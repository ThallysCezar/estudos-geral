import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/home/home.component').then(m => m.HomeComponent),
    title: 'Estudos · hoje'
  },
  {
    path: 'acervo',
    loadComponent: () => import('./features/acervo/acervo.component').then(m => m.AcervoComponent),
    title: 'O Acervo Completo · Estudos'
  },
  {
    path: 'trilhas/system-design',
    loadComponent: () =>
      import('./features/trilhas/system-design/system-design.component').then(
        m => m.SystemDesignComponent
      ),
    title: 'System Design · Estudos'
  },
  {
    path: 'trilhas/java',
    loadComponent: () =>
      import('./features/trilhas/java/java.component').then(m => m.JavaComponent),
    title: 'Java 21 Moderno · Estudos'
  },
  {
    path: 'trilhas/arquitetura',
    loadComponent: () =>
      import('./features/trilhas/arquitetura/arquitetura.component').then(
        m => m.ArquiteturaComponent
      ),
    title: 'Arquitetura de Software · Estudos'
  },
  {
    path: 'trilhas/docker-kubernetes',
    loadComponent: () =>
      import('./features/trilhas/docker-kubernetes/docker-kubernetes.component').then(
        m => m.DockerKubernetesComponent
      ),
    title: 'Docker & Kubernetes · Estudos'
  },
  {
    path: 'trilhas/nuvem',
    loadComponent: () =>
      import('./features/trilhas/nuvem/nuvem.component').then(m => m.NuvemComponent),
    title: 'Computação em Nuvem · Estudos'
  },
  {
    path: 'trilhas/spring',
    loadComponent: () =>
      import('./features/trilhas/spring/spring.component').then(m => m.SpringComponent),
    title: 'Spring Boot 3 · Estudos'
  },
  {
    path: 'trilhas/mensageria',
    loadComponent: () =>
      import('./features/trilhas/mensageria/mensageria.component').then(
        m => m.MensageriaComponent
      ),
    title: 'Mensageria & Filas · Estudos'
  },
  {
    path: 'trilhas/ia',
    loadComponent: () =>
      import('./features/trilhas/ia/ia.component').then(m => m.IaComponent),
    title: 'IA para Backend · Estudos'
  },
  {
    path: 'lab/projetos',
    loadComponent: () =>
      import('./features/lab/projetos/projetos.component').then(
        m => m.ProjetosLabComponent
      ),
    title: 'Laboratório de Projetos · Estudos'
  },
  {
    path: 'cadernos/conceitos-backend',
    loadComponent: () =>
      import('./features/cadernos/conceitos-backend/conceitos-backend.component').then(
        m => m.ConceitosBackendComponent
      ),
    title: 'Conceitos de Backend · Estudos'
  },
  {
    path: 'cadernos/linux',
    loadComponent: () =>
      import('./features/cadernos/linux/linux.component').then(
        m => m.LinuxComponent
      ),
    title: 'Linux & Terminal · Estudos'
  },
  {
    path: 'cadernos/git',
    loadComponent: () =>
      import('./features/cadernos/git/git.component').then(m => m.GitComponent),
    title: 'Git & Versionamento · Estudos'
  },
  {
    path: 'cadernos/biblioteca',
    loadComponent: () =>
      import('./features/cadernos/biblioteca/biblioteca.component').then(
        m => m.BibliotecaComponent
      ),
    title: 'Biblioteca Técnica · Estudos'
  },
  {
    path: 'cadernos/ingles',
    loadComponent: () =>
      import('./features/cadernos/ingles/ingles.component').then(
        m => m.InglesComponent
      ),
    title: 'Inglês Técnico · Estudos'
  },
  {
    path: 'cadernos/oratoria',
    loadComponent: () =>
      import('./features/cadernos/oratoria/oratoria.component').then(
        m => m.OratoriaComponent
      ),
    title: 'Oratória & Comunicação · Estudos'
  },
  {
    path: 'ferramentas/prompt-studio',
    loadComponent: () =>
      import('./features/ferramentas/prompt-studio/prompt-studio.component').then(
        m => m.PromptStudioComponent
      ),
    title: 'Prompt Studio · Engenharia de Prompt & Janela de Contexto para IA'
  },
  {
    path: 'ferramentas/refinador',
    loadComponent: () =>
      import('./features/ferramentas/refinador/refinador.component').then(
        m => m.RefinadorComponent
      ),
    title: 'Formatador & Refinador de Texto · Google Gemini'
  },
  {
    path: 'ferramentas/tutorial-api',
    loadComponent: () =>
      import('./features/ferramentas/tutorial-api/tutorial-api.component').then(
        m => m.TutorialApiFerramentaComponent
      ),
    title: 'Guia de APIs de IA Gratuitas · Google Gemini, Groq & OpenRouter'
  },
  {
    path: 'lab/tutorial-api',
    loadComponent: () =>
      import('./features/lab/tutorial-api/tutorial-api.component').then(
        m => m.TutorialApiLabComponent
      ),
    title: 'Tutorial de APIs de IA Gratuitas · Laboratório'
  },
  {
    path: '**',
    redirectTo: ''
  }
];
