import { Component, computed, inject, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AlternanciaService } from './core/services/alternancia.service';
import { AuraBackgroundComponent } from './shared/components/aura-background/aura-background.component';
import { IslandNavComponent } from './shared/components/island-nav/island-nav.component';
import { CommandPaletteComponent } from './shared/components/command-palette/command-palette.component';
import { BackupModalComponent } from './shared/components/backup-modal/backup-modal.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    AuraBackgroundComponent,
    IslandNavComponent,
    CommandPaletteComponent,
    BackupModalComponent
  ],
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  private alternanciaService = inject(AlternanciaService);

  readonly backupModalOpen = signal<boolean>(false);
  readonly accentColor = computed(() => this.alternanciaService.diaHoje().cor);

  abrirBackup(): void {
    this.backupModalOpen.set(true);
  }

  fecharBackup(): void {
    this.backupModalOpen.set(false);
  }
}
