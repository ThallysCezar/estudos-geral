// @vitest-environment jsdom
import { AlternanciaService } from './alternancia.service';
import { describe, it, expect, beforeEach } from 'vitest';

describe('AlternanciaService', () => {
  let service: AlternanciaService;

  beforeEach(() => {
    service = new AlternanciaService();
    localStorage.clear();
  });

  it('deve possuir os 7 dias na grade semanal', () => {
    expect(service.SEM.length).toBe(7);
    const siglas = service.SEM.map(d => d.sig);
    expect(siglas).toEqual(['seg', 'ter', 'qua', 'qui', 'sex', 'sáb', 'dom']);
  });

  it('deve gravar e recuperar o histórico de alternância em formato JSON', () => {
    service.gravar('ter', '/trilhas/spring');
    const registros = service.lerRegistros();
    expect(registros['ter']).toBeDefined();
    expect(registros['ter'][0].f).toBe('/trilhas/spring');
  });

  it('deve calcular a distância temporal em palavras', () => {
    const agora = Date.now();
    expect(service.quando(agora, 'na terça passada')).toBe('hoje mesmo');
  });
});
