import { Injectable, signal, computed } from '@angular/core';

export interface DiaOpcao {
  f: string;
  nome: string;
  nota: string;
  versao?: string;
}

export interface DiaCronograma {
  sig: string;
  tema: string;
  cor: string;
  doc?: string;
  doc2?: string;
  label: string;
  label2?: string;
  ini?: string;
  fim?: string;
  slot: string;
  passado: string;
  n1: string;
  n2: string;
  nota: string;
  livre?: string;
  descanso?: boolean;
  opcoes?: DiaOpcao[];
}

export interface RegistroItem {
  f: string;
  t: number;
}

export type RegistroAlternancia = Record<string, RegistroItem[]>;

@Injectable({
  providedIn: 'root'
})
export class AlternanciaService {
  private readonly RK = 'site.index.alternancia.v1';

  readonly SEM: DiaCronograma[] = [
    {
      sig: 'seg',
      tema: 'Java',
      cor: 'var(--cyan)',
      doc: '/trilhas/java',
      label: 'Java (7 Pilares)',
      ini: '19:30',
      fim: '22:30',
      slot: 'seg',
      passado: 'na segunda passada',
      n1: 'Plataforma e runtime: valores, referências, generics, coleções, falhas, JDBC sem ORM, concorrência e JVM.',
      n2: 'Java 21 Moderno em 7 Pilares: JMM, JIT C1/C2, Virtual Threads, HikariCP, GC e simulador interativo de concorrência.',
      nota: 'Da plataforma ao runtime em produção: escolha entre a versão V1 (Vault) ou a versão V2 (7 Pilares Didáticos & Lab Interativo).'
    },
    {
      sig: 'ter',
      tema: 'Spring e Mensageria',
      cor: 'var(--purple)',
      doc: '/trilhas/spring',
      label: 'Spring Boot 3 (7 Pilares)',
      ini: '19:30',
      fim: '22:30',
      slot: 'ter',
      passado: 'na terça passada',
      opcoes: [
        {
          f: '/trilhas/spring',
          nome: 'Spring Boot 3 (7 Pilares)',
          nota: 'Spring Boot 3 em 7 Pilares: arquitetura interna, CGLIB internals, Testcontainers e observabilidade.',
          versao: 'V2'
        },
        {
          f: '/trilhas/mensageria',
          nome: 'Mensageria & RabbitMQ (7 Pilares)',
          nota: 'Mensageria & RabbitMQ em 7 Pilares: topologia AMQP, Dead Letter Queue, Outbox Pattern e Kafka.',
          versao: 'V2'
        }
      ],
      n1: 'O container de IoC até a produção: ciclo de vida do bean, AOP e proxies, transação, Boot e configuração.',
      n2: 'Spring Boot 3 em 7 Pilares: arquitetura interna, CGLIB internals, Testcontainers e observabilidade.',
      nota: 'Do container de IoC à mensageria resiliente: escolha entre as versões de Spring e Mensageria.'
    },
    {
      sig: 'qua',
      tema: 'Nuvem',
      cor: 'var(--orange)',
      doc: '/trilhas/nuvem',
      label: 'Nuvem (7 Pilares)',
      ini: '19:30',
      fim: '22:30',
      slot: 'qua',
      passado: 'na quarta passada',
      n1: 'Conceitual e sem vendor: mapa de tradução entre AWS, Azure, Google, Oracle e VMware. Compute, rede, storage e IaC.',
      n2: 'Nuvem Multicloud em 7 Pilares: simulador interativo de VPC/CIDR, matriz comparativa AWS/Azure/GCP, IAM Least Privilege, S3 storage tiers e FinOps.',
      nota: 'Arquitetura de nuvem agnóstica: escolha entre a versão V1 (Vault) ou a versão V2 (7 Pilares Didáticos & Simulador VPC).'
    },
    {
      sig: 'qui',
      tema: 'Docker e Kubernetes',
      cor: 'var(--lime)',
      doc: '/trilhas/docker-kubernetes',
      label: 'Docker & K8s (7 Pilares)',
      ini: '19:30',
      fim: '22:30',
      slot: 'qui',
      passado: 'na quinta passada',
      n1: 'Do processo isolado ao cluster: namespaces e cgroups, camadas e cache do Dockerfile, ENTRYPOINT e PID 1, Pod, Service, Ingress e HPA.',
      n2: 'Containers e Kubernetes em 7 Pilares: simulador interativo de Probes (Liveness/Readiness/Startup), multi-stage builds, isolamento cgroups e autoescalonamento.',
      nota: 'Do processo isolado ao cluster em produção: escolha entre a versão V1 (Vault) ou a versão V2 (7 Pilares & Simulador de Probes).'
    },
    {
      sig: 'sex',
      tema: 'Arquitetura',
      cor: 'var(--gold)',
      doc: '/trilhas/arquitetura',
      label: 'Arquitetura (7 Pilares)',
      ini: '19:30',
      fim: '21:00',
      slot: 'sex',
      passado: 'na sexta passada',
      n1: 'O que arquitetura é de verdade: SOLID e a lei de Conway, estilos, DDD, comunicação, dados e consistência, escala e resiliência.',
      n2: 'Arquitetura de Software em 7 Pilares: simulador interativo de Circuit Breaker com estados CLOSED/OPEN/HALF-OPEN, Saga, Outbox, C4 Model e consistência eventual.',
      nota: 'Arquitetura de sistemas em produção: escolha entre a versão V1 (Vault) ou a versão V2 (7 Pilares & Simulador Circuit Breaker).'
    },
    {
      sig: 'sáb',
      tema: 'Inglês e oratória',
      cor: 'var(--pink)',
      doc: '/cadernos/ingles',
      doc2: '/cadernos/oratoria',
      label: 'Inglês',
      label2: 'Oratória',
      livre: '60 a 90 min, quando der',
      slot: 'sab',
      passado: 'no sábado passado',
      n1: 'Entrada antes de saída: escuta, leitura, shadowing e a reunião ao vivo em inglês.',
      n2: 'Gravar a própria voz, estruturar antes do slide e defender uma decisão técnica.',
      nota: 'Sábado sai da sequência técnica: inglês e oratória. O inglês pede 20 min por dia; o sábado é para a parte que precisa de bloco.'
    },
    {
      sig: 'dom',
      tema: 'Inteligência Artificial',
      cor: 'var(--purple)',
      doc: '/trilhas/ia',
      label: 'AI Engineering',
      livre: 'projeto próprio e IA',
      slot: 'dom',
      passado: 'no domingo passado',
      n1: 'Toda a base e vault: do token ao agente, RAG, prompt engineering, embeddings, pgvector, MCP e guardrails.',
      n2: 'AI Engineering V4 em 6 Níveis com Mapas Conceituais e Didática Visual: Fundamentos, Tokens, SDD, Spring AI, Agentes e Test Harness.',
      nota: 'Domingo é para IA e projeto próprio: escolha entre a versão V1 (Fundações & Vault) ou a versão V4 (Didática, Visual & 6 Níveis de Engenharia).'
    }
  ];

  readonly diaAtualIdx = signal<number>((new Date().getDay() + 6) % 7);
  readonly diaHoje = computed(() => this.SEM[this.diaAtualIdx()]);
  readonly diaAmanha = computed(() => this.SEM[(this.diaAtualIdx() + 1) % 7]);

  lerRegistros(): RegistroAlternancia {
    try {
      return JSON.parse(localStorage.getItem(this.RK) || '{}');
    } catch {
      return {};
    }
  }

  gravar(slot: string, file: string): void {
    try {
      const r = this.lerRegistros();
      const a = r[slot] || [];
      a.unshift({ f: file, t: Date.now() });
      r[slot] = a.slice(0, 12);
      localStorage.setItem(this.RK, JSON.stringify(r));
    } catch (e) {
      console.warn('Erro ao gravar alternancia:', e);
    }
  }

  quando(ts: number, pass: string): string {
    const a = new Date(ts);
    a.setHours(0, 0, 0, 0);
    const b = new Date();
    b.setHours(0, 0, 0, 0);
    const n = Math.round((b.getTime() - a.getTime()) / 864e5);
    const dt = new Date(ts).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    if (n <= 0) return 'hoje mesmo';
    if (n === 1) return 'ontem';
    if (n < 6) return `há ${n} dias, em ${dt}`;
    if (n <= 10) return `${pass}, em ${dt}`;
    return `há ${Math.round(n / 7)} semanas, em ${dt}`;
  }
}
