import { PaletteService } from './palette.service';
import { describe, it, expect, beforeEach } from 'vitest';

describe('PaletteService', () => {
  let service: PaletteService;

  beforeEach(() => {
    service = new PaletteService();
  });

  it('deve inicializar fechado e com catálogo preenchido', () => {
    expect(service.isOpen()).toBe(false);
    expect(service.DATA.length).toBeGreaterThanOrEqual(25);
  });

  it('deve alternar estado de abertura com toggle()', () => {
    service.toggle();
    expect(service.isOpen()).toBe(true);
    service.toggle();
    expect(service.isOpen()).toBe(false);
  });

  it('deve filtrar resultados por título ou categoria reativamente', () => {
    service.query.set('outbox');
    const resultados = service.filtered();
    expect(resultados.length).toBeGreaterThan(0);
    expect(resultados.some(item => item.t.toLowerCase().includes('outbox'))).toBe(true);
  });
});
