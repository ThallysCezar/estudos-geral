import { Injectable, signal, computed } from '@angular/core';

export interface PaletteItem {
  t: string;
  sub: string;
  cat: string;
  url: string;
  cor: string;
}

@Injectable({
  providedIn: 'root'
})
export class PaletteService {
  readonly isOpen = signal<boolean>(false);
  readonly query = signal<string>('');

  readonly DATA: PaletteItem[] = [
    { t: 'Java completo (7 Pilares)', sub: 'Java 21, JMM, Virtual Threads, HikariCP, GC e simulador de concorrência', cat: 'TRILHA', url: '/trilhas/java', cor: 'var(--cyan)' },
    { t: 'Spring Boot 3 (7 Pilares)', sub: 'Spring Boot 3, arquitetura interna, Testcontainers e observabilidade', cat: 'TRILHA', url: '/trilhas/spring', cor: 'var(--purple)' },
    { t: 'Mensageria e RabbitMQ (7 Pilares)', sub: 'Topologia AMQP, Dead Letter Queue, Outbox Pattern e resiliência', cat: 'TRILHA', url: '/trilhas/mensageria', cor: 'var(--pink)' },
    { t: 'Nuvem Multicloud (7 Pilares)', sub: 'VPC CIDR Simulator, AWS/Azure/GCP matrix, IAM Least Privilege e FinOps', cat: 'TRILHA', url: '/trilhas/nuvem', cor: 'var(--orange)' },
    { t: 'Docker e Kubernetes (7 Pilares)', sub: 'Probe Simulator (Liveness/Readiness), multi-stage builds e cgroups', cat: 'TRILHA', url: '/trilhas/docker-kubernetes', cor: 'var(--lime)' },
    { t: 'Arquitetura de Software (7 Pilares)', sub: 'Circuit Breaker Simulator, Saga, Outbox, C4 Model e consistência', cat: 'TRILHA', url: '/trilhas/arquitetura', cor: 'var(--gold)' },
    { t: 'System Design completo', sub: '17 Sistemas reais, Little\'s Law, sharding, chaves, Bloom filter e SLAs', cat: 'TRILHA', url: '/trilhas/system-design', cor: 'var(--lime)' },
    { t: 'AI Engineering completo', sub: 'Os 6 Grandes Níveis com mapas conceituais: Transformers, RoPE, Speculative Decoding, pgvector, agentes e Test Harness', cat: 'TRILHA', url: '/trilhas/ia', cor: 'var(--teal)' },
    { t: 'Conceitos de Backend completo', sub: 'Locks, race conditions, índices, JWT e War Room', cat: 'CADERNO', url: '/cadernos/conceitos-backend', cor: 'var(--gold)' },
    { t: 'Biblioteca clássica', sub: '5 livros fundamentais de arquitetura e algoritmos', cat: 'CADERNO', url: '/cadernos/biblioteca', cor: 'var(--purple)' },
    { t: 'Linux e terminal completo', sub: 'Processos, sinais, descritores, pipes e systemd', cat: 'CADERNO', url: '/cadernos/linux', cor: 'var(--orange)' },
    { t: 'Git em profundidade', sub: 'Grafo DAG, reflog, rebase, squash e recuperação', cat: 'CADERNO', url: '/cadernos/git', cor: 'var(--pink)' },
    { t: 'Inglês técnico completo', sub: 'Input compreensível, vocabulário e reuniões', cat: 'CADERNO', url: '/cadernos/ingles', cor: 'var(--cyan)' },
    { t: 'Oratória e comunicação', sub: 'Defesa técnica de decisões, postmortems e SBI', cat: 'CADERNO', url: '/cadernos/oratoria', cor: 'var(--gold)' },
    { t: 'Laboratório de projetos', sub: 'Bancada de 18 projetos práticos e OrderFlow', cat: 'LAB', url: '/lab/projetos', cor: 'var(--lime)' },
    { t: 'Transactional Outbox & Relay', sub: 'Garantia de publicação sem dual-write e at-least-once', cat: 'TEMA', url: '/trilhas/mensageria#g2', cor: 'var(--pink)' },
    { t: 'Connection Starvation no HikariCP', sub: 'HTTP síncrono lento dentro de @Transactional', cat: 'WAR ROOM', url: '/cadernos/conceitos-backend#j2', cor: 'var(--rose)' },
    { t: 'OOMKilled Fantasma (Exit 137)', sub: 'Limite do container cgroup vs memória Off-Heap JVM', cat: 'WAR ROOM', url: '/cadernos/conceitos-backend#j1', cor: 'var(--rose)' },
    { t: 'Avalanche e Poison Pill no RabbitMQ', sub: 'Requeue infinito, prefetch e Dead Letter Queue', cat: 'WAR ROOM', url: '/cadernos/conceitos-backend#j3', cor: 'var(--rose)' },
    { t: 'Pool de Conexões e HPA no K8s', sub: 'Multiplicação perigosa de conexões sob autoescalonamento', cat: 'PONTE', url: '/trilhas/java#g2', cor: 'var(--orange)' },
    { t: 'PID 1, Sinais POSIX e Graceful Shutdown', sub: 'Forma shell vs exec e terminação limpa no Kubernetes', cat: 'PONTE', url: '/trilhas/docker-kubernetes#b3', cor: 'var(--orange)' },
    { t: 'Java Memory Model & Concorrência', sub: 'Volatile, happens-before, atomics e Virtual Threads', cat: 'TEMA', url: '/trilhas/java#p9', cor: 'var(--cyan)' },
    { t: 'Proxies Spring, CGLIB e Self-Invocation', sub: 'Por que @Transactional falha quando chamado internamente', cat: 'TEMA', url: '/trilhas/spring#c4', cor: 'var(--purple)' },
    { t: 'Locks Pessimista, Otimista e Distribuído', sub: 'SELECT FOR UPDATE, @Version e Redis Redlock', cat: 'TEMA', url: '/cadernos/conceitos-backend#p3', cor: 'var(--gold)' },
    { t: 'Saga e Transações Compensatórias', sub: 'Orquestração vs Coreografia e consistência eventual', cat: 'TEMA', url: '/trilhas/arquitetura#f3', cor: 'var(--gold)' },
    { t: 'RAG, Embeddings e Bancos Vetoriais', sub: 'Busca semântica híbrida com pgvector / Qdrant', cat: 'IA', url: '/trilhas/ia#t4-rag', cor: 'var(--purple)' },
    { t: 'Constrained Decoding e Gramáticas BNF', sub: 'Saída JSON estruturada estrita contra alucinações', cat: 'IA', url: '/trilhas/ia#t4-structured', cor: 'var(--purple)' },
    { t: 'Protocolo MCP (Model Context Protocol)', sub: 'Arquitetura de servidores de ferramentas stdio/SSE', cat: 'IA', url: '/trilhas/ia#t5-mcp', cor: 'var(--purple)' },
    { t: 'Test Harness & Evals para Agentes', sub: 'Benchmarking determinístico e suites de regressão em CI/CD', cat: 'IA', url: '/trilhas/ia#t6-harness', cor: 'var(--teal)' },
    { t: 'SDD (Spec-Driven Development) & Prompts', sub: 'As 4 camadas de steering e redução drástica de tokens', cat: 'IA', url: '/trilhas/ia#t3-sdd', cor: 'var(--teal)' },
    { t: 'Agentes Autônomos & Loop ReAct', sub: 'Ciclo Pensamento-Ação-Observação e padrão Orchestrator-Workers', cat: 'IA', url: '/trilhas/ia#t5-react', cor: 'var(--teal)' },
    { t: 'Projeto R03 · OrderFlow Capstone', sub: 'Microsserviços com Saga, Outbox, RabbitMQ e K8s', cat: 'PROJETO', url: '/lab/projetos', cor: 'var(--lime)' }
  ];

  readonly filtered = computed(() => {
    const q = this.query().toLowerCase().trim();
    if (!q) return this.DATA;
    return this.DATA.filter(
      item =>
        item.t.toLowerCase().includes(q) ||
        item.sub.toLowerCase().includes(q) ||
        item.cat.toLowerCase().includes(q)
    );
  });

  open(): void {
    this.isOpen.set(true);
    this.query.set('');
  }

  close(): void {
    this.isOpen.set(false);
  }

  toggle(): void {
    if (this.isOpen()) {
      this.close();
    } else {
      this.open();
    }
  }
}
