// @vitest-environment jsdom
import { StorageService } from './storage.service';
import { describe, it, expect, beforeEach } from 'vitest';

describe('StorageService', () => {
  let service: StorageService;

  beforeEach(() => {
    service = new StorageService();
    localStorage.clear();
  });

  it('deve ser instanciado corretamente', () => {
    expect(service).toBeTruthy();
  });

  it('deve salvar e resgatar itens no localStorage', () => {
    service.setItem('site.teste.v1', 'valor-teste');
    expect(service.getItem('site.teste.v1')).toBe('valor-teste');
  });

  it('deve bloquear chaves sensíveis ao exportar backup', async () => {
    service.setItem('gemini_api_key', 'chave-secreta-123');
    service.setItem('meu_token', 'token-privado');
    service.setItem('site.index.alternancia.v1', JSON.stringify({ seg: [] }));

    const blob = service.exportBackup();
    const text = await blob.text();
    const backup = JSON.parse(text);

    expect(backup.dados['gemini_api_key']).toBeUndefined();
    expect(backup.dados['meu_token']).toBeUndefined();
    expect(backup.dados['site.index.alternancia.v1']).toBeDefined();
  });

  it('deve bloquear prototype pollution e chaves sensíveis ao restaurar backup', () => {
    const payload = JSON.stringify({
      versao: 1,
      exportadoEm: new Date().toISOString(),
      dados: {
        '__proto__': 'ataque',
        'api_key': 'chave-injetada',
        'site.index.alternancia.v1': 'dados-validos'
      }
    });

    const res = service.importBackup(payload);
    expect(res.success).toBe(true);
    expect(service.getItem('site.index.alternancia.v1')).toBe('dados-validos');
    expect(service.getItem('api_key')).toBeNull();
  });
});
