import { Injectable } from '@angular/core';

export interface BackupData {
  versao: number;
  exportadoEm: string;
  dados: Record<string, string>;
}

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  private readonly SENSITIVE_REGEX = /api_key|token|secret|credential|password|gemini/i;

  getItem(key: string): string | null {
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }

  setItem(key: string, value: string): void {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.warn('Erro ao salvar no localStorage:', e);
    }
  }

  get<T>(key: string, fallback: T): T {
    try {
      const val = this.getItem(key);
      if (!val) return fallback;
      return JSON.parse(val) as T;
    } catch {
      return fallback;
    }
  }

  set<T>(key: string, value: T): void {
    try {
      this.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn('Erro ao serializar para localStorage:', e);
    }
  }

  exportBackup(): Blob {
    const backup: BackupData = {
      versao: 1,
      exportadoEm: new Date().toISOString(),
      dados: {}
    };

    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!k || this.SENSITIVE_REGEX.test(k)) continue;

        if (
          k.startsWith('site.') ||
          k.includes('-completo-') ||
          k.includes('-trilha-') ||
          k.includes('-conteudo-') ||
          k.startsWith('ml.') ||
          k === 'quiz_xp' ||
          k.endsWith('_gam')
        ) {
          const val = localStorage.getItem(k);
          if (val !== null) {
            backup.dados[k] = val;
          }
        }
      }
    } catch (e) {
      console.error('Erro ao ler localStorage para exportação:', e);
    }

    return new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  }

  importBackup(jsonString: string): { success: boolean; count: number; error?: string } {
    try {
      const json = JSON.parse(jsonString) as BackupData;
      if (!json || !json.dados || typeof json.dados !== 'object') {
        return { success: false, count: 0, error: 'Arquivo de backup inválido.' };
      }

      let count = 0;
      for (const k in json.dados) {
        if (Object.prototype.hasOwnProperty.call(json.dados, k)) {
          // Blindagem contra Prototype Pollution
          if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
          // Blindagem contra injeção de credenciais
          if (this.SENSITIVE_REGEX.test(k)) continue;

          if (
            k.startsWith('site.') ||
            k.includes('-completo-') ||
            k.includes('-trilha-') ||
            k.includes('-conteudo-') ||
            k.startsWith('ml.') ||
            k === 'quiz_xp' ||
            k.endsWith('_gam')
          ) {
            if (typeof json.dados[k] === 'string') {
              localStorage.setItem(k, json.dados[k]);
              count++;
            }
          }
        }
      }

      return { success: true, count };
    } catch (err: any) {
      return { success: false, count: 0, error: err.message };
    }
  }
}
