import '@angular/compiler';
import { AcervoComponent } from './acervo.component';
import { describe, it, expect, beforeEach } from 'vitest';

describe('AcervoComponent', () => {
  let comp: AcervoComponent;

  beforeEach(() => {
    comp = new AcervoComponent();
  });

  it('deve listar todos os documentos cadastrados quando o filtro estiver vazio', () => {
    expect(comp.filtrados().length).toBe(comp.DOCUMENTOS.length);
    expect(comp.filtrados().length).toBeGreaterThanOrEqual(15);
  });

  it('deve filtrar os documentos reativamente pelo título ou chips', () => {
    comp.filtroTexto.set('kafka');
    const filtrados = comp.filtrados();
    expect(filtrados.length).toBeGreaterThan(0);
    expect(filtrados.some(d => d.titulo.includes('Mensageria') || d.chips.includes('Kafka'))).toBe(true);
  });
});
