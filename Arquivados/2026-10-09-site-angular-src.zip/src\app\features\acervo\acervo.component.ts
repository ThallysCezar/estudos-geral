import { Component, signal, computed } from '@angular/core';
import { RouterLink } from '@angular/router';

export interface DocumentoAcervo {
  titulo: string;
  categoria: 'TRILHA' | 'CADERNO' | 'LAB' | 'FERRAMENTA';
  cor: string;
  url: string;
  resumo: string;
  chips: string[];
}

@Component({
  selector: 'app-acervo',
  standalone: true,
  imports: [RouterLink],
  template: `
    <main class="wrap">
      <header class="acervo-header">
        <div class="stamp">
          <span class="dt">ÍNDICE COMPLETO</span>
        </div>
        <h1>O Acervo</h1>
        <p class="lede">
          Todos os documentos do ecossistema de estudos. Escolha por trilha temática ou filtre por conceito.
        </p>

        <div class="search-box">
          <input
            type="search"
            class="search-input"
            placeholder="Filtrar por tópico, assunto ou palavra-chave (ex: outbox, kubernetes, locks)..."
            [value]="filtroTexto()"
            (input)="onSearchInput($event)"
          />
        </div>
      </header>

      <section class="acervo-grid">
        @for (item of filtrados(); track item.url) {
          <a class="card-acervo" [routerLink]="item.url" [style.--card-c]="item.cor">
            <div class="card-top">
              <span class="card-badge">{{ item.categoria }}</span>
            </div>
            <h3>{{ item.titulo }}</h3>
            <p>{{ item.resumo }}</p>
            <div class="chips">
              @for (c of item.chips; track c) {
                <i>{{ c }}</i>
              }
            </div>
          </a>
        }
      </section>
    </main>
  `,
  styles: [`
    .acervo-header {
      padding: clamp(34px, 7vh, 70px) 0 30px;
      border-bottom: 1px solid var(--line);
      margin-bottom: 34px;
    }
    .stamp .dt {
      font: 700 .68rem "Cascadia Code", monospace;
      letter-spacing: .17em;
      text-transform: uppercase;
      color: var(--cyan);
    }
    h1 {
      margin: 14px 0 10px;
      font: 500 clamp(2.4rem, 6vw, 4.2rem) Georgia, serif;
    }
    .lede {
      font-size: 1.05rem;
      color: var(--ink2);
      max-width: 60ch;
      line-height: 1.6;
      margin: 0 0 24px;
    }
    .search-box {
      max-width: 600px;
    }
    .search-input {
      width: 100%;
      background: var(--panel);
      border: 1px solid var(--line2);
      border-radius: 14px;
      padding: 14px 18px;
      font: inherit;
      color: var(--ink);
      font-size: .95rem;
      outline: none;
      transition: border-color .2s;
    }
    .search-input:focus {
      border-color: var(--cyan);
    }
    .acervo-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 20px;
      padding-bottom: 80px;
    }
    .card-acervo {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 20px;
      padding: 24px;
      text-decoration: none;
      color: inherit;
      display: flex;
      flex-direction: column;
      transition: transform .25s ease, border-color .25s ease;
    }
    .card-acervo:hover {
      transform: translateY(-3px);
      border-color: var(--card-c);
    }
    .card-badge {
      font: 700 .6rem "Cascadia Code", monospace;
      letter-spacing: .08em;
      color: var(--card-c);
      background: color-mix(in srgb, var(--card-c) 14%, transparent);
      border: 1px solid color-mix(in srgb, var(--card-c) 30%, transparent);
      padding: 3px 8px;
      border-radius: 6px;
    }
    h3 {
      margin: 14px 0 10px;
      font: 500 1.4rem Georgia, serif;
      color: var(--ink);
    }
    p {
      margin: 0;
      font-size: .86rem;
      color: var(--muted);
      line-height: 1.6;
      flex-grow: 1;
    }
    .chips {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 18px;
    }
    .chips i {
      font-style: normal;
      font: .64rem "Cascadia Code", monospace;
      color: var(--soft);
      background: #1e1f29;
      padding: 3px 8px;
      border-radius: 999px;
      border: 1px solid var(--line2);
    }
  `]
})
export class AcervoComponent {
  readonly filtroTexto = signal<string>('');

  readonly DOCUMENTOS: DocumentoAcervo[] = [
    {
      titulo: 'System Design',
      categoria: 'TRILHA',
      cor: 'var(--lime)',
      url: '/trilhas/system-design',
      resumo: '17 Sistemas reais sob restrição: Little\'s Law, sharding, chaves, Bloom filter e SLAs.',
      chips: ['L = λ × W', 'partition key', 'Bloom filter', '17 sistemas']
    },
    {
      titulo: 'Java (7 Pilares)',
      categoria: 'TRILHA',
      cor: 'var(--cyan)',
      url: '/trilhas/java',
      resumo: 'Plataforma e JVM: JMM, JIT C1/C2, Virtual Threads, HikariCP e GC.',
      chips: ['JMM', 'Virtual Threads', 'HikariCP', 'GC']
    },
    {
      titulo: 'Spring Boot 3 (7 Pilares)',
      categoria: 'TRILHA',
      cor: 'var(--purple)',
      url: '/trilhas/spring',
      resumo: 'IoC container, CGLIB proxies, ciclo de vida do bean, Testcontainers e observabilidade.',
      chips: ['IoC', 'Proxies', '@Transactional', 'Testcontainers']
    },
    {
      titulo: 'Mensageria & RabbitMQ',
      categoria: 'TRILHA',
      cor: 'var(--pink)',
      url: '/trilhas/mensageria',
      resumo: 'Topologia AMQP, DLQ, Transactional Outbox Pattern e resiliência assíncrona.',
      chips: ['AMQP', 'DLQ', 'Outbox', 'Kafka']
    },
    {
      titulo: 'Arquitetura de Software',
      categoria: 'TRILHA',
      cor: 'var(--gold)',
      url: '/trilhas/arquitetura',
      resumo: 'SOLID, DDD, Saga, Circuit Breaker Simulator, C4 Model e consistência eventual.',
      chips: ['DDD', 'Circuit Breaker', 'Saga', 'C4 Model']
    },
    {
      titulo: 'Nuvem Multicloud',
      categoria: 'TRILHA',
      cor: 'var(--orange)',
      url: '/trilhas/nuvem',
      resumo: 'Agnóstico a vendors: VPC CIDR Simulator, AWS/Azure/GCP matrix, IAM e FinOps.',
      chips: ['VPC CIDR', 'AWS/GCP/Azure', 'IAM', 'FinOps']
    },
    {
      titulo: 'Docker & Kubernetes',
      categoria: 'TRILHA',
      cor: 'var(--lime)',
      url: '/trilhas/docker-kubernetes',
      resumo: 'Namespaces, cgroups, Probe Simulator (Liveness/Readiness), HPA e PID 1.',
      chips: ['Probes', 'Namespaces', 'cgroups', 'HPA']
    },
    {
      titulo: 'AI Engineering',
      categoria: 'TRILHA',
      cor: 'var(--teal)',
      url: '/trilhas/ia',
      resumo: '6 Níveis com Mapas Conceituais: Transformers, SDD, Spring AI, pgvector e Test Harness.',
      chips: ['RAG', 'pgvector', 'Agentes', 'Test Harness']
    },
    {
      titulo: 'Caderno de Dúvidas',
      categoria: 'CADERNO',
      cor: 'var(--gold)',
      url: '/cadernos/conceitos-backend',
      resumo: 'Locks, race condition, índices, JWT, OAuth2 e War Room de incidentes.',
      chips: ['locks', 'race condition', 'War Room']
    },
    {
      titulo: 'Biblioteca Clássica',
      categoria: 'CADERNO',
      cor: 'var(--purple)',
      url: '/cadernos/biblioteca',
      resumo: '5 Livros fundamentais de arquitetura e onde os autores divergem.',
      chips: ['DDD', 'Hard Parts', 'Algoritmos']
    },
    {
      titulo: 'Git em Profundidade',
      categoria: 'CADERNO',
      cor: 'var(--pink)',
      url: '/cadernos/git',
      resumo: 'Grafo de snapshots imutáveis: reflog, rebase interativo e recuperação.',
      chips: ['DAG', 'reflog', 'rebase', 'worktree']
    },
    {
      titulo: 'Linux e Terminal',
      categoria: 'CADERNO',
      cor: 'var(--orange)',
      url: '/cadernos/linux',
      resumo: 'Sinais POSIX, descritores de arquivo, cgroups e saída 137.',
      chips: ['PID 1', 'SIGTERM', 'cgroups']
    },
    {
      titulo: 'Inglês Técnico',
      categoria: 'CADERNO',
      cor: 'var(--cyan)',
      url: '/cadernos/ingles',
      resumo: 'Input compreensível, técnica de 3 passadas e reuniões internacionais.',
      chips: ['CEFR B2', 'Shadowing', 'Code Review']
    },
    {
      titulo: 'Oratória e Comunicação',
      categoria: 'CADERNO',
      cor: 'var(--gold)',
      url: '/cadernos/oratoria',
      resumo: 'Defesa de decisões técnicas, postmortems e modelo SBI.',
      chips: ['PREP', 'SBI', 'Defesa Técnica']
    },
    {
      titulo: 'Laboratório de Projetos',
      categoria: 'LAB',
      cor: 'var(--lime)',
      url: '/lab/projetos',
      resumo: '18 Projetos práticos com falhas injetadas e OrderFlow como capstone.',
      chips: ['18 Projetos', 'OrderFlow', 'R$ 0 local']
    }
  ];

  readonly filtrados = computed(() => {
    const q = this.filtroTexto().toLowerCase().trim();
    if (!q) return this.DOCUMENTOS;
    return this.DOCUMENTOS.filter(doc =>
      doc.titulo.toLowerCase().includes(q) ||
      doc.resumo.toLowerCase().includes(q) ||
      doc.categoria.toLowerCase().includes(q) ||
      doc.chips.some(c => c.toLowerCase().includes(q))
    );
  });

  onSearchInput(event: Event): void {
    const val = (event.target as HTMLInputElement).value;
    this.filtroTexto.set(val);
  }
}
