// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { BibliotecaComponent } from './biblioteca.component';

describe('BibliotecaComponent', () => {
  let comp: BibliotecaComponent;

  beforeEach(() => {
    comp = new BibliotecaComponent();
  });

  it('deve instanciar o caderno de Biblioteca', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Biblioteca Clássica');
  });
});
