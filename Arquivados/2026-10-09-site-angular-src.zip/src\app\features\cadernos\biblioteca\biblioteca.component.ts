import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-biblioteca',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/cadernos/biblioteca.html" />
  `
})
export class BibliotecaComponent {
  readonly titulo = 'Biblioteca Clássica';
}
