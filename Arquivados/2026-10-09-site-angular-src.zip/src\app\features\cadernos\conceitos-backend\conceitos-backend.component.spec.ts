// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { ConceitosBackendComponent } from './conceitos-backend.component';

describe('ConceitosBackendComponent', () => {
  let comp: ConceitosBackendComponent;

  beforeEach(() => {
    comp = new ConceitosBackendComponent();
  });

  it('deve instanciar o caderno de Conceitos de Backend', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Conceitos de Backend');
  });
});
