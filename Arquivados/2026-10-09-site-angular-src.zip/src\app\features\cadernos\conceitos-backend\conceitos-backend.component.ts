import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-conceitos-backend',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/cadernos/conceitos-backend.html" />
  `
})
export class ConceitosBackendComponent {
  readonly titulo = 'Conceitos de Backend';
}
