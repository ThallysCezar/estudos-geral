// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { GitComponent } from './git.component';

describe('GitComponent', () => {
  let comp: GitComponent;

  beforeEach(() => {
    comp = new GitComponent();
  });

  it('deve instanciar o caderno de Git', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Git e Versionamento');
  });
});
