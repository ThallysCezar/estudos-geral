// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { InglesComponent } from './ingles.component';

describe('InglesComponent', () => {
  let comp: InglesComponent;

  beforeEach(() => {
    comp = new InglesComponent();
  });

  it('deve instanciar o caderno de Inglês', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Inglês Técnico');
  });
});
