// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { LinuxComponent } from './linux.component';

describe('LinuxComponent', () => {
  let comp: LinuxComponent;

  beforeEach(() => {
    comp = new LinuxComponent();
  });

  it('deve instanciar o caderno de Linux', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Linux e Terminal');
  });
});
