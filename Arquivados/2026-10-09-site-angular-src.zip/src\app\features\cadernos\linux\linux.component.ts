import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-linux',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/cadernos/linux.html" />
  `
})
export class LinuxComponent {
  readonly titulo = 'Linux e Terminal';
}
