// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { OratoriaComponent } from './oratoria.component';

describe('OratoriaComponent', () => {
  let comp: OratoriaComponent;

  beforeEach(() => {
    comp = new OratoriaComponent();
  });

  it('deve instanciar o caderno de Oratória', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Oratória e Comunicação');
  });
});
