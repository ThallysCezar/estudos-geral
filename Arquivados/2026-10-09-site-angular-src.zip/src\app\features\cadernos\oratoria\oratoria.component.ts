import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-oratoria',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/cadernos/oratoria.html" />
  `
})
export class OratoriaComponent {
  readonly titulo = 'Oratória e Comunicação';
}
