// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { PromptStudioComponent } from './prompt-studio.component';

describe('PromptStudioComponent', () => {
  let comp: PromptStudioComponent;

  beforeEach(() => {
    comp = new PromptStudioComponent();
  });

  it('deve instanciar a ferramenta Prompt Studio', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Prompt Studio');
  });
});
