import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-prompt-studio',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/ferramentas/prompt-studio.html" />
  `
})
export class PromptStudioComponent {
  readonly titulo = 'Prompt Studio';
}
