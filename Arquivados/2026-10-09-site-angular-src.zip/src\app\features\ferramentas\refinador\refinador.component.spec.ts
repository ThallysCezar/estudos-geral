// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { RefinadorComponent } from './refinador.component';

describe('RefinadorComponent', () => {
  let comp: RefinadorComponent;

  beforeEach(() => {
    comp = new RefinadorComponent();
  });

  it('deve instanciar o refinador de texto', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Formatador e Refinador de Texto');
  });
});
