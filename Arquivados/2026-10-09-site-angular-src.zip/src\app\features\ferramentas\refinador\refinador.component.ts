import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-refinador',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/ferramentas/refinador.html" />
  `
})
export class RefinadorComponent {
  readonly titulo = 'Formatador e Refinador de Texto';
}
