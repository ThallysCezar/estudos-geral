// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { TutorialApiFerramentaComponent } from './tutorial-api.component';

describe('TutorialApiFerramentaComponent', () => {
  let comp: TutorialApiFerramentaComponent;

  beforeEach(() => {
    comp = new TutorialApiFerramentaComponent();
  });

  it('deve instanciar a ferramenta Tutorial API', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Guia de APIs de IA');
  });
});
