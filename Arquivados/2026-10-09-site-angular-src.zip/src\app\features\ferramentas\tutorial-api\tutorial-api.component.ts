import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-ferramentas-tutorial-api',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/ferramentas/tutorial-api.html" />
  `
})
export class TutorialApiFerramentaComponent {
  readonly titulo = 'Guia de APIs de IA';
}
