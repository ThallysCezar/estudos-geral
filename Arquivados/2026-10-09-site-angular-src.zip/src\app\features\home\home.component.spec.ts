// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { HomeComponent } from './home.component';

describe('HomeComponent', () => {
  let comp: HomeComponent;

  beforeEach(() => {
    localStorage.clear();
    comp = new HomeComponent();
  });

  it('deve carregar dados de dia e formatar data', () => {
    expect(comp.dataFormatada).toBeTruthy();
    expect(comp.diaHoje()).toBeTruthy();
    expect(comp.diaAmanha()).toBeTruthy();
  });

  it('deve conter o serviço de alternância e dias da semana', () => {
    expect(comp.alternanciaService.SEM.length).toBe(7);
  });
});
