import { Component, ViewChild, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AlternanciaService, DiaCronograma } from '../../core/services/alternancia.service';
import { AlternanciaModalComponent } from '../../shared/components/alternancia-modal/alternancia-modal.component';
import { MicrolearningWidgetComponent } from '../../shared/components/microlearning-widget/microlearning-widget.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink, AlternanciaModalComponent, MicrolearningWidgetComponent],
  template: `
    <main class="wrap">
      <section class="hero">
        <div class="stamp">
          <span class="dt">{{ dataFormatada }}</span>
          <span class="ln"></span>
          <span class="clk">{{ horarioTexto }}</span>
        </div>

        <h1>
          Hoje é <em [style.color]="diaHoje().cor">{{ diaHoje().tema }}</em>.
        </h1>
        <p class="lede">{{ diaHoje().nota }}</p>

        <div class="morrow" [style.--nx]="diaAmanha().cor">
          <span class="dot"></span>
          <span>Amanhã é <b>{{ diaAmanha().tema }}</b>.</span>
        </div>

        <div class="acts">
          @if (diaHoje().opcoes || diaHoje().doc2) {
            <button class="act" type="button" (click)="abrirModal(diaHoje())">
              escolher: {{ diaHoje().label }} →
            </button>
          } @else if (diaHoje().doc) {
            <a class="act" [routerLink]="diaHoje().doc">
              abrir {{ diaHoje().label.toLowerCase() }} →
            </a>
          }
          <a class="act ghost" routerLink="/acervo">ver o acervo</a>
          <a class="act ghost" routerLink="/cadernos/conceitos-backend">caderno de dúvidas</a>
        </div>
      </section>

      <!-- MicroLearning Diário -->
      <app-microlearning-widget />

      <section class="wk">
        <div class="hd">
          <h2>A semana</h2>
          <span class="kick">19:30 — 22:30 nos dias úteis</span>
        </div>
        <div class="wk-list">
          @for (x of alternanciaService.SEM; track x.sig; let i = $index) {
            @if (x.opcoes || x.doc2) {
              <button
                type="button"
                class="day"
                [class.now]="i === alternanciaService.diaAtualIdx()"
                [style.--c]="x.cor"
                (click)="abrirModal(x)"
              >
                <span class="sig">{{ x.sig }}</span>
                <span class="mid">
                  <span class="tm">
                    {{ x.tema }}
                    @if (i === alternanciaService.diaAtualIdx()) {
                      <span class="tag">hoje</span>
                    }
                    <span class="horario">{{ x.ini }} — {{ x.fim }}</span>
                  </span>
                  <span class="sub">{{ x.nota }}</span>
                </span>
                <span class="rt">
                  <span class="sel dois">escolher</span>
                  <span class="ar">↗</span>
                </span>
              </button>
            } @else if (x.doc) {
              <a
                class="day"
                [class.now]="i === alternanciaService.diaAtualIdx()"
                [style.--c]="x.cor"
                [routerLink]="x.doc"
              >
                <span class="sig">{{ x.sig }}</span>
                <span class="mid">
                  <span class="tm">
                    {{ x.tema }}
                    @if (i === alternanciaService.diaAtualIdx()) {
                      <span class="tag">hoje</span>
                    }
                    <span class="horario">{{ x.ini }} — {{ x.fim }}</span>
                  </span>
                  <span class="sub">{{ x.nota }}</span>
                </span>
                <span class="rt">
                  <span class="ar">↗</span>
                </span>
              </a>
            }
          }
        </div>
      </section>

      <!-- Seção Outros (7 Cards Canônicos) -->
      <section class="outros">
        <div class="hd"><h2>Outros</h2></div>

        <!-- 1. Caderno de dúvidas -->
        <a class="duv" routerLink="/cadernos/conceitos-backend">
          <span class="mk">?</span>
          <span class="bd">
            <span class="kk">fora da sequência</span>
            <h3>Caderno de dúvidas</h3>
            <p>Conceitos de Backend completo: o documento que não tem dia marcado. Abra sempre que bater uma dúvida — e anote a resposta ali, na parte certa, em vez de criar um arquivo novo solto.</p>
            <span class="chips">
              <i>gargalos e escala</i><i>race condition</i><i>locks</i><i>idempotência</i><i>rate limit</i><i>índices e JOINs</i><i>sessão vs JWT</i><i>OAuth2 e PKCE</i><i>observabilidade</i><i>deploy e rollback</i>
            </span>
          </span>
          <span class="go">↗</span>
        </a>

        <!-- 2. Biblioteca -->
        <a class="duv" routerLink="/cadernos/biblioteca" style="--dv:var(--purple)">
          <span class="mk">▤</span>
          <span class="bd">
            <span class="kk">a estante</span>
            <h3>Biblioteca</h3>
            <p>Os cinco livros que formaram o critério, num documento só — com a síntese de cada um e, principalmente, <b>onde os autores discordam</b>: é ali que mora o trade-off, e era invisível quando cada livro vivia no seu arquivo.</p>
            <span class="chips">
              <i>Fundamentals of Software Architecture</i><i>The Hard Parts</i><i>Learning DDD</i><i>System Design Interview</i><i>Entendendo Algoritmos</i><i>ordem de leitura</i>
            </span>
          </span>
          <span class="go">↗</span>
        </a>

        <!-- 3. Git -->
        <a class="duv" routerLink="/cadernos/git" style="--dv:var(--pink)">
          <span class="mk">⑂</span>
          <span class="bd">
            <span class="kk">o histórico</span>
            <h3>Git</h3>
            <p>Um <b>grafo de snapshots imutáveis</b>, não uma pilha de versões — e é dessa confusão que quase todo problema nasce. Unifica os quatro roadmaps que estavam concorrendo no vault. Comece pelo marco 04: saber recuperar é o que dá coragem para usar o resto da ferramenta.</p>
            <span class="chips">
              <i>cherry-pick -x</i><i>bisect</i><i>reflog</i><i>rebase -i --autosquash</i><i>--force-with-lease</i><i>worktree</i>
            </span>
          </span>
          <span class="go">↗</span>
        </a>

        <!-- 4. Linux e terminal -->
        <a class="duv" routerLink="/cadernos/linux" style="--dv:var(--orange)">
          <span class="mk">$_</span>
          <span class="bd">
            <span class="kk">o térreo</span>
            <h3>Linux e terminal</h3>
            <p>O que estava faltando <b>embaixo</b> de todos os outros. Todo laboratório roda em container, o Docker fala em PID 1 e SIGTERM, a Nuvem exige teardown por comando — e nenhum documento explicava o terminal. Cada conceito aqui vem com o sintoma real: o container que ignora o Ctrl+C, o disco que encheu sem arquivo grande, o 137 sem exceção no log.</p>
            <span class="chips">
              <i>SIGTERM × SIGKILL</i><i>PID 1</i><i>2&gt;&amp;1</i><i>grep sed awk</i><i>df × du</i><i>cgroup</i>
            </span>
          </span>
          <span class="go">↗</span>
        </a>

        <!-- 5. System Design -->
        <a class="duv" routerLink="/trilhas/system-design" style="--dv:var(--cyan)">
          <span class="mk">⧉</span>
          <span class="bd">
            <span class="kk">o projeto inteiro</span>
            <h3>System Design</h3>
            <p>O nono não explica mecanismo — ensina a <b>escolher entre eles sob restrição</b>. Nenhum conceito aparece sozinho: cada um chega com o caso que o obriga a existir, e com a conta que decide. 10 mil requisições por segundo, 1 milhão de eventos, dois bilhões de usernames, um milhão de pedidos para paginar.</p>
            <span class="chips">
              <i>L = λ × W</i><i>a escada de leitura</i><i>partition key</i><i>Bloom filter</i><i>keyset</i><i>falha parcial</i>
            </span>
          </span>
          <span class="go">↗</span>
        </a>

        <!-- 6. Inteligência Artificial -->
        <a class="duv" routerLink="/trilhas/ia" (click)="abrirModalIA($event)" style="--dv:var(--purple)">
          <span class="mk">◈</span>
          <span class="bd">
            <span class="kk">o que prevê · dois caminhos</span>
            <h3>Inteligência Artificial</h3>
            <p>Toda a área de IA do vault e a engenharia moderna: escolha entre a <b>Versão V1</b> (fundações, notas atômicas do vault, prompt, embedding e ofício) ou a <b>Versão V2/V3</b> (6 grandes níveis: fundamentos, tokens, SDD, Spring AI, pgvector, subagentes e Test Harness). Clique para escolher qual versão abrir no modal.</p>
            <span class="chips">
              <i>dois · escolher</i><i>V1 (Vault &amp; Fundações)</i><i>V2/V3 (6 Grandes Níveis)</i><i>tokens</i><i>RAG</i><i>pgvector</i><i>agentes</i><i>Test Harness</i>
            </span>
          </span>
          <span class="go">↗</span>
        </a>

        <!-- 7. Laboratório de projetos -->
        <a class="duv" routerLink="/lab/projetos" style="--dv:var(--lime)">
          <span class="mk">⌘</span>
          <span class="bd">
            <span class="kk">a bancada</span>
            <h3>Laboratório de projetos</h3>
            <p>Os catorze documentos explicam; aqui você constrói. <b>18 projetos</b> em seis oficinas — cada um com problema, falhas para injetar de propósito e o link de volta para o documento que sustenta a teoria. E <b>18 aquecimentos</b> de 20 a 40 minutos, para as noites que não comportam um projeto inteiro.</p>
            <span class="chips">
              <i>18 projetos</i><i>18 aquecimentos</i><i>tudo local primeiro</i><i>R$ 0 obrigatório</i><i>OrderFlow como capstone</i>
            </span>
          </span>
          <span class="go">↗</span>
        </a>
      </section>

      <footer>
        Caderno de estudos de Thallys Cézar. SPA acelerada com Angular & Signals.
      </footer>
    </main>

    <app-alternancia-modal #modalAlternancia />
  `,
  styles: [`
    .hero {
      padding: clamp(34px, 7vh, 86px) 0 0;
    }
    .stamp {
      display: flex;
      align-items: center;
      gap: 13px;
      flex-wrap: wrap;
    }
    .stamp .dt {
      font: 700 .68rem "Cascadia Code", monospace;
      letter-spacing: .17em;
      text-transform: uppercase;
      color: var(--cyan);
    }
    .stamp .ln {
      flex: 1;
      min-width: 30px;
      height: 1px;
      background: linear-gradient(to right, color-mix(in srgb, var(--cyan) 55%, transparent), transparent);
    }
    .stamp .clk {
      font: 700 .68rem "Cascadia Code", monospace;
      letter-spacing: .1em;
      color: var(--muted);
    }
    h1 {
      margin: 18px 0 0;
      font: 500 clamp(3rem, 10.5vw, 6.5rem)/1.02 Georgia, serif;
      letter-spacing: -.055em;
    }
    h1 em {
      font-style: normal;
    }
    .lede {
      margin: 22px 0 0;
      max-width: 58ch;
      color: var(--ink2);
      font-size: clamp(.95rem, 1.5vw, 1.1rem);
      line-height: 1.62;
    }
    .morrow {
      margin: 30px 0 0;
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .morrow .dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: var(--nx, var(--purple));
    }
    .morrow span {
      font-size: .86rem;
      color: var(--muted);
    }
    .morrow b {
      color: var(--nx, var(--purple));
      font-weight: 500;
    }
    .acts {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 30px;
    }
    .act {
      text-decoration: none;
      font-size: .85rem;
      padding: 12px 20px;
      border-radius: 999px;
      border: 1px solid color-mix(in srgb, var(--cyan) 52%, transparent);
      color: var(--cyan);
      background: color-mix(in srgb, var(--cyan) 12%, transparent);
      cursor: pointer;
      transition: background .35s ease;
    }
    .act:hover {
      background: color-mix(in srgb, var(--cyan) 22%, transparent);
    }
    .act.ghost {
      border-color: var(--line2);
      color: var(--ink);
      background: transparent;
    }
    .act.ghost:hover {
      background: #ffffff0a;
    }
    .wk {
      margin: clamp(56px, 9vh, 104px) 0 0;
    }
    .wk .hd {
      display: flex;
      align-items: baseline;
      justify-content: space-between;
      gap: 14px;
      padding-bottom: 13px;
      border-bottom: 1px solid var(--line);
    }
    .wk .hd h2 {
      margin: 0;
      font: 500 1.3rem Georgia, serif;
    }
    .wk-list {
      display: flex;
      flex-direction: column;
    }
    .day {
      display: grid;
      grid-template-columns: 60px minmax(0, 1fr) auto;
      gap: 22px;
      align-items: center;
      padding: 19px 16px 19px 18px;
      border-bottom: 1px solid var(--line);
      text-decoration: none;
      color: inherit;
      background: transparent;
      border-left: none;
      border-right: none;
      border-top: none;
      cursor: pointer;
      text-align: left;
      font-family: inherit;
      transition: background .3s ease;
    }
    .day:hover {
      background: color-mix(in srgb, var(--c) 8%, transparent);
    }
    .day.now {
      background: linear-gradient(90deg, color-mix(in srgb, var(--c) 14%, transparent), transparent 72%);
    }
    .day .sig {
      font: 700 .72rem "Cascadia Code", monospace;
      letter-spacing: .16em;
      text-transform: uppercase;
      color: var(--c);
    }
    .day .tm {
      display: block;
      font: 500 clamp(1.15rem, 2.4vw, 1.7rem)/1.2 Georgia, serif;
      letter-spacing: -.035em;
      color: var(--ink2);
    }
    .day .sub {
      display: block;
      margin-top: 10px;
      color: var(--muted);
      font-size: .82rem;
      line-height: 1.55;
    }
    .day .tag {
      display: inline-block;
      margin-left: 12px;
      font: 700 .58rem "Cascadia Code", monospace;
      background: var(--c);
      color: #282a36;
      border-radius: 999px;
      padding: 3px 8px;
    }
    .day .horario {
      display: inline-block;
      margin-left: 10px;
      font: 600 .62rem "Cascadia Code", monospace;
      color: var(--muted);
      background: #ffffff0a;
      border: 1px solid var(--line);
      border-radius: 999px;
      padding: 3px 9px;
    }
    .day .rt {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .day .sel {
      font: 700 .6rem "Cascadia Code", monospace;
      text-transform: uppercase;
      color: var(--c);
      border: 1px solid color-mix(in srgb, var(--c) 32%, transparent);
      border-radius: 999px;
      padding: 6px 12px;
    }
    .day .ar {
      color: var(--c);
      font: 500 1.05rem Georgia, serif;
    }
    .outros {
      margin: clamp(50px, 8vh, 84px) 0 0;
    }
    .outros .hd {
      border-bottom: 1px solid var(--line);
      padding-bottom: 16px;
    }
    .outros .hd h2 {
      margin: 0;
      font: 500 1.3rem Georgia, serif;
    }
    .duv {
      --dv: var(--gold);
      display: grid;
      grid-template-columns: auto minmax(0, 1fr) auto;
      gap: 26px;
      align-items: center;
      margin-top: 20px;
      padding: 28px 30px;
      border-radius: 26px;
      text-decoration: none;
      border: 1px solid color-mix(in srgb, var(--dv) 25%, transparent);
      background: var(--panel);
      transition: transform .3s ease, border-color .3s ease;
    }
    .duv:hover {
      border-color: color-mix(in srgb, var(--dv) 56%, transparent);
      transform: translateY(-4px);
    }
    .duv .mk {
      display: grid;
      place-items: center;
      width: 72px;
      height: 72px;
      border-radius: 22px;
      background: color-mix(in srgb, var(--dv) 10%, transparent);
      font: 500 2.2rem Georgia, serif;
      color: var(--dv);
    }
    .duv .kk {
      font: 700 .62rem "Cascadia Code", monospace;
      letter-spacing: .17em;
      text-transform: uppercase;
      color: var(--dv);
    }
    .duv h3 {
      margin: 9px 0;
      font: 500 clamp(1.4rem, 2.5vw, 1.8rem)/1.1 Georgia, serif;
      color: var(--ink);
    }
    .duv p {
      margin: 0;
      color: var(--muted);
      font-size: .87rem;
      line-height: 1.6;
    }
    .duv .chips {
      display: flex;
      flex-wrap: wrap;
      gap: 7px;
      margin-top: 14px;
    }
    .duv .chips i {
      font-style: normal;
      font: .66rem "Cascadia Code", monospace;
      color: var(--dv);
      border: 1px solid color-mix(in srgb, var(--dv) 25%, transparent);
      border-radius: 999px;
      padding: 5px 11px;
    }
    .duv .go {
      font: 500 1.5rem Georgia, serif;
      color: var(--dv);
    }
    footer {
      margin: clamp(56px, 9vh, 96px) 0 44px;
      padding-top: 24px;
      border-top: 1px solid var(--line);
      color: var(--muted);
      font-size: .77rem;
    }
    @media (max-width: 680px) {
      .day {
        grid-template-columns: 44px minmax(0, 1fr);
        gap: 14px;
      }
      .duv {
        grid-template-columns: 1fr;
        padding: 22px 20px;
      }
      .duv .mk, .duv .go {
        display: none;
      }
    }
  `]
})
export class HomeComponent {
  readonly alternanciaService: AlternanciaService;
  readonly diaHoje;
  readonly diaAmanha;

  constructor() {
    let service: AlternanciaService;
    try {
      service = inject(AlternanciaService);
    } catch {
      service = new AlternanciaService();
    }
    this.alternanciaService = service;
    this.diaHoje = this.alternanciaService.diaHoje;
    this.diaAmanha = this.alternanciaService.diaAmanha;
  }

  @ViewChild('modalAlternancia') modalAlternancia!: AlternanciaModalComponent;

  get dataFormatada(): string {
    return new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' });
  }

  get horarioTexto(): string {
    const d = this.diaHoje();
    return d.descanso ? 'sem pauta' : (d.livre ? d.livre : 'à noite');
  }

  abrirModal(dia: DiaCronograma): void {
    if (this.modalAlternancia) {
      this.modalAlternancia.abrir(dia);
    }
  }

  abrirModalIA(event: MouseEvent): void {
    if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) {
      return; // Permite abrir em nova aba sem interceptar
    }
    event.preventDefault();
    const diaIA = this.alternanciaService.SEM.find(d => d.slot === 'dom');
    if (diaIA && this.modalAlternancia) {
      this.modalAlternancia.abrir(diaIA);
    }
  }
}
