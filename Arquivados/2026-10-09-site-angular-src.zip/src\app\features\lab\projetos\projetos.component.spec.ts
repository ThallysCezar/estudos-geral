// @vitest-environment jsdom
import '@angular/compiler';
import { ProjetosLabComponent } from './projetos.component';
import { describe, it, expect, beforeEach } from 'vitest';

describe('ProjetosLabComponent', () => {
  let comp: ProjetosLabComponent;

  beforeEach(() => {
    localStorage.clear();
    comp = new ProjetosLabComponent();
  });

  it('deve inicializar com todos os 18 projetos da bancada cadastrados', () => {
    expect(comp.PROJETOS.length).toBe(18);
    expect(comp.projetosFiltrados().length).toBe(18);
  });

  it('deve filtrar os projetos por área reativamente', () => {
    comp.filtroArea.set('java');
    expect(comp.projetosFiltrados().every(p => p.area === 'java')).toBe(true);
    expect(comp.projetosFiltrados().length).toBe(3);

    comp.filtroArea.set('ai');
    expect(comp.projetosFiltrados().every(p => p.area === 'ai')).toBe(true);
    expect(comp.projetosFiltrados().length).toBe(3);
  });

  it('deve filtrar os projetos por dificuldade e por busca textual', () => {
    comp.filtroDificuldade.set('Avançado');
    expect(comp.projetosFiltrados().every(p => p.difficulty === 'Avançado')).toBe(true);

    comp.filtroTexto.set('outbox');
    expect(comp.projetosFiltrados().length).toBeGreaterThan(0);
    expect(comp.projetosFiltrados().some(p => p.id === 'R03')).toBe(true);
  });

  it('deve permitir marcar e desmarcar projetos concluídos salvando o progresso', () => {
    expect(comp.isDone('J01')).toBe(false);
    expect(comp.concluidosCount()).toBe(0);

    comp.toggleDone('J01');
    expect(comp.isDone('J01')).toBe(true);
    expect(comp.concluidosCount()).toBe(1);

    comp.toggleDone('J01');
    expect(comp.isDone('J01')).toBe(false);
    expect(comp.concluidosCount()).toBe(0);
  });
});
