import { Component, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { StorageService } from '../../../core/services/storage.service';

export interface ProjetoLab {
  id: string;
  area: 'java' | 'spring' | 'aws' | 'cloud' | 'ai' | 'rabbit';
  difficulty: 'Fundação' | 'Intermediário' | 'Avançado';
  sessions: number;
  title: string;
  summary: string;
  problem: string;
  why: string;
  learns: string[];
  architecture: string[];
  stack: string[];
  steps: string[];
  acceptance: string[];
  tests: string[];
  failures: string[];
  questions: string[];
  teoria: { doc: string; label: string; rota: string }[];
}

@Component({
  selector: 'app-projetos-lab',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="lab-shell">
      <header class="lab-hero">
        <div class="top-nav">
          <a routerLink="/" class="back-link">← Início</a>
          <span class="badge-lab">Bancada Experimental</span>
        </div>
        <h1>18 Projetos Práticos de Engenharia</h1>
        <p class="lede">
          De Java puro a Microsserviços e GenAI corporativa. Cada projeto aponta para o documento de teoria que o sustenta e conta com checklist de produção.
        </p>

        <!-- BARRA DE PROGRESSO XP -->
        <div class="progress-bar-wrap">
          <div class="pb-header">
            <span>Progresso da Bancada: <b>{{ concluidosCount() }} / {{ PROJETOS.length }}</b> projetos dominados</span>
            <span class="xp-val">+{{ concluidosCount() * 100 }} XP</span>
          </div>
          <div class="pb-track">
            <div class="pb-fill" [style.width.%]="progressoPct()"></div>
          </div>
        </div>
      </header>

      <!-- CONTROLES & FILTROS -->
      <section class="controls-panel">
        <div class="search-box">
          <input
            type="search"
            placeholder="Buscar por nome, stack ou tecnologia (ex: JDBC, Kafka, RAG)..."
            [value]="filtroTexto()"
            (input)="filtroTexto.set($any($event.target).value)"
          />
        </div>

        <div class="filter-row">
          <div class="filter-group">
            <span class="grp-label">Área:</span>
            <button
              class="filter-chip"
              [class.active]="filtroArea() === 'todas'"
              (click)="filtroArea.set('todas')"
              type="button"
            >
              Todas ({{ PROJETOS.length }})
            </button>
            <button
              class="filter-chip"
              [class.active]="filtroArea() === 'java'"
              (click)="filtroArea.set('java')"
              type="button"
            >
              ☕ Java Puro
            </button>
            <button
              class="filter-chip"
              [class.active]="filtroArea() === 'spring'"
              (click)="filtroArea.set('spring')"
              type="button"
            >
              🍃 Spring Boot
            </button>
            <button
              class="filter-chip"
              [class.active]="filtroArea() === 'rabbit'"
              (click)="filtroArea.set('rabbit')"
              type="button"
            >
              📬 RabbitMQ
            </button>
            <button
              class="filter-chip"
              [class.active]="filtroArea() === 'cloud'"
              (click)="filtroArea.set('cloud')"
              type="button"
            >
              ☁️ Cloud Agnóstica
            </button>
            <button
              class="filter-chip"
              [class.active]="filtroArea() === 'aws'"
              (click)="filtroArea.set('aws')"
              type="button"
            >
              🟧 Spring + AWS
            </button>
            <button
              class="filter-chip"
              [class.active]="filtroArea() === 'ai'"
              (click)="filtroArea.set('ai')"
              type="button"
            >
              🧠 GenAI
            </button>
          </div>

          <div class="filter-group">
            <span class="grp-label">Dificuldade:</span>
            <button
              class="filter-chip"
              [class.active]="filtroDificuldade() === 'todas'"
              (click)="filtroDificuldade.set('todas')"
              type="button"
            >
              Todas
            </button>
            <button
              class="filter-chip"
              [class.active]="filtroDificuldade() === 'Fundação'"
              (click)="filtroDificuldade.set('Fundação')"
              type="button"
            >
              Fundação
            </button>
            <button
              class="filter-chip"
              [class.active]="filtroDificuldade() === 'Intermediário'"
              (click)="filtroDificuldade.set('Intermediário')"
              type="button"
            >
              Intermediário
            </button>
            <button
              class="filter-chip"
              [class.active]="filtroDificuldade() === 'Avançado'"
              (click)="filtroDificuldade.set('Avançado')"
              type="button"
            >
              Avançado
            </button>
          </div>
        </div>
      </section>

      <!-- GRID DE PROJETOS -->
      <main class="projects-grid">
        @for (p of projetosFiltrados(); track p.id) {
          <article class="p-card" [class.is-done]="isDone(p.id)">
            <div class="p-card-top">
              <span class="p-id">{{ p.id }}</span>
              <span class="p-diff" [attr.data-diff]="p.difficulty">{{ p.difficulty }}</span>
              <button
                class="btn-toggle-done"
                (click)="toggleDone(p.id)"
                [title]="isDone(p.id) ? 'Marcar como pendente' : 'Marcar como concluído'"
                type="button"
              >
                {{ isDone(p.id) ? '✓ Concluído' : '○ Pendente' }}
              </button>
            </div>

            <h3>{{ p.title }}</h3>
            <p class="p-summary">{{ p.summary }}</p>

            <div class="p-stack">
              @for (tech of p.stack; track tech) {
                <span class="stack-tag">{{ tech }}</span>
              }
            </div>

            <div class="p-card-foot">
              <span class="sessions-tag">⏱️ {{ p.sessions }} sessões</span>
              <button class="btn-open-modal" (click)="abrirModal(p)" type="button">
                Ver Ficha Completa →
              </button>
            </div>
          </article>
        }
      </main>

      <!-- MODAL DE DETALHES DO PROJETO -->
      @if (projetoModal(); as p) {
        <div class="modal-backdrop" (click)="fecharModal()">
          <div class="modal-window" (click)="$event.stopPropagation()">
            <header class="modal-head">
              <div>
                <span class="p-id-lg">{{ p.id }} · {{ p.difficulty }} · {{ p.sessions }} sessões</span>
                <h2>{{ p.title }}</h2>
              </div>
              <button class="modal-close" (click)="fecharModal()" type="button">✕</button>
            </header>

            <div class="modal-body">
              <section class="modal-sec">
                <h4>🎯 O Problema Real</h4>
                <p>{{ p.problem }}</p>
              </section>

              <section class="modal-sec">
                <h4>💡 Por que Construir</h4>
                <p>{{ p.why }}</p>
              </section>

              <section class="modal-sec">
                <h4>🏗️ Arquitetura & Fluxo</h4>
                <div class="flow-pill-row">
                  @for (step of p.architecture; track step) {
                    <span class="flow-step">{{ step }}</span>
                  }
                </div>
              </section>

              <section class="modal-sec">
                <h4>📋 Roteiro de Execução</h4>
                <ol class="steps-list">
                  @for (st of p.steps; track st) {
                    <li>{{ st }}</li>
                  }
                </ol>
              </section>

              <section class="modal-sec">
                <h4>✅ Critérios de Aceite</h4>
                <ul class="checks-list">
                  @for (ac of p.acceptance; track ac) {
                    <li>{{ ac }}</li>
                  }
                </ul>
              </section>

              <section class="modal-sec">
                <h4>⚠️ Onde Quebra (Falhas Provocadas)</h4>
                <ul class="fail-list">
                  @for (f of p.failures; track f) {
                    <li>{{ f }}</li>
                  }
                </ul>
              </section>

              <section class="modal-sec">
                <h4>📚 Teoria Vinculada no Acervo</h4>
                <div class="teoria-links">
                  @for (t of p.teoria; track t.doc) {
                    <a [routerLink]="t.rota" class="teoria-link" (click)="fecharModal()">
                      <i>📖</i> <b>{{ t.label }}:</b> {{ t.doc }}
                    </a>
                  }
                </div>
              </section>
            </div>

            <footer class="modal-foot">
              <button
                class="btn-modal-action"
                (click)="toggleDone(p.id)"
                type="button"
              >
                {{ isDone(p.id) ? 'Desmarcar Concluído' : 'Marcar Projeto como Concluído (+100 XP)' }}
              </button>
              <button class="btn-modal-secondary" (click)="fecharModal()" type="button">
                Fechar
              </button>
            </footer>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .lab-shell {
      max-width: 1280px;
      margin: 0 auto;
      padding: 32px 24px 80px;
      color: var(--ink);
    }
    .top-nav {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 20px;
    }
    .back-link {
      font-size: 0.85rem;
      color: var(--cyan);
      text-decoration: none;
    }
    .badge-lab {
      font: 700 0.65rem "Cascadia Code", monospace;
      text-transform: uppercase;
      background: #bd93f925;
      color: var(--purple);
      padding: 3px 8px;
      border-radius: 6px;
      border: 1px solid #bd93f940;
    }
    .lab-hero h1 {
      font-size: 2.6rem;
      margin: 0 0 12px;
      color: var(--ink);
    }
    .lede {
      font-size: 1.05rem;
      color: var(--muted);
      max-width: 780px;
      margin: 0 0 28px;
      line-height: 1.5;
    }
    .progress-bar-wrap {
      background: #1e1f29;
      border: 1px solid var(--line2);
      border-radius: 14px;
      padding: 16px 20px;
      margin-bottom: 32px;
    }
    .pb-header {
      display: flex;
      justify-content: space-between;
      font-size: 0.86rem;
      margin-bottom: 8px;
    }
    .xp-val {
      color: var(--teal);
      font-family: "Cascadia Code", monospace;
      font-weight: 700;
    }
    .pb-track {
      height: 8px;
      background: #282a36;
      border-radius: 999px;
      overflow: hidden;
    }
    .pb-fill {
      height: 100%;
      background: linear-gradient(90deg, var(--cyan), var(--teal));
      border-radius: 999px;
      transition: width 0.3s ease;
    }
    .controls-panel {
      background: #1e1f29;
      border: 1px solid var(--line);
      border-radius: 16px;
      padding: 20px;
      margin-bottom: 32px;
    }
    .search-box input {
      width: 100%;
      background: #282a36;
      border: 1px solid var(--line2);
      color: var(--ink);
      padding: 12px 16px;
      border-radius: 10px;
      font-size: 0.9rem;
      outline: none;
      margin-bottom: 16px;
    }
    .search-box input:focus {
      border-color: var(--cyan);
    }
    .filter-row {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .filter-group {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
    }
    .grp-label {
      font-size: 0.76rem;
      color: var(--muted);
      text-transform: uppercase;
      font-weight: 700;
      margin-right: 4px;
    }
    .filter-chip {
      background: #282a36;
      border: 1px solid var(--line);
      color: var(--muted);
      font-size: 0.78rem;
      padding: 5px 12px;
      border-radius: 999px;
      cursor: pointer;
      transition: all 0.2s;
    }
    .filter-chip:hover {
      background: #343746;
      color: var(--ink);
    }
    .filter-chip.active {
      background: var(--purple);
      color: #282a36;
      font-weight: 700;
      border-color: var(--purple);
    }
    .projects-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(360px, 1fr));
      gap: 20px;
    }
    .p-card {
      background: #1e1f29;
      border: 1px solid var(--line);
      border-radius: 16px;
      padding: 22px;
      display: flex;
      flex-direction: column;
      transition: transform 0.2s, border-color 0.2s;
    }
    .p-card:hover {
      transform: translateY(-2px);
      border-color: var(--cyan);
    }
    .p-card.is-done {
      border-color: var(--teal);
      background: radial-gradient(100% 120% at 50% 0%, #50fa7b10, #1e1f29);
    }
    .p-card-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
    }
    .p-id {
      font: 700 0.8rem "Cascadia Code", monospace;
      color: var(--cyan);
    }
    .p-diff {
      font-size: 0.68rem;
      text-transform: uppercase;
      padding: 2px 7px;
      border-radius: 4px;
      background: #282a36;
      color: var(--muted);
    }
    .p-diff[data-diff="Fundação"] { color: var(--teal); }
    .p-diff[data-diff="Intermediário"] { color: var(--gold); }
    .p-diff[data-diff="Avançado"] { color: var(--rose); }
    .btn-toggle-done {
      background: transparent;
      border: 1px solid var(--line2);
      color: var(--muted);
      font-size: 0.72rem;
      padding: 3px 8px;
      border-radius: 6px;
      cursor: pointer;
    }
    .btn-toggle-done:hover {
      border-color: var(--teal);
      color: var(--teal);
    }
    .p-card.is-done .btn-toggle-done {
      background: var(--teal);
      color: #1e1f29;
      border-color: var(--teal);
      font-weight: 700;
    }
    .p-card h3 {
      font-size: 1.15rem;
      margin: 0 0 8px;
      color: var(--ink);
    }
    .p-summary {
      font-size: 0.84rem;
      color: var(--muted);
      line-height: 1.4;
      flex: 1;
      margin: 0 0 16px;
    }
    .p-stack {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 18px;
    }
    .stack-tag {
      font-size: 0.68rem;
      background: #282a36;
      color: var(--muted);
      padding: 2px 7px;
      border-radius: 4px;
      font-family: "Cascadia Code", monospace;
    }
    .p-card-foot {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-top: 1px solid var(--line);
      padding-top: 14px;
    }
    .sessions-tag {
      font-size: 0.74rem;
      color: var(--muted);
    }
    .btn-open-modal {
      background: transparent;
      border: 0;
      color: var(--purple);
      font-weight: 700;
      font-size: 0.82rem;
      cursor: pointer;
      padding: 0;
    }
    .btn-open-modal:hover {
      color: var(--cyan);
      text-decoration: underline;
    }
    /* MODAL */
    .modal-backdrop {
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.75);
      backdrop-filter: blur(4px);
      z-index: 1000;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .modal-window {
      background: #1e1f29;
      border: 1px solid var(--line2);
      border-radius: 18px;
      width: min(840px, 100%);
      max-height: 85vh;
      display: flex;
      flex-direction: column;
      box-shadow: 0 24px 60px rgba(0,0,0,0.6);
    }
    .modal-head {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      padding: 20px 24px;
      border-bottom: 1px solid var(--line);
    }
    .p-id-lg {
      font: 700 0.72rem "Cascadia Code", monospace;
      color: var(--cyan);
      text-transform: uppercase;
      display: block;
      margin-bottom: 4px;
    }
    .modal-head h2 {
      margin: 0;
      font-size: 1.5rem;
      color: var(--ink);
    }
    .modal-close {
      background: transparent;
      border: 0;
      color: var(--muted);
      font-size: 1.3rem;
      cursor: pointer;
    }
    .modal-body {
      padding: 20px 24px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    .modal-sec h4 {
      margin: 0 0 6px;
      font-size: 0.95rem;
      color: var(--cyan);
    }
    .modal-sec p {
      margin: 0;
      font-size: 0.88rem;
      color: var(--muted);
      line-height: 1.45;
    }
    .flow-pill-row {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }
    .flow-step {
      background: #282a36;
      border: 1px solid var(--line);
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 0.76rem;
      font-family: "Cascadia Code", monospace;
      color: var(--gold);
    }
    .steps-list, .checks-list, .fail-list {
      margin: 0;
      padding-left: 20px;
      font-size: 0.85rem;
      color: var(--muted);
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .fail-list li { color: var(--rose); }
    .teoria-links {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .teoria-link {
      background: #282a36;
      border: 1px solid var(--line);
      padding: 8px 12px;
      border-radius: 8px;
      color: var(--ink);
      font-size: 0.82rem;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .teoria-link:hover {
      border-color: var(--cyan);
      color: var(--cyan);
    }
    .modal-foot {
      padding: 16px 24px;
      border-top: 1px solid var(--line);
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }
    .btn-modal-action {
      background: var(--purple);
      border: 0;
      color: #1e1f29;
      font-weight: 700;
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
    }
    .btn-modal-secondary {
      background: #282a36;
      border: 1px solid var(--line2);
      color: var(--muted);
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
    }
  `]
})
export class ProjetosLabComponent {
  private storage: StorageService;

  readonly filtroArea = signal<string>('todas');
  readonly filtroDificuldade = signal<string>('todas');
  readonly filtroTexto = signal<string>('');
  readonly projetoModal = signal<ProjetoLab | null>(null);
  readonly concluidos = signal<string[]>([]);

  constructor() {
    try {
      this.storage = inject(StorageService);
    } catch {
      this.storage = new StorageService();
    }
    this.concluidos.set(this.storage.get<string[]>('lab_projetos_concluidos', []));
  }

  readonly concluidosCount = computed(() => this.concluidos().length);
  readonly progressoPct = computed(() => {
    return Math.round((this.concluidosCount() / this.PROJETOS.length) * 100);
  });

  readonly projetosFiltrados = computed(() => {
    const area = this.filtroArea();
    const diff = this.filtroDificuldade();
    const texto = this.filtroTexto().toLowerCase().trim();

    return this.PROJETOS.filter(p => {
      if (area !== 'todas' && p.area !== area) return false;
      if (diff !== 'todas' && p.difficulty !== diff) return false;
      if (texto) {
        const matchesTitle = p.title.toLowerCase().includes(texto);
        const matchesSummary = p.summary.toLowerCase().includes(texto);
        const matchesStack = p.stack.some(s => s.toLowerCase().includes(texto));
        if (!matchesTitle && !matchesSummary && !matchesStack) return false;
      }
      return true;
    });
  });

  isDone(id: string): boolean {
    return this.concluidos().includes(id);
  }

  toggleDone(id: string): void {
    const list = this.concluidos();
    const updated = list.includes(id)
      ? list.filter(item => item !== id)
      : [...list, id];

    this.concluidos.set(updated);
    this.storage.set('lab_projetos_concluidos', updated);
  }

  abrirModal(p: ProjetoLab): void {
    this.projetoModal.set(p);
  }

  fecharModal(): void {
    this.projetoModal.set(null);
  }

  readonly PROJETOS: ProjetoLab[] = [
    {
      id: 'J01',
      area: 'java',
      difficulty: 'Fundação',
      sessions: 5,
      title: 'Cofre CLI sem Centavos Mágicos',
      summary: 'Registre entradas, despesas e reservas sem double, sem framework e sem esconder regra em if solto.',
      problem: 'Uma pessoa guarda o que sobra, mas não sabe quanto pode separar sem misturar reserva e contas. O sistema precisa calcular valores monetários de forma exata.',
      why: 'Dinheiro expõe rápido os vícios de modelagem: arredondamento implícito, estado mutável e datas ambíguas. Fortalece o Java antes das abstrações do Spring.',
      learns: ['BigDecimal com escala 2 e arredondamento', 'Records e Value Objects para Money e Category', 'Escrita atômica em arquivo via NIO'],
      architecture: ['Terminal CLI', 'Command Parser', 'Domain Value Objects', 'Atomic File Writer'],
      stack: ['Java 21', 'Maven Wrapper', 'JUnit 5', 'NIO.2'],
      steps: ['Modelar Money com scale explícita', 'Criar casos de uso RegisterIncome e ReserveMoney', 'Implementar escrita atômica com Files.move'],
      acceptance: ['Nenhum cálculo monetário usa double ou float', 'Arquivo parcialmente escrito não corrompe o estado anterior'],
      tests: ['Teste de unidade de Money', 'Teste de integração com CLI'],
      failures: ['Matar o processo durante a escrita do arquivo', 'Comparar 0.1 + 0.2 em double vs BigDecimal'],
      questions: ['Por que BigDecimal(String) difere de BigDecimal(double)?'],
      teoria: [{ label: 'Java 21', doc: 'Records, Imutabilidade e Precisão Monetária', rota: '/trilhas/java' }]
    },
    {
      id: 'J02',
      area: 'java',
      difficulty: 'Intermediário',
      sessions: 7,
      title: 'Importador de Extratos Resistente',
      summary: 'Leia arquivos grandes com NIO, normalize formatos e paralelize com Virtual Threads sem perder ordem ou memória.',
      problem: 'Extratos CSV de bancos chegam com milhões de linhas e separadores distintos. O sistema não pode sofrer OOM nem duplicar transações.',
      why: 'I/O real mistura parsing, throughput, backpressure e observabilidade. Melhor laboratório de concorrência que threads genéricas.',
      learns: ['Pipeline producer/consumer com buffer limitado', 'Virtual Threads vs Carrier Threads', 'Deduplicação por hash estável'],
      architecture: ['Files NIO', 'Stream Reader', 'Normalizer', 'Virtual Threads Pool', 'Quarantine'],
      stack: ['Java 21', 'Virtual Threads', 'NIO.2', 'JFR', 'JUnit 5'],
      steps: ['Contrato BankStatementParser', 'Gerador de 1 milhão de linhas para teste de carga', 'Pipeline com Virtual Threads e deduplicação'],
      acceptance: ['Processa 1M linhas com heap máximo restrito', 'Linha inválida vai para quarantine sem abortar o lote'],
      tests: ['Teste de concorrência com 100 repetições', 'Benchmark sequencial vs Virtual Threads'],
      failures: ['Writer artificialmente lento para testar backpressure', 'Interrupção forçada no meio do streaming'],
      questions: ['Quando Virtual Threads não aumentam o throughput de CPU?'],
      teoria: [{ label: 'Java 21', doc: 'Concorrência e Virtual Threads (Project Loom)', rota: '/trilhas/java' }]
    },
    {
      id: 'J03',
      area: 'java',
      difficulty: 'Avançado',
      sessions: 9,
      title: 'Ledger Financeiro JDBC sem ORM',
      summary: 'Construa um livro-razão com SQL puro, pool de conexões, transações ACID e concorrência observável.',
      problem: 'Transferências não podem criar dinheiro nem aplicar duas vezes. O estado precisa ser auditável mesmo quando duas conexões concorrem.',
      why: 'ORMs escondem o que o banco faz. JDBC força você a dominar conexões, isolamento, locks e aritmética de pool.',
      learns: ['JDBC com PreparedStatement e Batch', 'HikariCP tuning e saturação', 'Transações ACID e SELECT FOR UPDATE'],
      architecture: ['Service', 'JDBC Repositories', 'HikariCP', 'PostgreSQL', 'Audit Query'],
      stack: ['Java 21', 'JDBC', 'HikariCP', 'PostgreSQL', 'Flyway', 'Testcontainers'],
      steps: ['Criar migrations SQL com constraints estritas', 'Implementar transferência atômica com débito e crédito balanceados', 'Subir PostgreSQL real em Testcontainers'],
      acceptance: ['Cada transferência cria exatamente 2 lançamentos com soma zero', 'Idempotency key repetida reaproveita o resultado'],
      tests: ['Dois saques concorrentes contra o mesmo saldo', 'Saturação do pool com mais threads que conexões'],
      failures: ['Pool de 2 conexões sob 50 threads concorrentes', 'Deadlock por ordem inversa de travamento'],
      questions: ['Por que saldo derivado é mais seguro que coluna mutável?'],
      teoria: [{ label: 'Java 21', doc: 'HikariCP, Conexões e Transações JDBC', rota: '/trilhas/java' }]
    },
    {
      id: 'S01',
      area: 'spring',
      difficulty: 'Intermediário',
      sessions: 7,
      title: 'API de Orçamento com SQL Visível',
      summary: 'Exponha o domínio por HTTP com Spring MVC, validação Bean Validation, JdbcTemplate e erros previsíveis.',
      problem: 'O cliente precisa registrar lançamentos via REST. A API deve fornecer contratos estáveis, paginação keyset e mensagens de erro padronizadas.',
      why: 'Acompanhar a requisição desde o socket HTTP até o banco de dados sem mágica de ORM.',
      learns: ['DispatcherServlet e Argument Resolvers', 'Problem Details (RFC 7807)', 'Paginação keyset por ID + data'],
      architecture: ['HTTP Client', 'Filter Chain', 'Controller', 'Use Case', 'JdbcTemplate', 'PostgreSQL'],
      stack: ['Java 21', 'Spring Boot 3', 'Spring MVC', 'JdbcTemplate', 'Testcontainers'],
      steps: ['Criar contratos REST POST e GET', 'Mapear DTOs isolados do domínio', 'Testes de integração com Testcontainers'],
      acceptance: ['Controller não acessa repositório diretamente', 'Erros seguem o padrão Problem Details RFC 7807'],
      tests: ['MockMvc para validação de campos', 'Teste de paginação sob inserções concorrentes'],
      failures: ['JSON gigante para testar limites de payload', 'Queda do banco durante a chamada'],
      questions: ['Por que paginação keyset é superior a offset em tabelas grandes?'],
      teoria: [{ label: 'Spring Boot', doc: 'IoC, MVC e Ciclo de Vida da Requisição', rota: '/trilhas/spring' }]
    },
    {
      id: 'S02',
      area: 'spring',
      difficulty: 'Avançado',
      sessions: 9,
      title: 'Transferência sob Corrida & AOP',
      summary: 'Faça transações, proxies CGLIB e idempotência sobreviverem a chamadas concorrentes e respostas de rede perdidas.',
      problem: 'Duas requisições de pagamento chegam ao mesmo tempo e uma terceira é repetida por timeout de cliente.',
      why: 'Usar @Transactional sem entender proxies e propagation cria bugs graves de concorrência.',
      learns: ['Proxy CGLIB e armadilha de auto-invocação', 'Idempotency Key com tabela de deduplicação', 'Tratamento de deadlock com retry exponencial'],
      architecture: ['HTTP Clients', 'Idempotency Filter', 'Service CGLIB Proxy', 'PostgreSQL Locks'],
      stack: ['Java 21', 'Spring Boot 3', 'Spring Tx', 'PostgreSQL', 'Testcontainers'],
      steps: ['Reproduzir falha com CyclicBarrier em 2 threads', 'Aplicar SELECT FOR UPDATE', 'Persistir idempotência na mesma transação'],
      acceptance: ['Saldo permanece íntegro sob 100 requisições simultâneas', 'Mesma chave com mesmo payload reaproveita resposta'],
      tests: ['CyclicBarrier para colisão determinística', 'Auto-invocação comprovada em teste'],
      failures: ['Remover o proxy e constatar perda de atomicidade', 'Chamar método transacional via this'],
      questions: ['Por que o Spring ignora @Transactional em chamadas internas?'],
      teoria: [{ label: 'Spring Boot', doc: '@Transactional e a Pegadinha da Auto-Invocação', rota: '/trilhas/spring' }]
    },
    {
      id: 'S03',
      area: 'spring',
      difficulty: 'Avançado',
      sessions: 8,
      title: 'Sala de Incidente Spring & Observabilidade',
      summary: 'Instrumente uma API com Actuator e Micrometer, provoque vazamento de pool e investigue com telemetria.',
      problem: 'A API fica lenta com picos de latência p99 e alguns requests recebem 503 enquanto a CPU parece normal.',
      why: 'Confiabilidade exige formular hipóteses e correlacionar métricas RED com thread dumps.',
      learns: ['Actuator e Micrometer', 'OpenTelemetry e Correlation IDs', 'Diagnóstico de threads bloqueadas em pool'],
      architecture: ['Load Generator', 'Spring API', 'Micrometer', 'Prometheus/Grafana', 'Toxiproxy'],
      stack: ['Java 21', 'Spring Boot 3', 'Actuator', 'Micrometer', 'Prometheus', 'Toxiproxy'],
      steps: ['Instrumentar métricas RED', 'Simular lentidão com Toxiproxy', 'Capturar thread dump e analisar saturação'],
      acceptance: ['Métricas revelam aumento do p99 antes de alarmes genéricos', 'Graceful shutdown drena tráfego sem erro 502'],
      tests: ['Teste de carga com injeção de latência', 'Validação de correlationId em todos os logs'],
      failures: ['Esgotamento forçado do pool HikariCP', 'Latência de 3 segundos injetada no banco'],
      questions: ['Por que a média esconde problemas que o percentil p99 revela?'],
      teoria: [{ label: 'Spring Boot', doc: 'Testcontainers e Telemetria em Produção', rota: '/trilhas/spring' }]
    },
    {
      id: 'R01',
      area: 'rabbit',
      difficulty: 'Intermediário',
      sessions: 6,
      title: 'Notificador por Tópico no RabbitMQ',
      summary: 'Publique notificações assíncronas com Topic Exchanges, bindings flexíveis e confirmações de entrega (Publisher Confirms).',
      problem: 'Eventos de múltiplos sistemas precisam ser entregues a canais distintos (email, push, webhook) sem acoplamento direto.',
      why: 'Entender a mecânica do AMQP onde produtores nunca publicam diretamente em filas.',
      learns: ['Topic Exchanges e curingas * e #', 'Publisher Confirms com confirmação assíncrona', 'Tratamento de mensagens não roteadas com Mandatory flag'],
      architecture: ['Publisher', 'Topic Exchange', 'Routing Keys', 'Queues × N', 'Consumers'],
      stack: ['Java 21', 'Spring AMQP', 'RabbitMQ', 'Testcontainers'],
      steps: ['Configurar Exchange de Notificações', 'Criar filas de email e webhook com routing keys', 'Implementar Publisher Confirms'],
      acceptance: ['Mensagem com chave sem rota dispara retorno via mandatory', 'Publicação garante confirmação do broker'],
      tests: ['Teste com RabbitMQ em Testcontainers', 'Validação de roteamento por máscara'],
      failures: ['Publicar com routing key inválida', 'Derrubar o broker durante envio em lote'],
      questions: ['Qual a diferença entre Fanout e Topic Exchange?'],
      teoria: [{ label: 'Mensageria', doc: 'Topologia RabbitMQ: Exchanges e Bindings', rota: '/trilhas/mensageria' }]
    },
    {
      id: 'R02',
      area: 'rabbit',
      difficulty: 'Avançado',
      sessions: 8,
      title: 'Consumidor Resiliente & Dead Letter Queue (DLQ)',
      summary: 'Processe mensagens com concorrência justa, retentativas com backoff exponencial e desvio seguro de poison pills para DLQ.',
      problem: 'Uma mensagem com formato corrompido entra na fila e causa loop infinito de NACK e requeue, travando todos os workers.',
      why: 'Tratamento de exceções em filas distribuídas exige estratégias contra colapso de nós.',
      learns: ['Manual Acknowledgment (ACK/NACK)', 'Prefetch Count justo para balanceamento', 'Dead Letter Exchange (DLX) e TTL'],
      architecture: ['Main Queue', 'Spring Listener', 'Retry Interceptor', 'DLX', 'Dead Letter Queue'],
      stack: ['Java 21', 'Spring AMQP', 'RabbitMQ', 'Testcontainers'],
      steps: ['Configurar prefetchCount = 5', 'Implementar Dead Letter Exchange', 'Criar consumidor de auditoria para a DLQ'],
      acceptance: ['Mensagem venenosa é desviada para a DLQ após 3 tentativas', 'Workers saudáveis continuam consumindo mensagens normais'],
      tests: ['Injeção de poison pill com assert na DLQ', 'Teste de distribuição de carga entre 3 workers'],
      failures: ['Desativar a DLQ e observar o loop de NACK', 'Configurar prefetch = 1000 sob worker lento'],
      questions: ['Por que requeue=true em exceção não recuperável é perigoso?'],
      teoria: [{ label: 'Mensageria', doc: 'Dead Letter Queues e Backoff Exponencial', rota: '/trilhas/mensageria' }]
    },
    {
      id: 'R03',
      area: 'rabbit',
      difficulty: 'Avançado',
      sessions: 10,
      title: 'OrderFlow: Transactional Outbox Pattern',
      summary: 'Elimine inconsistências de Dual-Write salvando o evento na transação do banco e despachando de forma garantida.',
      problem: 'Ao aprovar um pedido, o sistema grava no PostgreSQL e publica na fila. Se o broker reiniciar no milissegundo seguinte, a mensagem é perdida.',
      why: 'É o padrão canônico da indústria para comunicação assíncrona com garantia At-Least-Once.',
      learns: ['Transactional Outbox com tabela outbox', 'Polling Publisher com SELECT FOR UPDATE SKIP LOCKED', 'Consumidor idempotente com chave única'],
      architecture: ['Order Service', 'PostgreSQL (Orders + Outbox)', 'Outbox Dispatcher', 'RabbitMQ', 'Payment Worker'],
      stack: ['Java 21', 'Spring Boot 3', 'Spring AMQP', 'PostgreSQL', 'Testcontainers'],
      steps: ['Criar tabela outbox com colunas status e payload', 'Gravar pedido e outbox na mesma transação', 'Implementar dispatcher com polling seguro'],
      acceptance: ['Queda do broker durante o checkout não perde nenhum pedido', 'Consumidor deduplica mensagens repetidas'],
      tests: ['Teste de integração simulando crash do broker', 'Validação de consistência estrita de inventário'],
      failures: ['Matar o RabbitMQ no meio do fluxo', 'Injetar mensagens duplicadas no consumidor'],
      questions: ['Como o Outbox Pattern resolve o problema do Dual-Write?'],
      teoria: [{ label: 'Mensageria', doc: 'Transactional Outbox Pattern e Fim do Dual-Write', rota: '/trilhas/mensageria' }]
    },
    {
      id: 'C01',
      area: 'cloud',
      difficulty: 'Intermediário',
      sessions: 6,
      title: 'Storage Agnóstico: Portas e Adaptadores',
      summary: 'Implemente uma porta de armazenamento de arquivos com adaptadores para disco local, MinIO e S3 sem vazar SDK no domínio.',
      problem: 'A aplicação precisa fazer upload de anexos sem amarrar a regra de negócio a um provedor específico de nuvem.',
      why: 'Ports & Adapters (Hexagonal Architecture) protege o core da dependência de infraestrutura.',
      learns: ['Interface ObjectStorage pura', 'Adaptador S3/MinIO via AWS SDK v2', 'Testes de integração com MinIO em container'],
      architecture: ['Core Use Case', 'ObjectStorage Port', 'LocalDisk Adapter', 'S3/MinIO Adapter'],
      stack: ['Java 21', 'Spring Boot 3', 'AWS SDK v2', 'MinIO', 'Testcontainers'],
      steps: ['Definir interface de domínio com put, get e delete', 'Implementar adaptador para MinIO', 'Configurar injeção condicional por profile'],
      acceptance: ['O módulo de domínio compila sem o SDK de cloud no classpath', 'Troca de provedor ocorre apenas via application.yml'],
      tests: ['Teste do caso de uso com mock do storage', 'Teste real do adaptador contra MinIO em container'],
      failures: ['Tentar retornar tipos do SDK diretamente na porta', 'Simular falha de rede no upload'],
      questions: ['O que é a Regra da Dependência na Arquitetura Hexagonal?'],
      teoria: [{ label: 'Nuvem', doc: 'VPC, Armazenamento de Objetos e Multicloud', rota: '/trilhas/nuvem' }]
    },
    {
      id: 'C02',
      area: 'cloud',
      difficulty: 'Intermediário',
      sessions: 7,
      title: 'Segredos e Identidade sem Acoplamento',
      summary: 'Carregue credenciais dinamicamente via variáveis de ambiente e cofres de segredos sem embutir senhas em imagens Docker.',
      problem: 'Credenciais estáticas commitadas em repositórios ou embutidas em jars são alvos primários de vazamento.',
      why: 'Segurança e governança conforme o 12-Factor App exigem separação estrita entre configuração e código.',
      learns: ['Configuração externalizada no Spring', 'Sanitização de logs e Actuator /env', 'Princípio de Menor Privilégio'],
      architecture: ['Environment', 'Spring Environment', 'Secret Sanitizer', 'Protected Service'],
      stack: ['Java 21', 'Spring Boot 3', 'Docker', 'Vault/LocalStack'],
      steps: ['Configurar mascaramento de propriedades sensíveis', 'Proibir chaves hardcoded via linter', 'Testar carregamento seguro'],
      acceptance: ['Nenhum segredo aparece descriptografado em logs ou endpoints', 'Aplicação recusa subir se a chave estiver ausente'],
      tests: ['Teste de inicialização sem variáveis obrigatórias', 'Inspeção automática do actuator/env'],
      failures: ['Expor heap dump simulado para checar presença de chaves', 'Iniciar com segredo vazio'],
      questions: ['Por que credenciais estáticas violam a segurança em nuvem?'],
      teoria: [{ label: 'Nuvem', doc: 'IAM e Princípio do Menor Privilégio', rota: '/trilhas/nuvem' }]
    },
    {
      id: 'C03',
      area: 'cloud',
      difficulty: 'Avançado',
      sessions: 8,
      title: '12-Factor App & Resiliência em Kubernetes',
      summary: 'Empacote a aplicação para o Kubernetes com Probes configuradas, graceful shutdown e limites estritos de CPU e RAM.',
      problem: 'Ao fazer deploy no cluster, Pods morrem durante a inicialização ou derrubam conexões de usuários no encerramento.',
      why: 'Desenvolver para nuvem exige aderência ao ciclo de vida de containers orquestrados.',
      learns: ['Liveness vs Readiness vs Startup Probes', 'Graceful Shutdown de conexões HTTP', 'Memory Limits e prevenção de OOMKilled 137'],
      architecture: ['Kubelet', 'Health Probes', 'Spring Actuator', 'Pod Lifecycle', 'cgroups'],
      stack: ['Java 21', 'Spring Boot 3', 'Docker', 'Kubernetes / Kind', 'Actuator'],
      steps: ['Configurar probes nativas no application.properties', 'Ajustar server.shutdown=graceful', 'Criar manifesto K8s com requests e limits'],
      acceptance: ['Deploy em rolling update tem zero requisições 502/504 caídas', 'Startup probe concede até 60s para subir sem morte prematura'],
      tests: ['Teste de carga durante rolling update no Kind', 'Teste de saturação de memória'],
      failures: ['Colocar checagem de banco no liveness probe e derrubar o banco', 'Extrapolar o memory limit do cgroup'],
      questions: ['Qual a diferença fundamental entre Liveness e Readiness Probe?'],
      teoria: [{ label: 'Docker & K8s', doc: 'Health Probes sem Cascata e Gestão de Recursos', rota: '/trilhas/docker-kubernetes' }]
    },
    {
      id: 'A01',
      area: 'aws',
      difficulty: 'Intermediário',
      sessions: 7,
      title: 'Upload Direto com S3 Presigned URLs',
      summary: 'Gere URLs pré-assinadas temporárias para upload direto do cliente para o S3 sem sobrecarregar a memória da API.',
      problem: 'Clientes fazem upload de arquivos de 500 MB. A API Spring sofre pico de memória e thread starvation agindo como proxy de bytes.',
      why: 'Serviços de backend devem orquestrar autorização, nunca transportar bytes pesados de arquivos.',
      learns: ['AWS S3 Presigned URLs com expiração curta', 'Validação de metadados e tamanho máximo de arquivo', 'LocalStack para emulação AWS local'],
      architecture: ['Frontend', 'Spring Auth API', 'Presigned URL Generator', 'AWS S3 (LocalStack)'],
      stack: ['Java 21', 'Spring Boot 3', 'AWS SDK v2 S3', 'LocalStack', 'Testcontainers'],
      steps: ['Criar endpoint /uploads/presign com JWT', 'Gerar URL temporária PUT com validade de 5 minutos', 'Testar upload direto com curl'],
      acceptance: ['A API Spring consome menos de 50 MB de RAM durante uploads de 1 GB', 'URL expira e retorna 403 após o prazo'],
      tests: ['Teste com LocalStack em Testcontainers', 'Upload bem-sucedido e rejeição de URL expirada'],
      failures: ['Usar URL após a expiração', 'Tentar enviar arquivo com tamanho superior ao autorizado'],
      questions: ['Por que a API nunca deve ser proxy de bytes em uploads grandes?'],
      teoria: [{ label: 'Nuvem', doc: 'Armazenamento de Objetos e Presigned URLs', rota: '/trilhas/nuvem' }]
    },
    {
      id: 'A02',
      area: 'aws',
      difficulty: 'Avançado',
      sessions: 8,
      title: 'Processamento de Arquivos por Eventos com SQS',
      summary: 'Receba notificações de upload via S3 EventBridge, enfileire no SQS e processe de forma assíncrona e desacoplada.',
      problem: 'O pós-processamento de imagens (redimensionamento e OCR) é pesado e não pode bloquear a experiência do usuário.',
      why: 'Arquiteturas orientadas a eventos (EDA) absorvem picos de carga com filas gerenciadas.',
      learns: ['S3 ObjectCreated Events', 'SQS com Visibility Timeout e Dead Letter Queue', 'Consumo em lotes com Spring Cloud AWS'],
      architecture: ['S3 Bucket', 'EventBridge', 'SQS Queue', 'Worker Consumer', 'Database'],
      stack: ['Java 21', 'Spring Boot 3', 'AWS SDK v2 SQS', 'LocalStack', 'Testcontainers'],
      steps: ['Configurar notificação no bucket S3', 'Criar fila SQS e inscrever no evento', 'Implementar worker com ack manual'],
      acceptance: ['Upload dispara processamento assíncrono em menos de 2 segundos', 'Falha no processamento devolve mensagem para retry'],
      tests: ['Teste integrado com LocalStack', 'Validação de visibilidade e DLQ'],
      failures: ['Worker lento excedendo o Visibility Timeout', 'Arquivo inexistente no bucket'],
      questions: ['Como o Visibility Timeout do SQS previne perda de mensagens?'],
      teoria: [{ label: 'Mensageria', doc: 'Filas, DLQs e Arquiteturas Event-Driven', rota: '/trilhas/mensageria' }]
    },
    {
      id: 'A03',
      area: 'aws',
      difficulty: 'Avançado',
      sessions: 9,
      title: 'Esteira ECS Fargate & FinOps com Terraform',
      summary: 'Provisione infraestrutura segura como código com Terraform, alertas de custo e deploy de containers sem gerenciar VMs.',
      problem: 'Subir infraestrutura manualmente pelo console AWS causa desvios de configuração, brechas de segurança e sustos na fatura.',
      why: 'Infraestrutura como Código (IaC) e FinOps são competências essenciais de engenharia moderna.',
      learns: ['Terraform modular para VPC e ECS Fargate', 'AWS Budgets com alertas de limite de custo', 'IAM Roles com menor privilégio'],
      architecture: ['Terraform IaC', 'VPC 3-Tiers', 'ALB', 'ECS Fargate Tasks', 'AWS Budgets'],
      stack: ['Java 21', 'Docker', 'Terraform', 'AWS Fargate', 'LocalStack'],
      steps: ['Escrever módulos Terraform de rede', 'Configurar AWS Budgets e alertas por email', 'Script automatizado de teardown completo'],
      acceptance: ['Toda a infraestrutura é criada e destruída com um único comando', 'Alerta de orçamento é criado antes do primeiro recurso'],
      tests: ['Terraform validate e plan automatizado', 'Auditoria de recursos remanescentes pós-destroy'],
      failures: ['Verificar se sobras de volumes ou IPs elásticos ficaram ativos', 'Simular violação de limite de gasto'],
      questions: ['Por que o teardown em script é indispensável em laboratórios?'],
      teoria: [{ label: 'Nuvem', doc: 'Multicloud, FinOps e Automação', rota: '/trilhas/nuvem' }]
    },
    {
      id: 'I01',
      area: 'ai',
      difficulty: 'Intermediário',
      sessions: 6,
      title: 'ChatClient Corporativo com Spring AI',
      summary: 'Conecte sua API Spring Boot a modelos de linguagem locais (Ollama) ou nuvem com fallback, streaming e timeouts estritos.',
      problem: 'Integrar LLMs diretamente via HTTP gera código frágil, falta de tipagem e falhas quando o provedor de IA oscila.',
      why: 'Spring AI padroniza a integração com IA de forma análoga a bancos de dados com Spring Data.',
      learns: ['Spring AI ChatClient e Prompt Templates', 'Streaming de respostas com Server-Sent Events (SSE)', 'Circuit Breaker em torno da chamada de IA'],
      architecture: ['HTTP Client', 'Controller SSE', 'Spring AI ChatClient', 'Local Ollama / OpenAI', 'Fallback Handler'],
      stack: ['Java 21', 'Spring Boot 3', 'Spring AI', 'Ollama / Testcontainers'],
      steps: ['Configurar starter do Spring AI', 'Implementar endpoint reativo de streaming', 'Adicionar fallback com mensagem pré-fabricada sob timeout'],
      acceptance: ['Respostas com streaming enviam tokens sem travar a thread', 'Queda do modelo externo ativa fallback gracioso em 1 segundo'],
      tests: ['Teste de integração com Ollama containerizado', 'Teste de timeout de prompt'],
      failures: ['Modelo demorando 30 segundos para responder', 'Provedor retornando erro 429 de Rate Limit'],
      questions: ['Por que chamadas de IA exigem timeouts muito maiores que APIs normais?'],
      teoria: [{ label: 'Inteligência Artificial', doc: 'LLMs, Tokens e Spring AI', rota: '/trilhas/ia' }]
    },
    {
      id: 'I02',
      area: 'ai',
      difficulty: 'Intermediário',
      sessions: 7,
      title: 'Extração Estruturada com JSON Schema Estrito',
      summary: 'Transforme textos não estruturados (contratos, faturas) em Java Records imutáveis com validação formal e zero markdown na resposta.',
      problem: 'LLMs frequentemente devolvem comentários indesejados antes do JSON ou campos com tipos incorretos, quebrando deserializadores.',
      why: 'Constrained Decoding e Structured Outputs garantem determinismo sintático indispensável no backend corporativo.',
      learns: ['Structured Outputs com BeanOutputConverter', 'JSON Schema derivado de Java Records', 'Tratamento de retry tipado em caso de parsing fail'],
      architecture: ['Raw Text Input', 'System Prompt', 'Spring AI Converter', 'Java Record', 'Database'],
      stack: ['Java 21', 'Spring Boot 3', 'Spring AI', 'Jackson', 'Ollama / OpenAI'],
      steps: ['Modelar Record Alvo com anotações de validação', 'Configurar prompt com schema injetado', 'Validar objeto convertido com Bean Validation'],
      acceptance: ['100% das respostas bem-sucedidas são parseadas diretamente no Record', 'Erros de schema disparam exceção tipada de domínio'],
      tests: ['20 execuções repetidas do mesmo texto para validar formato', 'Injeção de texto com dados incompletos'],
      failures: ['Prompt com instruções contraditórias', 'Texto de entrada em idioma não suportado'],
      questions: ['Por que Structured Outputs é superior a usar regex para limpar markdown?'],
      teoria: [{ label: 'Inteligência Artificial', doc: 'Structured Outputs e JSON Schema', rota: '/trilhas/ia' }]
    },
    {
      id: 'I03',
      area: 'ai',
      difficulty: 'Avançado',
      sessions: 9,
      title: 'RAG Corporativo com pgvector & Test Harness',
      summary: 'Construa um pipeline completo de RAG no PostgreSQL com pgvector, busca híbrida e suíte automatizada de avaliação (Evals).',
      problem: 'O modelo alucina respostas sobre documentações técnicas internas da empresa porque elas não existem nos dados de treino públicos.',
      why: 'RAG com base de dados vetorial própria é a arquitetura padrão para estender o conhecimento de LLMs sem treinar modelos.',
      learns: ['Geração e armazenamento de Embeddings', 'Índices HNSW no PostgreSQL pgvector', 'Evals e métricas de fidelidade (Faithfulness) com Test Harness'],
      architecture: ['Document Ingestion', 'Embedding Model', 'PostgreSQL pgvector', 'Hybrid Search', 'Augmented Prompt', 'LLM Judge'],
      stack: ['Java 21', 'Spring Boot 3', 'Spring AI', 'pgvector', 'Testcontainers'],
      steps: ['Configurar extensão pgvector no PostgreSQL', 'Ingerir documentos e indexar com HNSW', 'Criar suíte de testes com 10 perguntas de benchmark'],
      acceptance: ['Respostas citam trechos exatos dos documentos ingeridos', 'Evals automatizados confirmam fidelidade superior a 90%'],
      tests: ['Teste de assertividade com perguntas com resposta conhecida', 'Perguntas sem resposta nos documentos devem responder que não sabem'],
      failures: ['Busca vetorial com documentos de tópicos conflitantes', 'Documento com informações desatualizadas'],
      questions: ['Como o pgvector calcula a proximidade semântica entre textos?'],
      teoria: [{ label: 'Inteligência Artificial', doc: 'RAG, Vector Search e Avaliação Contínua', rota: '/trilhas/ia' }]
    }
  ];
}
