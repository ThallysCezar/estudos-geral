// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { TutorialApiLabComponent } from './tutorial-api.component';

describe('TutorialApiLabComponent', () => {
  let comp: TutorialApiLabComponent;

  beforeEach(() => {
    comp = new TutorialApiLabComponent();
  });

  it('deve instanciar o lab Tutorial API', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Tutorial de APIs de IA');
  });
});
