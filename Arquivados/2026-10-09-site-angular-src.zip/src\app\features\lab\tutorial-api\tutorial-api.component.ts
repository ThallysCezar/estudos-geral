import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-lab-tutorial-api',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/lab/tutorial-api.html" />
  `
})
export class TutorialApiLabComponent {
  readonly titulo = 'Tutorial de APIs de IA';
}
