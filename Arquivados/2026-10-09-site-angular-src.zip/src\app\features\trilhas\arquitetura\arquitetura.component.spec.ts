// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { ArquiteturaComponent } from './arquitetura.component';

describe('ArquiteturaComponent', () => {
  let comp: ArquiteturaComponent;

  beforeEach(() => {
    comp = new ArquiteturaComponent();
  });

  it('deve instanciar o componente da trilha Arquitetura', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Arquitetura de Software');
  });
});
