import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-arquitetura',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/trilhas/arquitetura.html" />
  `
})
export class ArquiteturaComponent {
  readonly titulo = 'Arquitetura de Software';
}
