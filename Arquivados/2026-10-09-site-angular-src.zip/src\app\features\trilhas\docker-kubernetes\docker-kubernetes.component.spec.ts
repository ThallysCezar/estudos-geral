// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { DockerKubernetesComponent } from './docker-kubernetes.component';

describe('DockerKubernetesComponent', () => {
  let comp: DockerKubernetesComponent;

  beforeEach(() => {
    comp = new DockerKubernetesComponent();
  });

  it('deve instanciar o componente da trilha Docker & Kubernetes', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Docker & Kubernetes');
  });
});
