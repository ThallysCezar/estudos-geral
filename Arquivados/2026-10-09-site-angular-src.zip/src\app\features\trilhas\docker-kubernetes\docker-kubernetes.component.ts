import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-docker-kubernetes',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/trilhas/docker-kubernetes.html" />
  `
})
export class DockerKubernetesComponent {
  readonly titulo = 'Docker & Kubernetes';
}
