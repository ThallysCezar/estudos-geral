// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { IaComponent } from './ia.component';

describe('IaComponent', () => {
  let comp: IaComponent;

  beforeEach(() => {
    comp = new IaComponent();
  });

  it('deve instanciar o componente da trilha Inteligência Artificial', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Inteligência Artificial');
  });
});
