import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-ia',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/trilhas/ia.html" />
  `
})
export class IaComponent {
  readonly titulo = 'Inteligência Artificial';
}
