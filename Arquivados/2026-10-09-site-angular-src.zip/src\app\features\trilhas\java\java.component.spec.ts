// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { JavaComponent } from './java.component';

describe('JavaComponent', () => {
  let comp: JavaComponent;

  beforeEach(() => {
    comp = new JavaComponent();
  });

  it('deve instanciar o componente da trilha Java', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Java 21 Moderno');
  });
});
