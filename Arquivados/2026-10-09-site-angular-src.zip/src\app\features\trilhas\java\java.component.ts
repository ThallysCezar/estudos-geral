import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-java',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/trilhas/java.html" />
  `
})
export class JavaComponent {
  readonly titulo = 'Java 21 Moderno';
}
