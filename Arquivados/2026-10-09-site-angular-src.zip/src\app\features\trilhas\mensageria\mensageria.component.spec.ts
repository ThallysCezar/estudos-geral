// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { MensageriaComponent } from './mensageria.component';

describe('MensageriaComponent', () => {
  let comp: MensageriaComponent;

  beforeEach(() => {
    comp = new MensageriaComponent();
  });

  it('deve instanciar o componente da trilha Mensageria', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Mensageria & Filas');
  });
});
