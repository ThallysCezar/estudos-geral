import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-mensageria',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/trilhas/mensageria.html" />
  `
})
export class MensageriaComponent {
  readonly titulo = 'Mensageria & Filas';
}
