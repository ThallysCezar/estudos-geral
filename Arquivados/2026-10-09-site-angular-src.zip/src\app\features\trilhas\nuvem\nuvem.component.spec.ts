// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { NuvemComponent } from './nuvem.component';

describe('NuvemComponent', () => {
  let comp: NuvemComponent;

  beforeEach(() => {
    comp = new NuvemComponent();
  });

  it('deve instanciar o componente da trilha Nuvem', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Computação em Nuvem');
  });
});
