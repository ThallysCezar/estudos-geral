// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { SpringComponent } from './spring.component';

describe('SpringComponent', () => {
  let comp: SpringComponent;

  beforeEach(() => {
    comp = new SpringComponent();
  });

  it('deve instanciar o componente da trilha Spring', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('Spring Boot 3');
  });
});
