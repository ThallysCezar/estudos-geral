// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { SystemDesignComponent } from './system-design.component';

describe('SystemDesignComponent', () => {
  let comp: SystemDesignComponent;

  beforeEach(() => {
    comp = new SystemDesignComponent();
  });

  it('deve instanciar o componente da trilha System Design', () => {
    expect(comp).toBeDefined();
    expect(comp.titulo).toBe('System Design');
  });
});
