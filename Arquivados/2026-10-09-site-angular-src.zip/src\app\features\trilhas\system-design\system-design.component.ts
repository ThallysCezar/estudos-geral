import { Component } from '@angular/core';
import { FullDocViewerComponent } from '../../../shared/components/full-doc-viewer/full-doc-viewer.component';

@Component({
  selector: 'app-system-design',
  standalone: true,
  imports: [FullDocViewerComponent],
  template: `
    <app-full-doc-viewer docPath="assets/conteudo/trilhas/system-design.html" />
  `
})
export class SystemDesignComponent {
  readonly titulo = 'System Design';
}
