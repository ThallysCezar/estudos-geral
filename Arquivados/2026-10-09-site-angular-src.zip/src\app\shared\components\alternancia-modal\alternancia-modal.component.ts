import { Component, EventEmitter, Input, Output, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { AlternanciaService, DiaCronograma, DiaOpcao } from '../../../core/services/alternancia.service';

@Component({
  selector: 'app-alternancia-modal',
  standalone: true,
  template: `
    @if (dia()) {
      <div class="mdl" (click)="onBackdropClick($event)">
        <div class="box" [style.--c]="dia()!.cor">
          <button class="x" type="button" (click)="fechar()">×</button>
          <span class="kk">{{ dia()!.sig }} · escolha de versão ou tema</span>
          <h3>Qual versão estudar hoje?</h3>

          @if (dia()!.opcoes) {
            <p class="hist">
              Escolha qual versão deseja estudar:
            </p>
            <div class="opts opts-4">
              @for (op of dia()!.opcoes!; track op.f) {
                <button class="opt" type="button" (click)="irPara(op.f)">
                  <span class="bg">{{ op.versao || 'V2' }} · escolher</span>
                  <strong>{{ op.nome }}</strong>
                  <em>{{ op.nota }}</em>
                  <span class="qd">
                    {{ obterHistorico(op.f) }}
                  </span>
                </button>
              }
            </div>
          } @else {
            <p class="hist">
              Pela alternância semanal, escolha qual tema abrir:
            </p>
            <div class="opts">
              @if (dia()!.doc) {
                <button class="opt" type="button" (click)="irPara(dia()!.doc!)">
                  <span class="bg">{{ dia()!.label }}</span>
                  <strong>{{ dia()!.label }}</strong>
                  <em>{{ dia()!.n1 }}</em>
                  <span class="qd">{{ obterHistorico(dia()!.doc!) }}</span>
                </button>
              }
              @if (dia()!.doc2) {
                <button class="opt" type="button" (click)="irPara(dia()!.doc2!)">
                  <span class="bg">{{ dia()!.label2 }}</span>
                  <strong>{{ dia()!.label2 }}</strong>
                  <em>{{ dia()!.n2 }}</em>
                  <span class="qd">{{ obterHistorico(dia()!.doc2!) }}</span>
                </button>
              }
            </div>
          }

          <div class="pe">
            <button type="button" (click)="fechar()">fechar</button>
            <span class="nb">fica só neste navegador</span>
          </div>
        </div>
      </div>
    }
  `,
  styles: [`
    .mdl {
      position: fixed;
      inset: 0;
      z-index: 70;
      display: grid;
      place-items: center;
      padding: 20px;
      background: color-mix(in srgb, #15161e 78%, transparent);
      backdrop-filter: blur(7px);
      animation: mdlIn .32s var(--ease) forwards;
    }
    @keyframes mdlIn { to { opacity: 1; } }
    .box {
      --c: var(--purple);
      position: relative;
      width: min(720px, 100%);
      max-height: calc(100dvh - 40px);
      overflow: auto;
      border: 1px solid color-mix(in srgb, var(--c) 34%, transparent);
      border-radius: 26px;
      padding: 30px 30px 22px;
      background: radial-gradient(120% 130% at 0% 0%, color-mix(in srgb, var(--c) 12%, transparent), transparent 58%), var(--panel);
      box-shadow: 0 30px 90px #00000099;
    }
    .kk {
      font: 700 .62rem "Cascadia Code", monospace;
      letter-spacing: .17em;
      text-transform: uppercase;
      color: var(--c);
    }
    h3 {
      margin: 11px 0 0;
      font: 500 clamp(1.45rem, 3.4vw, 2rem)/1.12 Georgia, serif;
      letter-spacing: -.04em;
      color: var(--ink);
    }
    .hist {
      margin: 14px 0 0;
      color: var(--muted);
      font-size: .86rem;
      line-height: 1.62;
      max-width: 56ch;
    }
    .x {
      position: absolute;
      top: 14px;
      right: 17px;
      cursor: pointer;
      background: none;
      border: 0;
      line-height: 1;
      color: var(--soft);
      font: 400 1.5rem Georgia, serif;
    }
    .opts {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-top: 22px;
    }
    @media (max-width: 680px) {
      .opts { grid-template-columns: 1fr; }
    }
    .opt {
      --o: var(--c);
      display: block;
      width: 100%;
      text-align: left;
      cursor: pointer;
      font: inherit;
      color: inherit;
      border: 1px solid color-mix(in srgb, var(--o) 26%, transparent);
      border-radius: 19px;
      padding: 17px 18px 15px;
      background: color-mix(in srgb, var(--o) 6%, transparent);
      transition: border-color .3s var(--ease), background .3s var(--ease), transform .3s var(--ease);
    }
    .opt:hover {
      border-color: color-mix(in srgb, var(--o) 62%, transparent);
      background: color-mix(in srgb, var(--o) 13%, transparent);
      transform: translateY(-2px);
    }
    .opt .bg {
      display: inline-block;
      margin-bottom: 11px;
      padding: 4px 9px;
      border-radius: 999px;
      font: 700 .55rem "Cascadia Code", monospace;
      letter-spacing: .13em;
      text-transform: uppercase;
      border: 1px solid color-mix(in srgb, var(--o) 40%, transparent);
      color: var(--o);
    }
    .opt strong {
      display: block;
      font: 500 1.26rem Georgia, serif;
      letter-spacing: -.03em;
      color: var(--ink);
    }
    .opt em {
      display: block;
      margin-top: 8px;
      font-style: normal;
      color: var(--muted);
      font-size: .79rem;
      line-height: 1.5;
    }
    .opt .qd {
      display: block;
      margin-top: 11px;
      font: .67rem "Cascadia Code", monospace;
      color: var(--soft);
    }
    .pe {
      display: flex;
      gap: 16px;
      align-items: center;
      margin-top: 18px;
      padding-top: 15px;
      border-top: 1px solid var(--line);
    }
    .pe button {
      cursor: pointer;
      font: inherit;
      font-size: .76rem;
      color: var(--muted);
      background: none;
      border: 0;
      text-decoration: underline;
    }
    .pe .nb {
      margin-left: auto;
      color: var(--soft);
      font-size: .68rem;
      font-family: "Cascadia Code", monospace;
    }
  `]
})
export class AlternanciaModalComponent {
  private alternanciaService = inject(AlternanciaService);
  private router = inject(Router);

  readonly dia = signal<DiaCronograma | null>(null);
  @Output() onClose = new EventEmitter<void>();

  abrir(d: DiaCronograma): void {
    this.dia.set(d);
  }

  fechar(): void {
    this.dia.set(null);
    this.onClose.emit();
  }

  onBackdropClick(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains('mdl')) {
      this.fechar();
    }
  }

  irPara(rota: string): void {
    const d = this.dia();
    if (d) {
      this.alternanciaService.gravar(d.slot, rota);
    }
    this.fechar();
    this.router.navigate([rota]);
  }

  obterHistorico(rota: string): string {
    const d = this.dia();
    if (!d) return 'nunca aberto por aqui';
    const registros = this.alternanciaService.lerRegistros()[d.slot] || [];
    const ult = registros.find(r => r.f === rota);
    if (!ult) return 'nunca aberto por aqui';
    return `última vez: ${this.alternanciaService.quando(ult.t, d.passado)}`;
  }
}
