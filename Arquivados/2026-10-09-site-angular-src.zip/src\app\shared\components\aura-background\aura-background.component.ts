import { Component, ElementRef, HostListener, Input, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-aura-background',
  standalone: true,
  template: `
    <div class="aura-wrap" #auraWrap>
      <div class="aura" [style.--accent]="accentColor"></div>
    </div>
    <div class="grain"></div>
  `,
  styles: [`
    .aura-wrap {
      position: fixed;
      inset: 0;
      z-index: 0;
      pointer-events: none;
      will-change: transform;
    }
    .aura {
      position: absolute;
      inset: -20% -10%;
      pointer-events: none;
      background:
        radial-gradient(38% 42% at 18% 22%, color-mix(in srgb, var(--accent, #8be9fd) 30%, transparent), transparent 70%),
        radial-gradient(34% 38% at 82% 12%, color-mix(in srgb, var(--accent, #8be9fd) 17%, transparent), transparent 72%),
        radial-gradient(46% 46% at 62% 88%, #bd93f91f, transparent 72%);
      filter: blur(12px);
      animation: drift 26s ease-in-out infinite alternate;
    }
    @keyframes drift {
      0% { transform: translate3d(-2%, -1%, 0) scale(1); }
      50% { transform: translate3d(2%, 2%, 0) scale(1.07); }
      100% { transform: translate3d(-1%, 1.5%, 0) scale(1.02); }
    }
    .grain {
      position: fixed;
      inset: 0;
      z-index: 0;
      pointer-events: none;
      background-image: radial-gradient(#f8f8f21f 1px, transparent 1px);
      background-size: 22px 22px;
      mask-image: radial-gradient(80% 65% at 50% 28%, #000 0%, transparent 78%);
    }
    @media (prefers-reduced-motion: reduce) {
      .aura {
        animation: none;
      }
    }
  `]
})
export class AuraBackgroundComponent implements OnInit {
  @Input() accentColor: string = 'var(--cyan)';
  @ViewChild('auraWrap', { static: true }) auraWrap!: ElementRef<HTMLDivElement>;

  private ax = 0;
  private ay = 0;
  private tx = 0;
  private ty = 0;
  private rafId: number | null = null;
  private reducedMotion = false;

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
  }

  @HostListener('window:pointermove', ['$event'])
  onPointerMove(e: PointerEvent): void {
    if (this.reducedMotion || typeof window === 'undefined') return;
    this.tx = (e.clientX / window.innerWidth - 0.5) * 34;
    this.ty = (e.clientY / window.innerHeight - 0.5) * 24;

    if (!this.rafId) {
      this.rafId = requestAnimationFrame(() => this.seguir());
    }
  }

  private seguir(): void {
    this.ax += (this.tx - this.ax) * 0.045;
    this.ay += (this.ty - this.ay) * 0.045;

    if (this.auraWrap?.nativeElement) {
      this.auraWrap.nativeElement.style.transform = `translate3d(${this.ax.toFixed(2)}px, ${this.ay.toFixed(2)}px, 0)`;
    }

    if (Math.abs(this.tx - this.ax) > 0.2 || Math.abs(this.ty - this.ay) > 0.2) {
      this.rafId = requestAnimationFrame(() => this.seguir());
    } else {
      this.rafId = null;
    }
  }
}
