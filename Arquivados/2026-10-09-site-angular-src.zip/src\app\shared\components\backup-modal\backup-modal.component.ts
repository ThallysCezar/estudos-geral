import { Component, ElementRef, EventEmitter, Input, Output, ViewChild, inject, signal } from '@angular/core';
import { StorageService } from '../../../core/services/storage.service';

@Component({
  selector: 'app-backup-modal',
  standalone: true,
  template: `
    @if (isOpen()) {
      <div class="palette-scrim open" (click)="onBackdropClick($event)">
        <div class="backup-card">
          <div class="card-head">
            <h3>Backup de Dados Locais</h3>
            <button type="button" class="btn-fechar" (click)="fechar()">✕</button>
          </div>
          <p>
            Suas anotações, escolhas e dados ficam salvos localmente no navegador (
            <code class="mono">localStorage</code>
            ). Exporte um arquivo JSON para segurança ao limpar o cache ou trocar de máquina.
          </p>
          <div class="backup-actions">
            <button type="button" class="primary" (click)="exportar()">⬇ Exportar JSON</button>
            <button type="button" (click)="fileInput.click()">⬆ Restaurar JSON</button>
            <input #fileInput type="file" accept=".json" style="display:none" (change)="onFileSelected($event)" />
          </div>
          @if (mensagem()) {
            <div class="backup-msg">{{ mensagem() }}</div>
          }
        </div>
      </div>
    }
  `,
  styles: [`
    .palette-scrim {
      position: fixed;
      inset: 0;
      z-index: 100;
      background: #0d0e14d9;
      backdrop-filter: blur(8px);
      display: grid;
      place-items: center;
      padding: 20px;
    }
    .backup-card {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 20px;
      padding: 24px;
      width: min(500px, 100%);
      box-shadow: 0 24px 60px #000000a6;
      animation: popIn .2s var(--ease);
    }
    @keyframes popIn {
      from { transform: translateY(-10px) scale(.98); opacity: 0; }
      to { transform: none; opacity: 1; }
    }
    .card-head {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 6px;
    }
    .card-head h3 {
      margin: 0;
      font: 600 1.25rem Georgia, serif;
      color: var(--ink);
    }
    .btn-fechar {
      background: none;
      border: 0;
      color: var(--soft);
      cursor: pointer;
      font-size: 1.3rem;
    }
    .backup-card p {
      margin: 0 0 20px;
      font-size: .85rem;
      color: var(--muted);
      line-height: 1.55;
    }
    .backup-actions {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }
    .backup-actions button {
      flex: 1 1 140px;
      border-radius: 12px;
      padding: 12px 14px;
      border: 1px solid var(--line2);
      background: #282a36;
      color: var(--ink);
      font: 600 .8rem "Inter", sans-serif;
      cursor: pointer;
      transition: .15s;
    }
    .backup-actions button.primary {
      border-color: var(--purple);
      background: color-mix(in srgb, var(--purple) 18%, transparent);
      color: var(--purple);
    }
    .backup-actions button:hover {
      filter: brightness(1.2);
    }
    .backup-msg {
      margin-top: 14px;
      font-size: .8rem;
      color: var(--teal);
    }
  `]
})
export class BackupModalComponent {
  private storageService = inject(StorageService);

  @Input() isOpen = signal<boolean>(false);
  @Output() onClose = new EventEmitter<void>();

  readonly mensagem = signal<string>('');
  @ViewChild('fileInput') fileInputRef!: ElementRef<HTMLInputElement>;

  fechar(): void {
    this.isOpen.set(false);
    this.mensagem.set('');
    this.onClose.emit();
  }

  onBackdropClick(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains('palette-scrim')) {
      this.fechar();
    }
  }

  exportar(): void {
    const blob = this.storageService.exportBackup();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const d = new Date();
    a.download = `estudos-backup-${d.toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    this.mensagem.set('✓ Backup exportado com sucesso (sem credenciais)!');
    setTimeout(() => this.mensagem.set(''), 4000);
  }

  onFileSelected(e: Event): void {
    const input = e.target as HTMLInputElement;
    if (!input.files || !input.files[0]) return;
    const file = input.files[0];
    const reader = new FileReader();

    reader.onload = (event: ProgressEvent<FileReader>) => {
      const text = event.target?.result as string;
      const res = this.storageService.importBackup(text);
      if (res.success) {
        this.mensagem.set(`✓ ${res.count} chaves restauradas com sucesso!`);
      } else {
        this.mensagem.set(`Erro na restauração: ${res.error}`);
      }
    };
    reader.readAsText(file);
  }
}
