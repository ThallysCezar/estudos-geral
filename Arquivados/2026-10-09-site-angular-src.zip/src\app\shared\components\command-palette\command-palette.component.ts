import { Component, ElementRef, HostListener, ViewChild, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { PaletteService, PaletteItem } from '../../../core/services/palette.service';

@Component({
  selector: 'app-command-palette',
  standalone: true,
  template: `
    @if (paletteService.isOpen()) {
      <div class="palette-scrim open" (click)="onBackdropClick($event)">
        <div class="palette-box">
          <div class="palette-head">
            <i>⌘</i>
            <input
              #inputElement
              type="search"
              class="palette-input"
              placeholder="Buscar tópicos, arquivos ou projetos... (ex: outbox, hikari, kafka, jwt, r03)"
              [value]="paletteService.query()"
              (input)="onInput($event)"
              (keydown)="onKeyDown($event)"
              autocomplete="off"
            />
            <span class="palette-kbd"><kbd>Esc</kbd> fechar</span>
          </div>

          <div class="palette-results">
            @if (paletteService.filtered().length === 0) {
              <div class="palette-empty">Nenhum resultado encontrado para "{{ paletteService.query() }}".</div>
            } @else {
              @for (item of paletteService.filtered(); track item.url; let idx = $index) {
                <div
                  class="palette-item"
                  [class.active]="idx === selectedIndex()"
                  (click)="selecionarItem(item)"
                  (mouseenter)="selectedIndex.set(idx)"
                >
                  <span
                    class="p-tag"
                    [style.background]="'color-mix(in srgb, ' + item.cor + ' 16%, transparent)'"
                    [style.color]="item.cor"
                    [style.border]="'1px solid color-mix(in srgb, ' + item.cor + ' 36%, transparent)'"
                  >
                    {{ item.cat }}
                  </span>
                  <div class="p-text">
                    <span class="p-title">{{ item.t }}</span>
                    <span class="p-sub">{{ item.sub }}</span>
                  </div>
                  <span class="palette-kbd-enter">↵</span>
                </div>
              }
            }
          </div>
        </div>
      </div>
    }
  `,
  styles: [`
    .palette-scrim {
      position: fixed;
      inset: 0;
      z-index: 100;
      background: #0d0e14d9;
      backdrop-filter: blur(8px);
      display: grid;
      place-items: start center;
      padding: clamp(20px, 10vh, 80px) 16px 20px;
    }
    .palette-box {
      width: min(660px, 100%);
      background: var(--panel);
      border: 1px solid var(--line2);
      border-radius: 20px;
      box-shadow: 0 24px 60px #000000a6;
      overflow: hidden;
      transform: translateY(0);
      animation: popIn .2s var(--ease);
    }
    @keyframes popIn {
      from { transform: translateY(-10px) scale(.98); opacity: 0; }
      to { transform: none; opacity: 1; }
    }
    .palette-head {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 16px 20px;
      border-bottom: 1px solid var(--line);
      background: #1e1f29;
    }
    .palette-head i {
      font-style: normal;
      color: var(--purple);
      font-size: 1.1rem;
    }
    .palette-input {
      flex: 1;
      background: transparent;
      border: 0;
      outline: none;
      color: var(--ink);
      font: 500 1rem "Inter", sans-serif;
    }
    .palette-input::placeholder {
      color: var(--soft);
    }
    .palette-kbd {
      font: 700 .65rem "Cascadia Code", monospace;
      color: var(--muted);
      background: #282a36;
      padding: 4px 8px;
      border-radius: 6px;
      border: 1px solid var(--line2);
    }
    .palette-results {
      max-height: min(420px, 60vh);
      overflow-y: auto;
      padding: 8px 0;
    }
    .palette-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 11px 20px;
      text-decoration: none;
      cursor: pointer;
      border-left: 3px solid transparent;
      transition: background .15s;
    }
    .palette-item:hover, .palette-item.active {
      background: #ffffff0f;
      border-left-color: var(--purple);
    }
    .p-tag {
      font: 700 .6rem "Cascadia Code", monospace;
      letter-spacing: .08em;
      text-transform: uppercase;
      padding: 3px 8px;
      border-radius: 6px;
      white-space: nowrap;
    }
    .p-text {
      flex: 1;
      min-width: 0;
    }
    .p-title {
      font: 600 .86rem "Inter", sans-serif;
      color: var(--ink);
      display: block;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .p-sub {
      font: 400 .74rem Georgia, serif;
      color: var(--muted);
      display: block;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .palette-kbd-enter {
      font: 700 .6rem "Cascadia Code", monospace;
      color: var(--soft);
    }
    .palette-empty {
      padding: 28px 20px;
      text-align: center;
      color: var(--soft);
      font-style: italic;
      font-size: .88rem;
    }
  `]
})
export class CommandPaletteComponent {
  readonly paletteService = inject(PaletteService);
  private router = inject(Router);

  readonly selectedIndex = signal<number>(0);
  @ViewChild('inputElement') set inputElement(el: ElementRef<HTMLInputElement> | undefined) {
    if (el) {
      setTimeout(() => el.nativeElement.focus(), 30);
    }
  }

  @HostListener('window:keydown', ['$event'])
  handleGlobalKeydown(e: KeyboardEvent): void {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      this.paletteService.toggle();
      this.selectedIndex.set(0);
    } else if (e.key === 'Escape' && this.paletteService.isOpen()) {
      this.paletteService.close();
    }
  }

  onInput(event: Event): void {
    const val = (event.target as HTMLInputElement).value;
    this.paletteService.query.set(val);
    this.selectedIndex.set(0);
  }

  onKeyDown(e: KeyboardEvent): void {
    const total = this.paletteService.filtered().length;
    if (!total) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      this.selectedIndex.update(i => (i + 1) % total);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      this.selectedIndex.update(i => (i - 1 + total) % total);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const item = this.paletteService.filtered()[this.selectedIndex()];
      if (item) {
        this.selecionarItem(item);
      }
    }
  }

  onBackdropClick(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains('palette-scrim')) {
      this.paletteService.close();
    }
  }

  selecionarItem(item: PaletteItem): void {
    this.paletteService.close();
    const [path, anchor] = item.url.split('#');
    if (anchor) {
      this.router.navigate([path], { fragment: anchor });
    } else {
      this.router.navigate([path]);
    }
  }
}
