// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { ElementRef } from '@angular/core';
import { FullDocViewerComponent } from './full-doc-viewer.component';

describe('FullDocViewerComponent', () => {
  let comp: FullDocViewerComponent;
  let hostEl: HTMLElement;

  beforeEach(() => {
    hostEl = document.createElement('div');
    hostEl.innerHTML = '<div class="doc-container"></div>';
    document.body.appendChild(hostEl);

    // Injetar ElementRef manualmente no teste
    comp = new FullDocViewerComponent();
    (comp as any).el = new ElementRef(hostEl);
    comp.docPath = 'assets/conteudo/trilhas/java.html';
  });

  afterEach(() => {
    comp.ngOnDestroy();
    hostEl.remove();
  });

  it('deve inicializar no estado carregando', () => {
    expect(comp.carregando()).toBe(true);
    expect(comp.docPath).toBe('assets/conteudo/trilhas/java.html');
  });

  it('deve limpar elementos residuais globais no ngOnDestroy', () => {
    // Simular elementos criados dinamicamente por scripts como responsive-drawer
    const header = document.createElement('header');
    header.className = 'mobile-header';
    document.body.appendChild(header);

    const backdrop = document.createElement('div');
    backdrop.className = 'drawer-backdrop';
    document.body.appendChild(backdrop);

    const floatingBtn = document.createElement('a');
    floatingBtn.id = 'btnFloatingHome';
    document.body.appendChild(floatingBtn);

    const floatingStyle = document.createElement('style');
    floatingStyle.id = 'styleFloatingHome';
    document.head.appendChild(floatingStyle);

    document.documentElement.style.overflow = 'hidden';

    // Executar teardown do componente
    comp.ngOnDestroy();

    expect(document.querySelector('.mobile-header')).toBeNull();
    expect(document.querySelector('.drawer-backdrop')).toBeNull();
    expect(document.getElementById('btnFloatingHome')).toBeNull();
    expect(document.getElementById('styleFloatingHome')).toBeNull();
    expect(document.documentElement.style.overflow).toBe('');
  });

  it('deve normalizar links para rotas SPA em renderizarConteudo', () => {
    const sampleHtml = `
      <!doctype html>
      <html>
        <body>
          <a href="../index.html">Home</a>
          <a href="acervo.html">Acervo</a>
          <a href="trilhas/java.html">Java</a>
          <a href="cadernos/linux.html">Linux</a>
          <a href="lab/projetos.html">Projetos</a>
          <a href="lab/tutorial-api.html">Tutorial Lab</a>
          <a href="ferramentas/prompt-studio.html">Prompt Studio</a>
          <a href="#modulo1">Modulo 1</a>
        </body>
      </html>
    `;

    (comp as any).renderizarConteudo(sampleHtml);

    const container = hostEl.querySelector('.doc-container') as HTMLElement;
    expect(container).toBeDefined();

    const links = container.querySelectorAll('a');
    const hrefs = Array.from(links).map(a => a.getAttribute('href'));
    const spas = Array.from(links).map(a => a.getAttribute('data-spa'));

    expect(hrefs).toContain('/');
    expect(hrefs).toContain('/acervo');
    expect(hrefs).toContain('/trilhas/java');
    expect(hrefs).toContain('/cadernos/linux');
    expect(hrefs).toContain('/lab/projetos');
    expect(hrefs).toContain('/lab/tutorial-api');
    expect(hrefs).toContain('/ferramentas/prompt-studio');
    expect(hrefs).toContain('#modulo1');

    // Âncora interna deve ter data-anchor
    const anchor = container.querySelector('a[href="#modulo1"]');
    expect(anchor?.getAttribute('data-anchor')).toBe('true');
  });
});
