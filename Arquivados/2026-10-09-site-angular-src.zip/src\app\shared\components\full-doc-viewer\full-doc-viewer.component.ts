import {
  Component,
  Input,
  OnInit,
  OnDestroy,
  ElementRef,
  inject,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-full-doc-viewer',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div *ngIf="carregando()" class="loading-state">
      <div class="loader-spinner"></div>
      <span>Carregando documento completo...</span>
    </div>
    <div #docContainer class="doc-container" [style.opacity]="carregando() ? '0' : '1'"></div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      max-width: 100%;
      min-width: 0;
      min-height: 100vh;
      background: var(--bg, #282a36);
      color: var(--ink, #f8f8f2);
      overflow-x: hidden;
    }
    .loading-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 400px;
      gap: 16px;
      color: var(--muted, #9aa1c0);
      font-family: 'Inter', sans-serif;
      font-size: .88rem;
    }
    .loader-spinner {
      width: 32px;
      height: 32px;
      border: 3px solid rgba(189, 147, 249, 0.2);
      border-top-color: var(--purple, #bd93f9);
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    .doc-container {
      transition: opacity 0.25s ease;
      width: 100%;
      max-width: 100%;
      min-width: 0;
      overflow-x: hidden;
    }
  `]
})
export class FullDocViewerComponent implements OnInit, OnDestroy {
  @Input({ required: true }) docPath!: string;

  private readonly el?: ElementRef;
  private readonly router?: Router;

  constructor() {
    try { this.el = inject(ElementRef); } catch {}
    try { this.router = inject(Router); } catch {}
  }

  readonly carregando = signal(true);
  private clickHandler?: (e: MouseEvent) => void;
  private readonly injectedElements: HTMLElement[] = [];

  private static cache = new Map<string, string>();

  ngOnInit(): void {
    this.carregarDocumento();
  }

  ngOnDestroy(): void {
    if (this.clickHandler && this.el) {
      this.el.nativeElement.removeEventListener('click', this.clickHandler);
    }

    // 1. Remover scripts e estilos injetados dinamicamente
    for (const el of this.injectedElements) {
      el.remove();
    }
    this.injectedElements.length = 0;

    // 2. Limpar elementos e estilos residuais criados por scripts globais
    document.getElementById('styleFloatingHome')?.remove();
    document.getElementById('btnFloatingHome')?.remove();
    document.querySelectorAll('.mobile-header, .drawer-backdrop').forEach(el => el.remove());

    // 3. Restaurar bloqueio de scroll
    document.documentElement.style.overflow = '';
    document.body.style.overflow = '';
  }

  private async carregarDocumento(): Promise<void> {
    if (!this.el) return;
    try {
      let html = FullDocViewerComponent.cache.get(this.docPath);
      if (!html) {
        const res = await fetch(this.docPath);
        if (!res.ok) throw new Error(`Falha ao carregar ${this.docPath}: HTTP ${res.status}`);
        html = await res.text();
        FullDocViewerComponent.cache.set(this.docPath, html);
      }

      this.renderizarConteudo(html);
    } catch (err) {
      console.error(`[FullDocViewer] Erro ao carregar ${this.docPath}:`, err);
      this.carregando.set(false);
    }
  }

  private renderizarConteudo(html: string): void {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    const container = this.el?.nativeElement.querySelector('.doc-container') as HTMLElement;
    if (!container) return;

    // Normalizar links no documento parseado para rotas do SPA
    doc.querySelectorAll('a').forEach(a => {
      const href = a.getAttribute('href');
      if (!href) return;

      if (href === '../index.html' || href === 'index.html') {
        a.setAttribute('href', '/');
        a.setAttribute('data-spa', 'true');
      } else if (href.includes('acervo.html')) {
        a.setAttribute('href', '/acervo');
        a.setAttribute('data-spa', 'true');
      } else if (href.includes('lab/projetos.html') || href.includes('projetos.html')) {
        a.setAttribute('href', '/lab/projetos');
        a.setAttribute('data-spa', 'true');
      } else if (href.includes('lab/tutorial-api.html')) {
        a.setAttribute('href', '/lab/tutorial-api');
        a.setAttribute('data-spa', 'true');
      } else if (/ferramentas\/([a-z0-9\-]+)\.html/i.test(href)) {
        const match = href.match(/ferramentas\/([a-z0-9\-]+)\.html/i);
        if (match) {
          a.setAttribute('href', `/ferramentas/${match[1]}`);
          a.setAttribute('data-spa', 'true');
        }
      } else if (/trilhas\/([a-z0-9\-]+)\.html/i.test(href)) {
        const match = href.match(/trilhas\/([a-z0-9\-]+)\.html/i);
        if (match) {
          a.setAttribute('href', `/trilhas/${match[1]}`);
          a.setAttribute('data-spa', 'true');
        }
      } else if (/cadernos\/([a-z0-9\-]+)\.html/i.test(href)) {
        const match = href.match(/cadernos\/([a-z0-9\-]+)\.html/i);
        if (match) {
          a.setAttribute('href', `/cadernos/${match[1]}`);
          a.setAttribute('data-spa', 'true');
        }
      } else if (href.startsWith('#')) {
        a.setAttribute('data-anchor', 'true');
      }
    });

    // Injetar estilos do documento no container
    const styles = doc.querySelectorAll('style');
    styles.forEach(s => {
      container.appendChild(s.cloneNode(true));
    });

    // Extrair todos os scripts antes de injetar o body (evita nós inativos e duplicações)
    const scriptNodes = Array.from(doc.querySelectorAll('script'));
    const scriptsToRun: { src?: string; code?: string }[] = [];
    const seenSrcs = new Set<string>();

    for (const s of scriptNodes) {
      if (s.src) {
        let cleanSrc = s.getAttribute('src') || '';
        if (cleanSrc.startsWith('../')) cleanSrc = cleanSrc.replace('../', '');
        if (!seenSrcs.has(cleanSrc)) {
          seenSrcs.add(cleanSrc);
          scriptsToRun.push({ src: cleanSrc });
        }
      } else if (s.textContent) {
        scriptsToRun.push({ code: s.textContent });
      }
      s.remove();
    }

    // Injetar o restante dos nós do body no container
    Array.from(doc.body.childNodes).forEach(node => {
      container.appendChild(node.cloneNode(true));
    });

    this.carregando.set(false);

    // Configurar interceptador de cliques para navegação SPA e âncoras suaves
    this.configurarInterceptadorDeCliques(container);

    // Executar scripts no escopo global de forma sequencial
    this.executarScripts(scriptsToRun);
  }

  private configurarInterceptadorDeCliques(container: HTMLElement): void {
    this.clickHandler = (e: MouseEvent) => {
      const a = (e.target as HTMLElement).closest('a');
      if (!a) return;

      const isSpa = a.getAttribute('data-spa') === 'true';
      const isAnchor = a.getAttribute('data-anchor') === 'true';
      const href = a.getAttribute('href');

      if (isSpa && href) {
        if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
        e.preventDefault();
        this.router?.navigateByUrl(href);
      } else if (isAnchor && href) {
        e.preventDefault();
        const targetId = href.substring(1);
        const targetEl = document.getElementById(targetId);
        if (targetEl) {
          targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
          history.replaceState(null, '', href);
        }
      }
    };

    container.addEventListener('click', this.clickHandler);
  }

  private async executarScripts(scripts: { src?: string; code?: string }[]): Promise<void> {
    for (const item of scripts) {
      if (item.src) {
        await new Promise<void>((resolve) => {
          const el = document.createElement('script');
          el.src = item.src!;
          el.onload = () => resolve();
          el.onerror = (err) => {
            console.error(`[FullDocViewer] Erro ao carregar script ${item.src} em ${this.docPath}:`, err);
            resolve();
          };
          document.body.appendChild(el);
          this.injectedElements.push(el);
        });
      } else if (item.code) {
        try {
          // Executa inline scripts no escopo global (window), preservando var e function cruzados
          const el = document.createElement('script');
          el.type = 'text/javascript';
          el.textContent = item.code;
          document.body.appendChild(el);
          this.injectedElements.push(el);
        } catch (err) {
          console.error(`[FullDocViewer] Erro ao executar script inline em ${this.docPath}:`, err);
        }
      }
    }
  }
}
