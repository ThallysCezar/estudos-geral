import { Component, EventEmitter, Output, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { PaletteService } from '../../../core/services/palette.service';

@Component({
  selector: 'app-island-nav',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  template: `
    <nav class="island">
      <a routerLink="/" class="brand"><i>◆</i> ESTUDOS / BACKEND</a>
      <button type="button" class="btn-act" (click)="abrirBusca()" title="Buscar no acervo completo (Ctrl+K)">
        🔍 Buscar <kbd>Ctrl+K</kbd>
      </button>
      <button type="button" class="btn-act" (click)="onAbrirBackup.emit()" title="Fazer backup ou restaurar dados">
        💾 Backup
      </button>
      <a routerLink="/acervo" routerLinkActive="on">o acervo completo</a>
      <a routerLink="/lab/projetos" routerLinkActive="on">projetos</a>
      <a routerLink="/ferramentas/prompt-studio" class="destaque-cyan">🧠 prompt studio</a>
      <a routerLink="/ferramentas/refinador" class="destaque-purple">✨ formatador</a>
    </nav>
  `,
  styles: [`
    .island {
      position: sticky;
      top: 16px;
      z-index: 60;
      width: min(1120px, calc(100% - 32px));
      margin: 16px auto;
      display: flex;
      align-items: center;
      gap: 9px;
      padding: 11px 20px;
      border: 1px solid var(--line);
      border-radius: 999px;
      background: color-mix(in srgb, var(--panel) 88%, transparent);
      backdrop-filter: blur(18px);
    }
    .brand {
      font: 800 .78rem/1 Inter, sans-serif;
      letter-spacing: .13em;
      margin-right: auto;
      white-space: nowrap;
      text-decoration: none;
      color: var(--ink);
    }
    .brand i {
      font-style: normal;
      color: var(--cyan);
      transition: color .8s var(--ease);
    }
    .island a {
      font-size: .76rem;
      color: var(--muted);
      text-decoration: none;
      border: 1px solid var(--line);
      border-radius: 999px;
      padding: 8px 14px;
      white-space: nowrap;
      transition: background .3s var(--ease), color .3s var(--ease), border-color .3s var(--ease);
    }
    .island a:hover {
      background: #ffffff0a;
      color: var(--ink);
    }
    .island a.on {
      color: var(--cyan);
      border-color: color-mix(in srgb, var(--cyan) 48%, transparent);
    }
    .island button.btn-act {
      background: transparent;
      border: 1px solid var(--line);
      color: var(--muted);
      border-radius: 999px;
      padding: 7px 13px;
      font: 600 .74rem "Inter", sans-serif;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: all .2s var(--ease);
    }
    .island button.btn-act:hover {
      background: #ffffff0f;
      color: var(--ink);
      border-color: var(--purple);
    }
    .island button.btn-act kbd {
      font: 700 .6rem "Cascadia Code", monospace;
      background: #ffffff14;
      padding: 2px 5px;
      border-radius: 4px;
      border: 1px solid var(--line2);
    }
    .destaque-cyan {
      color: var(--cyan) !important;
      font-weight: 700;
      border-color: color-mix(in srgb, var(--cyan) 45%, transparent) !important;
      background: color-mix(in srgb, var(--cyan) 10%, transparent) !important;
    }
    .destaque-purple {
      color: var(--purple) !important;
      font-weight: 700;
      border-color: color-mix(in srgb, var(--purple) 45%, transparent) !important;
      background: color-mix(in srgb, var(--purple) 10%, transparent) !important;
    }
    @media (max-width: 680px) {
      .island {
        width: calc(100% - 24px);
        flex-wrap: wrap;
        border-radius: 22px;
        padding: 10px 13px;
        gap: 7px;
      }
      .island .brand {
        margin-right: 0;
        width: 100%;
        margin-bottom: 2px;
        font-size: .72rem;
      }
      .island a, .island button.btn-act {
        font-size: .71rem;
        padding: 6px 10px;
      }
    }
  `]
})
export class IslandNavComponent {
  private paletteService = inject(PaletteService);
  @Output() onAbrirBackup = new EventEmitter<void>();

  abrirBusca(): void {
    this.paletteService.open();
  }
}
