// @vitest-environment jsdom
import '@angular/compiler';
import { describe, it, expect, beforeEach } from 'vitest';
import { MicrolearningWidgetComponent } from './microlearning-widget.component';

describe('MicrolearningWidgetComponent', () => {
  let comp: MicrolearningWidgetComponent;

  beforeEach(() => {
    localStorage.clear();
    comp = new MicrolearningWidgetComponent();
    comp.ngOnInit();
  });

  it('deve inicializar com uma questão sorteada', () => {
    expect(comp.questaoAtual).not.toBeNull();
    expect(comp.questaoAtual?.opcoes.length).toBe(4);
    expect(comp.respondido).toBe(false);
  });

  it('deve pontuar +50 XP e incrementar streak quando responder corretamente', () => {
    const q = comp.questaoAtual!;
    const optCorreta = q.opcoes.find(o => o.correct)!;

    comp.responder(optCorreta);

    expect(comp.respondido).toBe(true);
    expect(comp.acertou).toBe(true);
    expect(comp.xp).toBe(50);
    expect(comp.streak).toBe(1);
    expect(localStorage.getItem('quiz_xp')).toBe('50');
  });

  it('deve marcar erro e não pontuar quando responder incorretamente', () => {
    const q = comp.questaoAtual!;
    const optIncorreta = q.opcoes.find(o => !o.correct)!;

    comp.responder(optIncorreta);

    expect(comp.respondido).toBe(true);
    expect(comp.acertou).toBe(false);
    expect(comp.xp).toBe(0);
    expect(localStorage.getItem('quiz_xp')).toBeNull();
  });
});
