import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { StorageService } from '../../../core/services/storage.service';
import {
  MICROLEARNING_QUESTIONS,
  MicrolearningQuestao,
  MicrolearningOpcao
} from '../../../core/data/microlearning.data';

@Component({
  selector: 'app-microlearning-widget',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section class="ml-card" *ngIf="questaoAtual">
      <div class="ml-top">
        <div class="ml-badge">
          <span class="ml-icon">{{ questaoAtual.icon }}</span>
          <span [style.color]="questaoAtual.cor">{{ questaoAtual.trilha }}</span>
          <span class="ml-sep">·</span>
          <span class="ml-topico">{{ questaoAtual.topicoNome }}</span>
        </div>

        <div class="ml-streak-badges">
          <span class="ml-streak" title="Dias seguidos praticando">
            🔥 {{ streak }} dia{{ streak === 1 ? '' : 's' }}
          </span>
          <span class="ml-xp" title="Experiência técnica">
            ⚡ {{ xp }} XP
          </span>
          <button type="button" class="ml-btn-next" (click)="sortearNovaQuestao()" title="Sortear outro desafio">
            ↻ Outro desafio
          </button>
        </div>
      </div>

      <div class="ml-body">
        <p class="ml-pergunta">{{ questaoAtual.pergunta }}</p>

        <pre *ngIf="questaoAtual.code" class="ml-code"><code>{{ questaoAtual.code }}</code></pre>

        <div class="ml-options">
          <button
            *ngFor="let opt of questaoAtual.opcoes; let i = index"
            type="button"
            class="ml-opt"
            [class.selected]="opcaoEscolhida === opt"
            [class.correct]="respondido && opt.correct"
            [class.wrong]="respondido && opcaoEscolhida === opt && !opt.correct"
            [disabled]="respondido"
            (click)="responder(opt)"
          >
            <span class="ml-opt-letter">{{ opt.letter }}</span>
            <span class="ml-opt-text">{{ opt.text }}</span>
          </button>
        </div>

        <div *ngIf="respondido" class="ml-feedback" [class.feedback-ok]="acertou" [class.feedback-err]="!acertou">
          <div class="ml-fb-header">
            <span class="ml-fb-badge">{{ acertou ? '✓ RESPOSTA CORRETA (+50 XP)' : '✕ RESPOSTA INCORRETA' }}</span>
          </div>
          <p class="ml-fb-text">{{ questaoAtual.explicacao }}</p>
          <div class="ml-fb-footer">
            <span class="ml-fb-rec">💡 <b>Recomendação:</b> {{ questaoAtual.recomendacao }}</span>
            <button type="button" class="ml-btn-continue" (click)="sortearNovaQuestao()">
              Próximo Desafio →
            </button>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .ml-card {
      background: var(--panel, #21222c);
      border: 1px solid var(--line2, #44475a);
      border-left: 4px solid var(--cyan, #8be9fd);
      border-radius: 18px;
      padding: 24px 26px;
      margin: 32px 0 20px;
      box-shadow: 0 14px 34px rgba(0, 0, 0, 0.35);
    }
    .ml-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 12px;
      margin-bottom: 16px;
      padding-bottom: 12px;
      border-bottom: 1px solid var(--line, #44475a66);
    }
    .ml-badge {
      display: flex;
      align-items: center;
      gap: 8px;
      font: 700 .75rem "Inter", sans-serif;
      text-transform: uppercase;
      letter-spacing: .08em;
    }
    .ml-icon {
      font-size: 1.15rem;
    }
    .ml-sep {
      color: var(--soft, #6272a4);
    }
    .ml-topico {
      color: var(--ink, #f8f8f2);
      font-weight: 600;
    }
    .ml-streak-badges {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
    }
    .ml-streak {
      display: inline-flex;
      align-items: center;
      font: 700 .78rem "Inter", sans-serif;
      color: var(--orange, #ffb86c);
      background: rgba(255, 184, 108, 0.12);
      border: 1px solid rgba(255, 184, 108, 0.3);
      border-radius: 999px;
      padding: 4px 11px;
    }
    .ml-xp {
      display: inline-flex;
      align-items: center;
      font: 700 .78rem "Inter", sans-serif;
      color: var(--gold, #f1fa8c);
      background: rgba(241, 250, 140, 0.1);
      border: 1px solid rgba(241, 250, 140, 0.28);
      border-radius: 999px;
      padding: 4px 11px;
    }
    .ml-btn-next {
      background: transparent;
      border: 1px solid var(--line, #44475a);
      color: var(--muted, #9aa1c0);
      border-radius: 999px;
      padding: 4px 12px;
      font: 600 .72rem "Inter", sans-serif;
      cursor: pointer;
      transition: all .2s;
    }
    .ml-btn-next:hover {
      color: var(--cyan, #8be9fd);
      border-color: var(--cyan, #8be9fd);
      background: rgba(139, 233, 253, 0.08);
    }
    .ml-pergunta {
      font: 500 1.05rem/1.55 Georgia, serif;
      color: var(--ink, #f8f8f2);
      margin: 0 0 14px;
    }
    .ml-code {
      background: #14151e;
      border: 1px solid var(--line, #44475a66);
      border-radius: 10px;
      padding: 12px 16px;
      margin: 0 0 16px;
      font: 500 .82rem "Cascadia Code", monospace;
      color: var(--cyan, #8be9fd);
      overflow-x: auto;
    }
    .ml-options {
      display: grid;
      grid-template-columns: 1fr;
      gap: 10px;
    }
    .ml-opt {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      background: var(--card, #282a36);
      border: 1px solid var(--line, #44475a66);
      border-radius: 12px;
      padding: 12px 16px;
      cursor: pointer;
      text-align: left;
      color: var(--ink2, #dcdce0);
      font: 400 .88rem/1.5 "Inter", sans-serif;
      transition: all .2s ease;
    }
    .ml-opt:hover:not(:disabled) {
      border-color: var(--cyan, #8be9fd);
      background: rgba(139, 233, 253, 0.06);
      transform: translateX(4px);
    }
    .ml-opt:disabled {
      cursor: default;
    }
    .ml-opt-letter {
      flex: none;
      display: grid;
      place-items: center;
      width: 24px;
      height: 24px;
      border-radius: 6px;
      background: rgba(255, 255, 255, 0.06);
      border: 1px solid var(--line, #44475a);
      font: 700 .75rem "Cascadia Code", monospace;
      color: var(--muted, #9aa1c0);
    }
    .ml-opt.correct {
      border-color: var(--lime, #50fa7b) !important;
      background: rgba(80, 250, 123, 0.12) !important;
      color: #fff;
    }
    .ml-opt.correct .ml-opt-letter {
      background: var(--lime, #50fa7b);
      color: #1e1f29;
      border-color: var(--lime, #50fa7b);
    }
    .ml-opt.wrong {
      border-color: var(--red, #ff5555) !important;
      background: rgba(255, 85, 85, 0.12) !important;
      color: #fff;
    }
    .ml-opt.wrong .ml-opt-letter {
      background: var(--red, #ff5555);
      color: #fff;
      border-color: var(--red, #ff5555);
    }
    .ml-feedback {
      margin-top: 16px;
      border-radius: 12px;
      padding: 16px 18px;
      border: 1px solid var(--line);
      animation: fadeIn .3s ease;
    }
    .feedback-ok {
      background: rgba(80, 250, 123, 0.08);
      border-color: rgba(80, 250, 123, 0.35);
    }
    .feedback-err {
      background: rgba(255, 85, 85, 0.08);
      border-color: rgba(255, 85, 85, 0.35);
    }
    .ml-fb-badge {
      font: 800 .75rem "Inter", sans-serif;
      letter-spacing: .08em;
      text-transform: uppercase;
    }
    .feedback-ok .ml-fb-badge { color: var(--lime, #50fa7b); }
    .feedback-err .ml-fb-badge { color: var(--red, #ff5555); }
    .ml-fb-text {
      margin: 8px 0 12px;
      font: 400 .86rem/1.55 Georgia, serif;
      color: var(--ink2, #dcdce0);
    }
    .ml-fb-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 12px;
      padding-top: 10px;
      border-top: 1px solid rgba(255, 255, 255, 0.08);
    }
    .ml-fb-rec {
      font-size: .82rem;
      color: var(--muted, #9aa1c0);
      flex: 1 1 280px;
    }
    .ml-btn-continue {
      background: var(--purple, #bd93f9);
      color: #1e1f29;
      border: none;
      border-radius: 999px;
      padding: 7px 18px;
      font: 700 .78rem "Inter", sans-serif;
      cursor: pointer;
      transition: filter .15s;
    }
    .ml-btn-continue:hover {
      filter: brightness(1.2);
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-4px); }
      to { opacity: 1; transform: none; }
    }
  `]
})
export class MicrolearningWidgetComponent implements OnInit {
  private readonly storageService: StorageService;

  constructor() {
    let service: StorageService;
    try {
      service = inject(StorageService);
    } catch {
      service = new StorageService();
    }
    this.storageService = service;
  }

  questoes: MicrolearningQuestao[] = MICROLEARNING_QUESTIONS;
  questaoAtual: MicrolearningQuestao | null = null;
  opcaoEscolhida: MicrolearningOpcao | null = null;
  respondido = false;
  acertou = false;

  streak = 0;
  xp = 0;

  ngOnInit(): void {
    this.carregarProgresso();
    this.sortearNovaQuestao();
  }

  carregarProgresso(): void {
    const todayStr = new Date().toISOString().slice(0, 10);
    const lastDate = localStorage.getItem('ml.lastDate');
    let streakVal = parseInt(localStorage.getItem('ml.streak') || '0', 10);

    if (lastDate && lastDate !== todayStr) {
      const diffDays = Math.round((new Date(todayStr).getTime() - new Date(lastDate).getTime()) / 864e5);
      if (diffDays > 1) {
        streakVal = 0;
        localStorage.setItem('ml.streak', '0');
      }
    }
    this.streak = streakVal;
    this.xp = parseInt(localStorage.getItem('quiz_xp') || '0', 10);
  }

  sortearNovaQuestao(): void {
    this.respondido = false;
    this.opcaoEscolhida = null;
    this.acertou = false;

    if (this.questoes.length === 0) return;
    const excludeId = this.questaoAtual?.id;
    const candidates = this.questoes.filter(q => q.id !== excludeId);
    const list = candidates.length > 0 ? candidates : this.questoes;
    this.questaoAtual = list[Math.floor(Math.random() * list.length)];
  }

  responder(opt: MicrolearningOpcao): void {
    if (this.respondido) return;
    this.respondido = true;
    this.opcaoEscolhida = opt;
    this.acertou = opt.correct;

    if (this.acertou) {
      const todayStr = new Date().toISOString().slice(0, 10);
      const lastDate = localStorage.getItem('ml.lastDate');
      if (lastDate !== todayStr) {
        this.streak += 1;
        localStorage.setItem('ml.streak', this.streak.toString());
        localStorage.setItem('ml.lastDate', todayStr);
      }
      this.xp += 50;
      localStorage.setItem('quiz_xp', this.xp.toString());
    }
  }
}
