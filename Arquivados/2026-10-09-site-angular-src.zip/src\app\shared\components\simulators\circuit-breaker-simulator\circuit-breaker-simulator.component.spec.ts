import '@angular/compiler';
import { CircuitBreakerSimulatorComponent } from './circuit-breaker-simulator.component';
import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';

describe('CircuitBreakerSimulatorComponent', () => {
  let comp: CircuitBreakerSimulatorComponent;

  beforeEach(() => {
    vi.useFakeTimers();
    comp = new CircuitBreakerSimulatorComponent();
  });

  afterEach(() => {
    comp.ngOnDestroy();
    vi.useRealTimers();
  });

  it('deve inicializar com estado CLOSED e taxa de erro inicial controlada', () => {
    expect(comp.circuitState()).toBe('CLOSED');
    expect(comp.windowCalls().length).toBe(4);
    expect(comp.errorRate()).toBe(0);
  });

  it('deve forçar disparo do circuito para OPEN', () => {
    comp.forcarDisparo();
    expect(comp.circuitState()).toBe('OPEN');
    expect(comp.errorRate()).toBe(100);
  });

  it('deve alternar para HALF_OPEN ao avançar tempo de espera', () => {
    comp.avancarHalfOpen();
    expect(comp.circuitState()).toBe('HALF_OPEN');
    expect(comp.windowCalls().length).toBe(0);
  });

  it('deve resetar o simulador com estado limpo', () => {
    comp.forcarDisparo();
    expect(comp.circuitState()).toBe('OPEN');

    comp.resetar();
    expect(comp.circuitState()).toBe('CLOSED');
    expect(comp.windowCalls().length).toBe(4);
  });
});
