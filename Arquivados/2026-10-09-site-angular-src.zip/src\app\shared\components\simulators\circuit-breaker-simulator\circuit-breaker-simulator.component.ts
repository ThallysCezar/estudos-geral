import { Component, signal, computed, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface HudLog {
  txt: string;
  cls: 'ch-info' | 'ch-ok' | 'ch-err' | 'ch-warn';
}

export interface ScenarioStep {
  node: number;
  status?: 'ok' | 'err' | 'warn' | 'active';
  logs: HudLog[];
  delay?: number;
}

@Component({
  selector: 'app-circuit-breaker-simulator',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="circuit-lab" id="circuitLab">
      <div class="cl-head">
        <h4>⚡ Laboratório Interativo: Resilience4j Circuit Breaker & Resiliência</h4>
        <span class="sub-label">Simulador de Transição de Estados (Closed ⇋ Open ⇋ Half-Open) e Fallback</span>
      </div>

      <div class="cl-ctrls">
        <button class="btn-cl btn-ok" (click)="requisicaoSucesso()" [disabled]="isRunning()" type="button">
          🟢 Requisição com Sucesso (200 OK)
        </button>
        <button class="btn-cl btn-fail" (click)="injetarFalha()" [disabled]="isRunning()" type="button">
          🔴 Injetar Falha / Timeout (504)
        </button>
        <button class="btn-cl btn-trip" (click)="forcarDisparo()" [disabled]="isRunning()" type="button">
          ⚡ Forçar Disparo (Abrir Circuito)
        </button>
        <button class="btn-cl btn-half" (click)="avancarHalfOpen()" [disabled]="isRunning()" type="button">
          ⏱️ Avançar Espera (Half-Open)
        </button>
        <button class="btn-cl" (click)="resetar()" [disabled]="isRunning()" type="button">
          🔄 Resetar Circuito
        </button>
      </div>

      <div class="cl-flow">
        <!-- 1. Client / Inbound -->
        <div class="cl-node" [ngClass]="getNodeClasses(0)">
          <span class="cn-tag">1. Client / Inbound</span>
          <span class="cn-val">API Gateway<br><small>Chamadas HTTP</small></span>
        </div>

        <!-- 2. Circuit Breaker -->
        <div class="cl-node" [ngClass]="getNodeClasses(1)">
          <span class="cn-tag">2. Circuit Breaker</span>
          <span class="cn-val">
            @if (circuitState() === 'CLOSED') {
              <span style="color:var(--teal)">CLOSED (Fechado)</span>
            } @else if (circuitState() === 'OPEN') {
              <span style="color:var(--rose)">OPEN (Aberto - Fail Fast)</span>
            } @else {
              <span style="color:var(--gold)">HALF-OPEN (Meio Aberto)</span>
            }
          </span>
        </div>

        <!-- 3. Sliding Window -->
        <div class="cl-node" [ngClass]="getNodeClasses(2)">
          <span class="cn-tag">3. Sliding Window</span>
          <span class="cn-val">
            <span class="icons">{{ windowIcons() }}</span><br>
            <small>Erro: {{ errorRate() }}% ({{ failureCount() }}/{{ windowCalls().length }})</small>
          </span>
        </div>

        <!-- 4. Downstream API -->
        <div class="cl-node" [ngClass]="getNodeClasses(3)">
          <span class="cn-tag">4. Downstream API</span>
          <span class="cn-val">Payment Service<br><small>Dependência Crítica</small></span>
        </div>

        <!-- 5. Fallback Handler -->
        <div class="cl-node" [ngClass]="getNodeClasses(4)">
          <span class="cn-tag">5. Fallback Handler</span>
          <span class="cn-val">Cache / Degradação<br><small>Resposta em 1ms</small></span>
        </div>
      </div>

      <div class="cl-hud">
        @for (log of hudLogs(); track $index) {
          <div class="ch-l" [ngClass]="log.cls">{{ log.txt }}</div>
        }
      </div>
    </div>
  `,
  styles: [`
    .circuit-lab {
      margin: 24px 0;
      border: 1px solid var(--line2);
      border-radius: 18px;
      background: #1e1f29;
      padding: 22px;
      box-shadow: 0 16px 40px #00000055;
    }
    .cl-head {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      gap: 12px;
      flex-wrap: wrap;
      border-bottom: 1px solid var(--line);
      padding-bottom: 12px;
    }
    .cl-head h4 {
      margin: 0;
      font: 700 0.85rem "Cascadia Code", monospace;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--cyan);
    }
    .sub-label {
      font-size: 0.76rem;
      color: var(--muted);
    }
    .cl-ctrls {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-top: 14px;
    }
    .btn-cl {
      border: 1px solid var(--line2);
      background: #282a36;
      color: var(--ink);
      font: 600 0.74rem "Inter", sans-serif;
      padding: 8px 14px;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    .btn-cl:hover:not(:disabled) {
      border-color: var(--cyan);
      background: color-mix(in srgb, var(--cyan) 15%, transparent);
      transform: translateY(-2px);
    }
    .btn-cl:active:not(:disabled) {
      transform: scale(0.97);
    }
    .btn-cl:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .btn-cl.btn-ok {
      border-color: color-mix(in srgb, var(--teal) 50%, transparent);
      color: var(--teal);
      background: color-mix(in srgb, var(--teal) 8%, transparent);
    }
    .btn-cl.btn-fail {
      border-color: color-mix(in srgb, var(--rose) 50%, transparent);
      color: var(--rose);
      background: color-mix(in srgb, var(--rose) 8%, transparent);
    }
    .btn-cl.btn-trip {
      border-color: color-mix(in srgb, var(--purple) 50%, transparent);
      color: var(--purple);
      background: color-mix(in srgb, var(--purple) 8%, transparent);
    }
    .btn-cl.btn-half {
      border-color: color-mix(in srgb, var(--gold) 50%, transparent);
      color: var(--gold);
      background: color-mix(in srgb, var(--gold) 8%, transparent);
    }
    .cl-flow {
      display: grid;
      grid-template-columns: repeat(5, minmax(0, 1fr));
      gap: 8px;
      margin: 20px 0 16px;
    }
    @media (max-width: 768px) {
      .cl-flow {
        grid-template-columns: 1fr;
      }
    }
    .cl-node {
      background: #282a36;
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 12px 10px;
      font-size: 0.74rem;
      transition: all 0.3s ease;
    }
    .cl-node .cn-tag {
      font: 700 0.65rem "Cascadia Code", monospace;
      color: var(--muted);
      text-transform: uppercase;
      display: block;
      margin-bottom: 4px;
    }
    .cl-node .cn-val {
      font-weight: 600;
      color: var(--ink);
      display: block;
      line-height: 1.3;
    }
    .cl-node.active {
      border-color: var(--cyan);
      background: radial-gradient(100% 120% at 50% 0%, #8be9fd25, #282a36);
      box-shadow: 0 0 18px #8be9fd44;
      transform: translateY(-2px);
    }
    .cl-node.ok {
      border-color: var(--teal);
      background: radial-gradient(100% 120% at 50% 0%, #50fa7b25, #282a36);
    }
    .cl-node.err {
      border-color: var(--rose);
      background: radial-gradient(100% 120% at 50% 0%, #ff555525, #282a36);
      box-shadow: 0 0 14px #ff555533;
    }
    .cl-node.warn {
      border-color: var(--gold);
      background: radial-gradient(100% 120% at 50% 0%, #f1fa8c25, #282a36);
    }
    .cl-hud {
      background: #14151e;
      border: 1px solid var(--line2);
      border-radius: 12px;
      padding: 14px 18px;
      font: 500 0.74rem "Cascadia Code", monospace;
      color: var(--ink);
      min-height: 90px;
      max-height: 180px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 5px;
    }
    .ch-l {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .ch-info { color: var(--cyan); }
    .ch-ok { color: var(--teal); }
    .ch-err { color: var(--rose); }
    .ch-warn { color: var(--gold); }
  `]
})
export class CircuitBreakerSimulatorComponent implements OnDestroy {
  readonly circuitState = signal<'CLOSED' | 'OPEN' | 'HALF_OPEN'>('CLOSED');
  readonly windowCalls = signal<boolean[]>([true, true, true, true]);
  readonly windowSize = 10;

  readonly isRunning = signal<boolean>(false);
  readonly nodeActive = signal<number | null>(null);
  readonly nodeStatuses = signal<Record<number, string>>({});
  readonly hudLogs = signal<HudLog[]>([
    { txt: '⚡ [Circuit Breaker Ativo] Clique em um dos cenários acima para simular a proteção contra falhas em cascata...', cls: 'ch-info' }
  ]);

  private timerId: ReturnType<typeof setTimeout> | null = null;

  readonly failureCount = computed(() => {
    return this.windowCalls().filter(v => !v).length;
  });

  readonly errorRate = computed(() => {
    const list = this.windowCalls();
    if (!list.length) return 0;
    return Math.round((this.failureCount() / list.length) * 100);
  });

  readonly windowIcons = computed(() => {
    const list = this.windowCalls();
    if (!list.length) return '⚪⚪⚪⚪⚪';
    return list.map(v => (v ? '🟩' : '🟥')).join('');
  });

  getNodeClasses(index: number): Record<string, boolean> {
    const isActive = this.nodeActive() === index;
    const status = this.nodeStatuses()[index] || '';
    return {
      active: isActive,
      ok: status === 'ok',
      err: status === 'err',
      warn: status === 'warn'
    };
  }

  requisicaoSucesso(): void {
    if (this.circuitState() === 'OPEN') {
      this.runScenario([
        { node: 0, logs: [{ cls: 'ch-info', txt: '[Client Gateway] Requisição GET /pedidos/123 recebida.' }], delay: 400 },
        { node: 1, status: 'err', logs: [{ cls: 'ch-err', txt: '⚡ [CircuitBreaker OPEN] Circuito está ABERTO! Chamada downstream BLOQUEADA sem tocar na rede!' }], delay: 500 },
        { node: 4, status: 'ok', logs: [{ cls: 'ch-ok', txt: '🛡️ [Fallback Executado] Retorna dados do cache local Redis ou resposta parcial em 1ms (Sem esgotar threads!).' }], delay: 400 }
      ]);
      return;
    }

    const currentCalls = [...this.windowCalls(), true];
    if (currentCalls.length > this.windowSize) currentCalls.shift();
    this.windowCalls.set(currentCalls);

    if (this.circuitState() === 'HALF_OPEN') {
      const successes = currentCalls.filter(x => x).length;
      if (successes >= 3) {
        this.circuitState.set('CLOSED');
        this.windowCalls.set([true, true, true]);
      }
    }

    this.runScenario([
      { node: 0, logs: [{ cls: 'ch-info', txt: '[Client Gateway] Requisição GET /pedidos/checkout disparada.' }], delay: 400 },
      { node: 1, status: 'ok', logs: [{ cls: 'ch-ok', txt: `[Resilience4j CB] Estado: ${this.circuitState()}. Requisição autorizada a prosseguir.` }], delay: 500 },
      { node: 2, status: 'ok', logs: [{ cls: 'ch-ok', txt: '[Sliding Window] Janela atualizada: Sucesso registrado (200 OK, 38ms).' }], delay: 500 },
      { node: 3, status: 'ok', logs: [{ cls: 'ch-ok', txt: '[Downstream Service] Microsserviço de Pagamentos respondeu com sucesso!' }], delay: 400 }
    ]);
  }

  injetarFalha(): void {
    if (this.circuitState() === 'OPEN') {
      this.runScenario([
        { node: 0, logs: [{ cls: 'ch-info', txt: '[Client Gateway] Requisição recebida.' }], delay: 400 },
        { node: 1, status: 'err', logs: [{ cls: 'ch-err', txt: '⚡ [Fail-Fast] CB já está OPEN! Call downstream nem é disparada. Economia imediata de socket/thread.' }], delay: 500 },
        { node: 4, status: 'ok', logs: [{ cls: 'ch-ok', txt: '🛡️ [Fallback Ativado] Degradação graciosa entregue ao cliente.' }], delay: 400 }
      ]);
      return;
    }

    const currentCalls = [...this.windowCalls(), false];
    if (currentCalls.length > this.windowSize) currentCalls.shift();
    this.windowCalls.set(currentCalls);

    const fails = currentCalls.filter(x => !x).length;
    const rate = Math.round((fails / currentCalls.length) * 100);
    const willTrip = (rate >= 50 && currentCalls.length >= 5) || (this.circuitState() === 'HALF_OPEN');

    this.runScenario([
      { node: 0, logs: [{ cls: 'ch-warn', txt: '[Client Gateway] Requisição POST /pedidos/pagar disparada.' }], delay: 400 },
      { node: 1, status: 'warn', logs: [{ cls: 'ch-info', txt: `[Resilience4j CB] Estado: ${this.circuitState()}. Enviando chamada ao downstream...` }], delay: 500 },
      { node: 3, status: 'err', logs: [{ cls: 'ch-err', txt: '💥 [Downstream Falhou] GatewayTimeout (504) ou Connection Refused no serviço de pagamentos!' }], delay: 600 },
      { node: 2, status: 'err', logs: [{ cls: 'ch-err', txt: `[Sliding Window] Erro registrado. Taxa de falha calculada: ${rate}% (limiar tolerado: 50%).` }], delay: 600 },
      { node: 4, status: 'ok', logs: [{ cls: 'ch-warn', txt: '🛡️ [Fallback Executado] Mensagem enviada para Dead Letter Queue / Outbox para processamento assíncrono posterior.' }], delay: 400 }
    ], () => {
      if (willTrip) {
        this.circuitState.set('OPEN');
        this.hudLogs.update(prev => [
          ...prev,
          { cls: 'ch-err', txt: '🚨 [CIRCUITO DISPAROU -> OPEN] Taxa de falha excedeu 50%! O Circuit Breaker abriu! Próximas chamadas falharão instantaneamente sem sobrecarregar o serviço.' }
        ]);
      }
    });
  }

  forcarDisparo(): void {
    this.circuitState.set('OPEN');
    this.windowCalls.set([false, false, false, false, false]);
    this.runScenario([
      { node: 1, status: 'err', logs: [{ cls: 'ch-err', txt: '🚨 [DISPARO FORÇADO] Circuit Breaker alterado para estado OPEN!' }], delay: 400 },
      { node: 2, status: 'err', logs: [{ cls: 'ch-err', txt: '[Sliding Window] Taxa de erro: 100%. Limiar violado!' }], delay: 400 },
      { node: 4, status: 'ok', logs: [{ cls: 'ch-ok', txt: '🛡️ [Proteção Ativa] Todos os novos requests são desviados para o Fallback em <2ms.' }], delay: 400 }
    ]);
  }

  avancarHalfOpen(): void {
    this.circuitState.set('HALF_OPEN');
    this.windowCalls.set([]);
    this.runScenario([
      { node: 1, status: 'warn', logs: [{ cls: 'ch-warn', txt: '⏱️ [WaitDurationInOpenState Esgotado] Transição de OPEN -> HALF-OPEN.' }], delay: 400 },
      { node: 2, status: 'warn', logs: [{ cls: 'ch-info', txt: '[Trial Probe Mode] Limite de 3 chamadas de teste (permittedNumberOfCallsInHalfOpenState=3).' }], delay: 500 },
      { node: 0, status: 'ok', logs: [{ cls: 'ch-ok', txt: 'Envie requisições de sucesso (btn Verde) para restaurar para CLOSED, ou falha para reabrir imediatamente.' }], delay: 400 }
    ]);
  }

  resetar(): void {
    this.circuitState.set('CLOSED');
    this.windowCalls.set([true, true, true, true]);
    this.clearState();
    this.hudLogs.set([
      { txt: '🔄 [Circuito Resetado] Estado inicial: CLOSED. Janela zerada com chamadas saudáveis.', cls: 'ch-info' }
    ]);
  }

  private clearState(): void {
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
    this.isRunning.set(false);
    this.nodeActive.set(null);
    this.nodeStatuses.set({});
  }

  private runScenario(steps: ScenarioStep[], onComplete?: () => void): void {
    this.clearState();
    this.isRunning.set(true);

    let idx = 0;
    const next = () => {
      if (idx > 0 && steps[idx - 1]) {
        const prev = steps[idx - 1];
        this.nodeStatuses.update(cur => ({
          ...cur,
          [prev.node]: prev.status || 'ok'
        }));
      }

      if (idx < steps.length) {
        const cur = steps[idx];
        this.nodeActive.set(cur.node);
        this.hudLogs.update(logs => [...logs, ...cur.logs]);
        idx++;
        this.timerId = setTimeout(next, cur.delay || 500);
      } else {
        this.nodeActive.set(null);
        this.isRunning.set(false);
        if (onComplete) onComplete();
      }
    };

    next();
  }

  ngOnDestroy(): void {
    if (this.timerId) {
      clearTimeout(this.timerId);
    }
  }
}
