import '@angular/compiler';
import { KubernetesProbeSimulatorComponent } from './kubernetes-probe-simulator.component';
import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';

describe('KubernetesProbeSimulatorComponent', () => {
  let comp: KubernetesProbeSimulatorComponent;

  beforeEach(() => {
    vi.useFakeTimers();
    comp = new KubernetesProbeSimulatorComponent();
  });

  afterEach(() => {
    comp.ngOnDestroy();
    vi.useRealTimers();
  });

  it('deve inicializar o simulador com log inicial de prontidão do kubelet', () => {
    expect(comp.isRunning()).toBe(false);
    expect(comp.hudLogs().length).toBeGreaterThan(0);
    expect(comp.hudLogs()[0].txt).toContain('Kubelet Observando');
  });

  it('deve iniciar o cenário de readiness e registrar logs', () => {
    comp.cenarioReadiness();
    expect(comp.isRunning()).toBe(true);
    expect(comp.hudLogs().length).toBeGreaterThan(0);
  });

  it('deve iniciar o cenário de liveness crashloop e resetar com sucesso', () => {
    comp.cenarioLivenessErr();
    expect(comp.isRunning()).toBe(true);

    comp.resetar();
    expect(comp.isRunning()).toBe(false);
    expect(comp.nodeActive()).toBeNull();
  });
});
