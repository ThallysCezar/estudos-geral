import { Component, signal, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface ProbeHudLog {
  txt: string;
  cls: 'ph-info' | 'ph-ok' | 'ph-err' | 'ph-warn';
}

export interface ProbeScenarioStep {
  node: number;
  status?: 'ok' | 'err' | 'warn' | 'active';
  logs: ProbeHudLog[];
  delay?: number;
}

@Component({
  selector: 'app-kubernetes-probe-simulator',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="probe-lab" id="probeLab">
      <div class="pl-head">
        <h4>⚡ Simulador Interativo · K8s Health Probes & Cascata de Falhas</h4>
        <span class="sub-label">Veja a diferença entre Kubelet cortar tráfego (Readiness) ou matar o Pod (Liveness)</span>
      </div>

      <div class="pl-ctrls">
        <button type="button" class="btn-pl btn-ok" (click)="cenarioReadiness()" [disabled]="isRunning()">
          🟢 1. Banco Oscilou com Readiness (Corte Seguro de Tráfego)
        </button>
        <button type="button" class="btn-pl btn-err" (click)="cenarioLivenessErr()" [disabled]="isRunning()">
          🔴 2. Banco no Liveness (O Desastre: CrashLoopBackOff Geral)
        </button>
        <button type="button" class="btn-pl btn-warn" (click)="cenarioStartupProbe()" [disabled]="isRunning()">
          ⚠️ 3. JVM Subindo sem Startup Probe (Morte Prematura)
        </button>
        <button type="button" class="btn-pl" (click)="resetar()" [disabled]="isRunning()">
          🔄 Reset
        </button>
      </div>

      <div class="pl-flow">
        <!-- Fase 1 -->
        <div class="pl-node" [ngClass]="getNodeClasses(0)">
          <span class="pn-tag">Fase 1</span>
          <span class="pn-val">Evento no Cluster</span>
        </div>

        <!-- Fase 2 -->
        <div class="pl-node" [ngClass]="getNodeClasses(1)">
          <span class="pn-tag">Fase 2</span>
          <span class="pn-val">Sondagem Kubelet</span>
        </div>

        <!-- Fase 3 -->
        <div class="pl-node" [ngClass]="getNodeClasses(2)">
          <span class="pn-tag">Fase 3</span>
          <span class="pn-val">Veredito da Probe</span>
        </div>

        <!-- Fase 4 -->
        <div class="pl-node" [ngClass]="getNodeClasses(3)">
          <span class="pn-tag">Fase 4</span>
          <span class="pn-val">Ação do Kubernetes</span>
        </div>

        <!-- Fase 5 -->
        <div class="pl-node" [ngClass]="getNodeClasses(4)">
          <span class="pn-tag">Fase 5</span>
          <span class="pn-val">Impacto de Produção</span>
        </div>
      </div>

      <div class="pl-hud">
        @for (log of hudLogs(); track $index) {
          <div class="ph-l" [ngClass]="log.cls">{{ log.txt }}</div>
        }
      </div>
    </div>
  `,
  styles: [`
    .probe-lab {
      margin: 24px 0;
      border: 1px solid var(--line2);
      border-radius: 18px;
      background: #1e1f29;
      padding: 22px;
      box-shadow: 0 16px 40px #00000055;
    }
    .pl-head {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      gap: 12px;
      flex-wrap: wrap;
      border-bottom: 1px solid var(--line);
      padding-bottom: 12px;
    }
    .pl-head h4 {
      margin: 0;
      font: 700 0.85rem "Cascadia Code", monospace;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--cyan);
    }
    .sub-label {
      font-size: 0.76rem;
      color: var(--muted);
    }
    .pl-ctrls {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-top: 14px;
    }
    .btn-pl {
      border: 1px solid var(--line2);
      background: #282a36;
      color: var(--ink);
      font: 600 0.74rem "Inter", sans-serif;
      padding: 8px 14px;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    .btn-pl:hover:not(:disabled) {
      border-color: var(--cyan);
      background: color-mix(in srgb, var(--cyan) 15%, transparent);
      transform: translateY(-2px);
    }
    .btn-pl:active:not(:disabled) {
      transform: scale(0.97);
    }
    .btn-pl:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .btn-pl.btn-ok {
      border-color: color-mix(in srgb, var(--teal) 50%, transparent);
      color: var(--teal);
      background: color-mix(in srgb, var(--teal) 8%, transparent);
    }
    .btn-pl.btn-err {
      border-color: color-mix(in srgb, var(--rose) 50%, transparent);
      color: var(--rose);
      background: color-mix(in srgb, var(--rose) 8%, transparent);
    }
    .btn-pl.btn-warn {
      border-color: color-mix(in srgb, var(--gold) 50%, transparent);
      color: var(--gold);
      background: color-mix(in srgb, var(--gold) 8%, transparent);
    }
    .pl-flow {
      display: grid;
      grid-template-columns: repeat(5, minmax(0, 1fr));
      gap: 8px;
      margin: 20px 0 16px;
    }
    @media (max-width: 768px) {
      .pl-flow {
        grid-template-columns: 1fr;
      }
    }
    .pl-node {
      background: #282a36;
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 12px 10px;
      font-size: 0.74rem;
      transition: all 0.3s ease;
    }
    .pl-node .pn-tag {
      font: 700 0.65rem "Cascadia Code", monospace;
      color: var(--muted);
      text-transform: uppercase;
      display: block;
      margin-bottom: 4px;
    }
    .pl-node .pn-val {
      font-weight: 600;
      color: var(--ink);
      display: block;
      line-height: 1.3;
    }
    .pl-node.active {
      border-color: var(--cyan);
      background: radial-gradient(100% 120% at 50% 0%, #8be9fd25, #282a36);
      box-shadow: 0 0 18px #8be9fd44;
      transform: translateY(-2px);
    }
    .pl-node.ok {
      border-color: var(--teal);
      background: radial-gradient(100% 120% at 50% 0%, #50fa7b25, #282a36);
    }
    .pl-node.err {
      border-color: var(--rose);
      background: radial-gradient(100% 120% at 50% 0%, #ff555525, #282a36);
      box-shadow: 0 0 14px #ff555533;
    }
    .pl-node.warn {
      border-color: var(--gold);
      background: radial-gradient(100% 120% at 50% 0%, #f1fa8c25, #282a36);
    }
    .pl-hud {
      background: #14151e;
      border: 1px solid var(--line2);
      border-radius: 12px;
      padding: 14px 18px;
      font: 500 0.74rem "Cascadia Code", monospace;
      color: var(--ink);
      min-height: 90px;
      max-height: 180px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 5px;
    }
    .ph-l {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .ph-info { color: var(--cyan); }
    .ph-ok { color: var(--teal); }
    .ph-err { color: var(--rose); }
    .ph-warn { color: var(--gold); }
  `]
})
export class KubernetesProbeSimulatorComponent implements OnDestroy {
  readonly isRunning = signal<boolean>(false);
  readonly nodeActive = signal<number | null>(null);
  readonly nodeStatuses = signal<Record<number, string>>({});
  readonly hudLogs = signal<ProbeHudLog[]>([
    { txt: '[Kubelet Observando] Escolha um cenário para testar a resiliência das probes...', cls: 'ph-info' }
  ]);

  private timerId: ReturnType<typeof setTimeout> | null = null;

  getNodeClasses(index: number): Record<string, boolean> {
    const isActive = this.nodeActive() === index;
    const status = this.nodeStatuses()[index] || '';
    return {
      active: isActive,
      ok: status === 'ok',
      err: status === 'err',
      warn: status === 'warn'
    };
  }

  cenarioReadiness(): void {
    this.runScenario([
      { node: 0, logs: [{ cls: 'ph-warn', txt: '[Cluster Event] PostgreSQL sofre spike de CPU ou failover de 30s.' }], delay: 400 },
      { node: 1, status: 'warn', logs: [{ cls: 'ph-info', txt: '[Kubelet Probe] GET /actuator/health/readiness -> status DOWN (503 Service Unavailable).' }], delay: 450 },
      { node: 2, status: 'warn', logs: [{ cls: 'ph-warn', txt: '[Readiness Reprovado] failureThreshold atingido (2/2). Liveness continua PASSANDO (200 OK).' }], delay: 500 },
      { node: 3, status: 'ok', logs: [{ cls: 'ph-ok', txt: '[K8s Endpoint Controller] Remove o IP do Pod dos Endpoints do Service. Tráfego de novas requisições é pausado imediatamente!' }], delay: 500 },
      { node: 4, status: 'ok', logs: [{ cls: 'ph-ok', txt: '🛡️ [ZERO RESTARTS] O container continua vivo e saudável! Quando o banco volta, readiness passa e o Pod retorna ao tráfego em 2s sem reiniciar.' }], delay: 400 }
    ]);
  }

  cenarioLivenessErr(): void {
    this.runScenario([
      { node: 0, logs: [{ cls: 'ph-warn', txt: '[Cluster Event] PostgreSQL fica lento ou indisponível temporariamente por 40s.' }], delay: 400 },
      { node: 1, status: 'err', logs: [{ cls: 'ph-err', txt: '[ERRO DE ARQUITETURA] Desenvolvedor colocou verificação de banco dentro do LivenessProbe!' }], delay: 450 },
      { node: 2, status: 'err', logs: [{ cls: 'ph-err', txt: '[Liveness Reprovado] GET /health falha porque o banco não respondeu em 1s.' }], delay: 500 },
      { node: 3, status: 'err', logs: [{ cls: 'ph-err', txt: '☠️ [Kubelet SIGKILL] Kubelet entende que a aplicação travou: mata o container e recria o Pod!' }], delay: 500 },
      { node: 4, status: 'err', logs: [{ cls: 'ph-err', txt: '💥 [CASCATA / CRASHLOOPBACKOFF] Todos os 20 Pods morrem e tentam reconectar ao banco juntos, sobrecarregando o banco e entrando em CrashLoopBackOff infinito!' }], delay: 400 }
    ]);
  }

  cenarioStartupProbe(): void {
    this.runScenario([
      { node: 0, logs: [{ cls: 'ph-info', txt: '[Novo Deployment] Pod da aplicação Spring Boot é agendado no node.' }], delay: 400 },
      { node: 1, status: 'warn', logs: [{ cls: 'ph-warn', txt: '[JVM Inicializando] Spring Boot leva 40 segundos carregando beans, Flyway e conexões.' }], delay: 450 },
      { node: 2, status: 'err', logs: [{ cls: 'ph-err', txt: '⚠️ [Sem StartupProbe] LivenessProbe configurada com initialDelaySeconds=10s já começa a disparar!' }], delay: 500 },
      { node: 3, status: 'err', logs: [{ cls: 'ph-err', txt: '[Morte Prematura] Kubelet recebe Connection Refused no segundo 15 e mata o Pod antes dele terminar de subir.' }], delay: 500 },
      { node: 4, status: 'ok', logs: [{ cls: 'ph-ok', txt: '✅ [Fix com StartupProbe] Configure startupProbe com failureThreshold=30 e periodSeconds=5 (concede até 150s para subir sem morrer).' }], delay: 400 }
    ]);
  }

  resetar(): void {
    this.clearState();
    this.hudLogs.set([
      { txt: '[Kubelet Observando] Escolha um cenário para testar a resiliência das probes...', cls: 'ph-info' }
    ]);
  }

  private clearState(): void {
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
    this.isRunning.set(false);
    this.nodeActive.set(null);
    this.nodeStatuses.set({});
  }

  private runScenario(steps: ProbeScenarioStep[]): void {
    this.clearState();
    this.isRunning.set(true);

    let idx = 0;
    const next = () => {
      if (idx > 0 && steps[idx - 1]) {
        const prev = steps[idx - 1];
        this.nodeStatuses.update(cur => ({
          ...cur,
          [prev.node]: prev.status || 'ok'
        }));
      }

      if (idx < steps.length) {
        const cur = steps[idx];
        this.nodeActive.set(cur.node);
        this.hudLogs.update(logs => [...logs, ...cur.logs]);
        idx++;
        this.timerId = setTimeout(next, cur.delay || 500);
      } else {
        this.nodeActive.set(null);
        this.isRunning.set(false);
      }
    };

    next();
  }

  ngOnDestroy(): void {
    if (this.timerId) {
      clearTimeout(this.timerId);
    }
  }
}
