import '@angular/compiler';
import { VpcNetworkSimulatorComponent } from './vpc-network-simulator.component';
import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';

describe('VpcNetworkSimulatorComponent', () => {
  let comp: VpcNetworkSimulatorComponent;

  beforeEach(() => {
    vi.useFakeTimers();
    comp = new VpcNetworkSimulatorComponent();
  });

  afterEach(() => {
    comp.ngOnDestroy();
    vi.useRealTimers();
  });

  it('deve inicializar o simulador VPC com topologia pronta', () => {
    expect(comp.isRunning()).toBe(false);
    expect(comp.hudLogs().length).toBeGreaterThan(0);
    expect(comp.hudLogs()[0].txt).toContain('VPC Topologia Pronta');
  });

  it('deve executar o cenário de tráfego normal', () => {
    comp.cenarioNormal();
    expect(comp.isRunning()).toBe(true);
    expect(comp.hudLogs().length).toBeGreaterThan(0);
  });

  it('deve executar o cenário de bloqueio de Security Group e permitir reset', () => {
    comp.cenarioSgDrop();
    expect(comp.isRunning()).toBe(true);

    comp.resetar();
    expect(comp.isRunning()).toBe(false);
    expect(comp.nodeActive()).toBeNull();
  });
});
