import { Component, signal, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface VpcHudLog {
  txt: string;
  cls: 'vh-info' | 'vh-ok' | 'vh-err' | 'vh-warn';
}

export interface VpcScenarioStep {
  node: number;
  status?: 'ok' | 'err' | 'warn' | 'active';
  logs: VpcHudLog[];
  delay?: number;
}

@Component({
  selector: 'app-vpc-network-simulator',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="vpc-lab" id="vpcLab">
      <div class="vl-head">
        <h4>⚡ Simulador Interativo · Topologia de Rede VPC, Subnets & Security Groups</h4>
        <span class="sub-label">Simule pacotes de rede entre Internet, Subnet Pública (ALB), NAT Gateway, Subnet Privada (App) e Subnet de Dados (DB)</span>
      </div>

      <div class="vl-ctrls">
        <button type="button" class="btn-vl btn-ok" (click)="cenarioNormal()" [disabled]="isRunning()">
          🟢 1. Tráfego Normal (Internet → ALB → App → DB)
        </button>
        <button type="button" class="btn-vl btn-err" (click)="cenarioDirectDb()" [disabled]="isRunning()">
          🔴 2. Internet Direto ao DB (Bloqueio Route Table)
        </button>
        <button type="button" class="btn-vl btn-warn" (click)="cenarioSgDrop()" [disabled]="isRunning()">
          ⚠️ 3. Bloqueio Security Group (Falta 5432 Ingress)
        </button>
        <button type="button" class="btn-vl" (click)="cenarioNat()" [disabled]="isRunning()">
          🌐 4. Saída Egress via NAT Gateway (App → NAT → Internet)
        </button>
        <button type="button" class="btn-vl" (click)="resetar()" [disabled]="isRunning()">
          🔄 Reset
        </button>
      </div>

      <div class="vl-flow">
        <!-- 0: Borda -->
        <div class="vl-node" [ngClass]="getNodeClasses(0)">
          <span class="vn-tag">Origem / Borda</span>
          <span class="vn-val">Internet / Cliente</span>
        </div>

        <!-- 1: Subnet Pública ALB -->
        <div class="vl-node" [ngClass]="getNodeClasses(1)">
          <span class="vn-tag">Subnet Pública</span>
          <span class="vn-val">Internet Gateway & ALB</span>
        </div>

        <!-- 2: Subnet Privada App -->
        <div class="vl-node" [ngClass]="getNodeClasses(2)">
          <span class="vn-tag">Subnet Privada</span>
          <span class="vn-val">Spring Boot App</span>
        </div>

        <!-- 3: Subnet Isolada Dados -->
        <div class="vl-node" [ngClass]="getNodeClasses(3)">
          <span class="vn-tag">Subnet Isolada</span>
          <span class="vn-val">RDS PostgreSQL</span>
        </div>

        <!-- 4: Subnet Pública NAT -->
        <div class="vl-node" [ngClass]="getNodeClasses(4)">
          <span class="vn-tag">Subnet Pública</span>
          <span class="vn-val">NAT Gateway</span>
        </div>
      </div>

      <div class="vl-hud">
        @for (log of hudLogs(); track $index) {
          <div class="vh-l" [ngClass]="log.cls">{{ log.txt }}</div>
        }
      </div>
    </div>
  `,
  styles: [`
    .vpc-lab {
      margin: 24px 0;
      border: 1px solid var(--line2);
      border-radius: 18px;
      background: #1e1f29;
      padding: 22px;
      box-shadow: 0 16px 40px #00000055;
    }
    .vl-head {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      gap: 12px;
      flex-wrap: wrap;
      border-bottom: 1px solid var(--line);
      padding-bottom: 12px;
    }
    .vl-head h4 {
      margin: 0;
      font: 700 0.85rem "Cascadia Code", monospace;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--cyan);
    }
    .sub-label {
      font-size: 0.76rem;
      color: var(--muted);
    }
    .vl-ctrls {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-top: 14px;
    }
    .btn-vl {
      border: 1px solid var(--line2);
      background: #282a36;
      color: var(--ink);
      font: 600 0.74rem "Inter", sans-serif;
      padding: 8px 14px;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    .btn-vl:hover:not(:disabled) {
      border-color: var(--cyan);
      background: color-mix(in srgb, var(--cyan) 15%, transparent);
      transform: translateY(-2px);
    }
    .btn-vl:active:not(:disabled) {
      transform: scale(0.97);
    }
    .btn-vl:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .btn-vl.btn-ok {
      border-color: color-mix(in srgb, var(--teal) 50%, transparent);
      color: var(--teal);
      background: color-mix(in srgb, var(--teal) 8%, transparent);
    }
    .btn-vl.btn-err {
      border-color: color-mix(in srgb, var(--rose) 50%, transparent);
      color: var(--rose);
      background: color-mix(in srgb, var(--rose) 8%, transparent);
    }
    .btn-vl.btn-warn {
      border-color: color-mix(in srgb, var(--gold) 50%, transparent);
      color: var(--gold);
      background: color-mix(in srgb, var(--gold) 8%, transparent);
    }
    .vl-flow {
      display: grid;
      grid-template-columns: repeat(5, minmax(0, 1fr));
      gap: 8px;
      margin: 20px 0 16px;
    }
    @media (max-width: 768px) {
      .vl-flow {
        grid-template-columns: 1fr;
      }
    }
    .vl-node {
      background: #282a36;
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 12px 10px;
      font-size: 0.74rem;
      transition: all 0.3s ease;
    }
    .vl-node .vn-tag {
      font: 700 0.65rem "Cascadia Code", monospace;
      color: var(--muted);
      text-transform: uppercase;
      display: block;
      margin-bottom: 4px;
    }
    .vl-node .vn-val {
      font-weight: 600;
      color: var(--ink);
      display: block;
      line-height: 1.3;
    }
    .vl-node.active {
      border-color: var(--cyan);
      background: radial-gradient(100% 120% at 50% 0%, #8be9fd25, #282a36);
      box-shadow: 0 0 18px #8be9fd44;
      transform: translateY(-2px);
    }
    .vl-node.ok {
      border-color: var(--teal);
      background: radial-gradient(100% 120% at 50% 0%, #50fa7b25, #282a36);
    }
    .vl-node.err {
      border-color: var(--rose);
      background: radial-gradient(100% 120% at 50% 0%, #ff555525, #282a36);
      box-shadow: 0 0 14px #ff555533;
    }
    .vl-node.warn {
      border-color: var(--gold);
      background: radial-gradient(100% 120% at 50% 0%, #f1fa8c25, #282a36);
    }
    .vl-hud {
      background: #14151e;
      border: 1px solid var(--line2);
      border-radius: 12px;
      padding: 14px 18px;
      font: 500 0.74rem "Cascadia Code", monospace;
      color: var(--ink);
      min-height: 90px;
      max-height: 180px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 5px;
    }
    .vh-l {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .vh-info { color: var(--cyan); }
    .vh-ok { color: var(--teal); }
    .vh-err { color: var(--rose); }
    .vh-warn { color: var(--gold); }
  `]
})
export class VpcNetworkSimulatorComponent implements OnDestroy {
  readonly isRunning = signal<boolean>(false);
  readonly nodeActive = signal<number | null>(null);
  readonly nodeStatuses = signal<Record<number, string>>({});
  readonly hudLogs = signal<VpcHudLog[]>([
    { txt: '🌐 [VPC Topologia Pronta] Escolha um cenário acima para simular o roteamento e filtros de segurança...', cls: 'vh-info' }
  ]);

  private timerId: ReturnType<typeof setTimeout> | null = null;

  getNodeClasses(index: number): Record<string, boolean> {
    const isActive = this.nodeActive() === index;
    const status = this.nodeStatuses()[index] || '';
    return {
      active: isActive,
      ok: status === 'ok',
      err: status === 'err',
      warn: status === 'warn'
    };
  }

  cenarioNormal(): void {
    this.runScenario([
      { node: 0, logs: [{ cls: 'vh-info', txt: '[Cliente Web] Requisição HTTPS enviada para https://app.empresa.com. Consulta DNS Route 53 aponta para o ALB na Subnet Pública.' }], delay: 400 },
      { node: 1, status: 'ok', logs: [{ cls: 'vh-ok', txt: '[Subnet Pública - ALB] Internet Gateway encaminha pacote. Application Load Balancer realiza TLS Termination e inspeciona headers.' }], delay: 450 },
      { node: 2, status: 'ok', logs: [{ cls: 'vh-ok', txt: '[Subnet Privada - Spring API] ALB encaminha HTTP para o Pod/Instância (10.0.11.45:8080). Security Group autoriza porta 8080 com origem no SG do ALB.' }], delay: 500 },
      { node: 3, status: 'ok', logs: [{ cls: 'vh-ok', txt: '✅ [Subnet Isolada - PostgreSQL RDS] Spring Boot conecta via JDBC na porta 5432 (10.0.21.80). SG do RDS autoriza tráfego exclusivamente do SG da App. Transação executada com sucesso!' }], delay: 400 }
    ]);
  }

  cenarioDirectDb(): void {
    this.runScenario([
      { node: 0, logs: [{ cls: 'vh-info', txt: '[Atacante Externo] Varredura automatizada na internet tenta conexão direta na porta 5432 do IP privado do PostgreSQL (10.0.21.80).' }], delay: 400 },
      { node: 1, status: 'err', logs: [{ cls: 'vh-err', txt: '[Internet Gateway / VPC Edge] O bloco 10.0.21.0/24 é privado (RFC 1918). A Tabela de Rotas da Subnet de Dados não possui entrada 0.0.0.0/0 para o IGW.' }], delay: 500 },
      { node: 3, status: 'err', logs: [{ cls: 'vh-err', txt: '🚫 [DROP SILENCIOSO] Subnet Isolada sem rota externa e sem IP público. Pacotes descartados na borda da VPC. Banco de dados completamente invisível na internet pública!' }], delay: 400 }
    ]);
  }

  cenarioSgDrop(): void {
    this.runScenario([
      { node: 0, logs: [{ cls: 'vh-info', txt: '[Cliente Web] Requisição normal recebida no ALB.' }], delay: 400 },
      { node: 1, status: 'ok', logs: [{ cls: 'vh-ok', txt: '[Subnet Pública - ALB] ALB repassa requisição para a Spring Boot API.' }], delay: 400 },
      { node: 2, status: 'warn', logs: [{ cls: 'vh-warn', txt: '[Subnet Privada - App] Spring Boot tenta estabelecer conexão TCP na porta 5432 com o RDS (10.0.21.80).' }], delay: 450 },
      { node: 3, status: 'err', logs: [{ cls: 'vh-err', txt: '⚠️ [Security Group DROP] O Security Group do RDS NÃO possui regra de Ingress liberando a porta 5432 para o SG da aplicação. Pacote descartado silenciosamente (DROP L4).' }], delay: 500 },
      { node: 2, status: 'err', logs: [{ cls: 'vh-err', txt: '💥 [HikariCP ConnectionTimeout] Falha na aplicação: Connection to 10.0.21.80:5432 timed out (3000ms). Falhas de Security Group causam timeout por descarte silencioso, não Connection Refused!' }], delay: 400 }
    ]);
  }

  cenarioNat(): void {
    this.runScenario([
      { node: 2, logs: [{ cls: 'vh-info', txt: '[Subnet Privada - App] Worker Spring Boot precisa chamar API externa da Stripe (https://api.stripe.com/v1) para confirmar pagamento.' }], delay: 400 },
      { node: 4, status: 'ok', logs: [{ cls: 'vh-ok', txt: '[Subnet Pública - NAT Gateway] Tabela de rotas da subnet privada direciona 0.0.0.0/0 para o NAT Gateway (10.0.1.100). NAT realiza Source NAT (SNAT), alocando seu IP público elástico.' }], delay: 500 },
      { node: 0, status: 'ok', logs: [{ cls: 'vh-ok', txt: '🌐 [Internet Pública] Pacote cruza o IGW, alcança a Stripe e recebe resposta 200 OK. NAT Gateway consulta sua connection tracking table e desfaz o NAT para 10.0.11.45.' }], delay: 450 },
      { node: 2, status: 'ok', logs: [{ cls: 'vh-ok', txt: '✅ [Retorno Seguro] Spring Boot recebe resposta da Stripe. Nenhum serviço externo conseguiu iniciar conexão para a rede privada!' }], delay: 400 }
    ]);
  }

  resetar(): void {
    this.clearState();
    this.hudLogs.set([
      { txt: '🌐 [VPC Topologia Pronta] Escolha um cenário acima para simular o roteamento e filtros de segurança...', cls: 'vh-info' }
    ]);
  }

  private clearState(): void {
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
    this.isRunning.set(false);
    this.nodeActive.set(null);
    this.nodeStatuses.set({});
  }

  private runScenario(steps: VpcScenarioStep[]): void {
    this.clearState();
    this.isRunning.set(true);

    let idx = 0;
    const next = () => {
      if (idx > 0 && steps[idx - 1]) {
        const prev = steps[idx - 1];
        this.nodeStatuses.update(cur => ({
          ...cur,
          [prev.node]: prev.status || 'ok'
        }));
      }

      if (idx < steps.length) {
        const cur = steps[idx];
        this.nodeActive.set(cur.node);
        this.hudLogs.update(logs => [...logs, ...cur.logs]);
        idx++;
        this.timerId = setTimeout(next, cur.delay || 500);
      } else {
        this.nodeActive.set(null);
        this.isRunning.set(false);
      }
    };

    next();
  }

  ngOnDestroy(): void {
    if (this.timerId) {
      clearTimeout(this.timerId);
    }
  }
}
