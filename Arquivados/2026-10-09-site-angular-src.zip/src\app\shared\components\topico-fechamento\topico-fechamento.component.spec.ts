// @vitest-environment jsdom
import { TopicoFechamentoComponent, ExercicioOpcao } from './topico-fechamento.component';
import { StorageService } from '../../../core/services/storage.service';
import { describe, it, expect, beforeEach } from 'vitest';

describe('TopicoFechamentoComponent', () => {
  let comp: TopicoFechamentoComponent;
  let storage: StorageService;

  beforeEach(() => {
    localStorage.clear();
    comp = new TopicoFechamentoComponent();
    // Injeção de storage de teste
    (comp as any).storageService = new StorageService();
  });

  it('deve alternar o estado do flashcard ao virar', () => {
    expect(comp.flashcardVirado()).toBe(false);
    comp.virarFlashcard();
    expect(comp.flashcardVirado()).toBe(true);
    comp.virarFlashcard();
    expect(comp.flashcardVirado()).toBe(false);
  });

  it('deve computar resposta correta e pontuar +50 XP no localStorage', () => {
    const opcaoCorreta: ExercicioOpcao = {
      letra: 'B',
      texto: 'Opção correta',
      correta: true,
      rationale: 'Explicado com sucesso'
    };

    comp.responder(opcaoCorreta);

    expect(comp.respondido()).toBe(true);
    expect(comp.acertou()).toBe(true);
    expect(comp.opcaoEscolhida()).toBe('B');
    expect(comp.feedbackTexto()).toBe('Explicado com sucesso');
    expect(localStorage.getItem('quiz_xp')).toBe('50');
  });

  it('deve alternar o estado de tópico dominado e persistir', () => {
    comp.topicoId = 'sd_t1';
    comp.ngOnInit();
    expect(comp.isDominado()).toBe(false);

    comp.toggleDominado();
    expect(comp.isDominado()).toBe(true);
    expect(localStorage.getItem('topico_sd_t1_dominado')).toBe('true');

    comp.toggleDominado();
    expect(comp.isDominado()).toBe(false);
    expect(localStorage.getItem('topico_sd_t1_dominado')).toBe('false');
  });
});
