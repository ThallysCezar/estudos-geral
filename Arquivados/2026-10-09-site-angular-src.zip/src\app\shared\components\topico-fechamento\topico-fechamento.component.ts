import { Component, Input, inject, signal } from '@angular/core';
import { StorageService } from '../../../core/services/storage.service';

export interface RevisaoPonto {
  cor: 'teal' | 'purple' | 'rose';
  titulo: string;
  texto: string;
}

export interface ExercicioOpcao {
  letra: 'A' | 'B' | 'C' | 'D';
  texto: string;
  correta: boolean;
  rationale: string;
}

export interface ExercicioDados {
  id: string;
  cenario: string;
  instrucao?: string;
  opcoes: ExercicioOpcao[];
}

export interface FlashcardDados {
  pergunta: string;
  dica?: string;
  resposta: string;
}

@Component({
  selector: 'app-topico-fechamento',
  standalone: true,
  template: `
    <div class="topico-fechamento">
      <!-- A. REVISÃO -->
      @if (pontosRevisao && pontosRevisao.length > 0) {
        <div class="topico-revisao">
          <div class="tr-header">
            <span class="tr-badge">🧠 RECAPITULANDO O ASSUNTO</span>
            <h4 class="tr-title">{{ tituloRevisao || 'Síntese de Fixação' }}</h4>
          </div>

          <div class="tr-grid">
            @for (p of pontosRevisao; track p.titulo) {
              <div class="tr-item">
                <span class="tr-dot" [class]="p.cor"></span>
                <div class="tr-corpo">
                  <b>{{ p.titulo }}</b>
                  <p>{{ p.texto }}</p>
                </div>
              </div>
            }
          </div>

          @if (pegadinha || modeloMental) {
            <div class="tr-takeaway">
              @if (pegadinha) {
                <div class="tr-takeaway-item alert">
                  <span class="tr-icon">⚠️</span>
                  <div>
                    <b>Armadilha Comum:</b>
                    <p>{{ pegadinha }}</p>
                  </div>
                </div>
              }
              @if (modeloMental) {
                <div class="tr-takeaway-item tip">
                  <span class="tr-icon">💡</span>
                  <div>
                    <b>Modelo Mental:</b>
                    <p>{{ modeloMental }}</p>
                  </div>
                </div>
              }
            </div>
          }
        </div>
      }

      <!-- B. EXERCÍCIO INTERATIVO -->
      @if (exercicio) {
        <div class="topico-exercicio">
          <div class="te-header">
            <div class="te-badge">
              <span class="te-icon">🎮</span>
              <span>DESAFIO PRÁTICO #{{ exercicio.id }}</span>
            </div>
            <div class="te-reward">
              <span class="te-xp-badge">⭐ +50 XP</span>
              <span class="te-status">
                {{ respondido() ? (acertou() ? '✓ Concluído' : 'Tente novamente') : 'Aguardando resposta' }}
              </span>
            </div>
          </div>

          <div class="te-body">
            <p class="te-pergunta"><strong>Cenário:</strong> {{ exercicio.cenario }}</p>
            @if (exercicio.instrucao) {
              <p class="te-instrucao">{{ exercicio.instrucao }}</p>
            }

            <div class="te-options">
              @for (op of exercicio.opcoes; track op.letra) {
                <button
                  type="button"
                  class="te-opt"
                  [class.correta]="respondido() && op.correta"
                  [class.errada]="opcaoEscolhida() === op.letra && !op.correta"
                  (click)="responder(op)"
                >
                  <span class="te-letter">{{ op.letra }}</span>
                  {{ op.texto }}
                </button>
              }
            </div>

            @if (feedbackTexto()) {
              <div class="te-feedback" [class.sucesso]="acertou()" [class.falha]="!acertou()">
                {{ feedbackTexto() }}
              </div>
            }
          </div>
        </div>
      }

      <!-- C. FLASHCARD ROTATIVO -->
      @if (flashcard) {
        <div class="topico-flashcard" (click)="virarFlashcard()">
          <div class="tf-card" [class.virado]="flashcardVirado()">
            <div class="tf-face tf-front">
              <div class="tf-tag">🃏 FLASHCARD · CLIQUE PARA VIRAR</div>
              <p class="tf-pergunta">{{ flashcard.pergunta }}</p>
              @if (flashcard.dica) {
                <span class="tf-hint">{{ flashcard.dica }}</span>
              }
            </div>
            <div class="tf-face tf-back">
              <div class="tf-tag ok">✓ RESPOSTA TÉCNICA</div>
              <p class="tf-resposta">{{ flashcard.resposta }}</p>
              <span class="tf-hint">← Clique para voltar à pergunta</span>
            </div>
          </div>
        </div>
      }

      <!-- D. BOTÃO MARCAR DOMINADO -->
      @if (topicoId) {
        <div class="dominado-wrap">
          <button
            type="button"
            class="done-btn"
            [class.dominado]="isDominado()"
            (click)="toggleDominado()"
          >
            {{ isDominado() ? '✓ Tópico Dominado' : 'Marcar como dominado' }}
          </button>
        </div>
      }
    </div>
  `,
  styles: [`
    .topico-fechamento {
      margin-top: 36px;
      padding-top: 28px;
      border-top: 1px solid var(--line);
    }
    .topico-revisao {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 18px;
      padding: 24px;
      margin-bottom: 24px;
    }
    .tr-badge {
      font: 700 .62rem "Cascadia Code", monospace;
      color: var(--teal);
      letter-spacing: .12em;
    }
    .tr-title {
      margin: 8px 0 18px;
      font: 500 1.25rem Georgia, serif;
      color: var(--ink);
    }
    .tr-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 16px;
      margin-bottom: 20px;
    }
    .tr-item {
      display: flex;
      gap: 12px;
    }
    .tr-dot {
      width: 9px;
      height: 9px;
      border-radius: 50%;
      margin-top: 6px;
      flex-shrink: 0;
    }
    .tr-dot.teal { background: var(--teal); }
    .tr-dot.purple { background: var(--purple); }
    .tr-dot.rose { background: var(--rose); }
    .tr-corpo b {
      display: block;
      font-size: .88rem;
      color: var(--ink);
      margin-bottom: 4px;
    }
    .tr-corpo p {
      margin: 0;
      font-size: .82rem;
      color: var(--muted);
      line-height: 1.5;
    }
    .tr-takeaway {
      display: grid;
      gap: 12px;
      padding-top: 16px;
      border-top: 1px solid var(--line);
    }
    .tr-takeaway-item {
      display: flex;
      gap: 12px;
      padding: 12px 14px;
      border-radius: 10px;
      background: #1e1f29;
      font-size: .82rem;
    }
    .tr-takeaway-item.alert { border-left: 3px solid var(--orange); }
    .tr-takeaway-item.tip { border-left: 3px solid var(--cyan); }
    .tr-takeaway-item p { margin: 4px 0 0; color: var(--muted); }

    /* Exercício */
    .topico-exercicio {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 18px;
      padding: 24px;
      margin-bottom: 24px;
    }
    .te-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }
    .te-badge {
      font: 700 .62rem "Cascadia Code", monospace;
      color: var(--purple);
    }
    .te-reward {
      display: flex;
      gap: 10px;
      align-items: center;
      font: 600 .72rem "Inter", sans-serif;
    }
    .te-xp-badge { color: var(--gold); }
    .te-status { color: var(--muted); }
    .te-pergunta {
      font-size: .9rem;
      color: var(--ink);
      line-height: 1.6;
      margin-bottom: 14px;
    }
    .te-instrucao {
      font-size: .85rem;
      color: var(--muted);
      margin-bottom: 16px;
    }
    .te-options {
      display: grid;
      gap: 10px;
    }
    .te-opt {
      text-align: left;
      background: #1e1f29;
      border: 1px solid var(--line2);
      border-radius: 12px;
      padding: 14px 16px;
      color: var(--ink2);
      font: inherit;
      font-size: .84rem;
      line-height: 1.5;
      cursor: pointer;
      display: flex;
      gap: 12px;
      transition: border-color .2s, background .2s;
    }
    .te-opt:hover {
      border-color: var(--purple);
      background: color-mix(in srgb, var(--purple) 8%, transparent);
    }
    .te-opt.correta {
      border-color: var(--teal) !important;
      background: color-mix(in srgb, var(--teal) 14%, transparent) !important;
      color: var(--ink);
    }
    .te-opt.errada {
      border-color: var(--rose) !important;
      background: color-mix(in srgb, var(--rose) 14%, transparent) !important;
    }
    .te-letter {
      font: 700 .7rem "Cascadia Code", monospace;
      padding: 2px 7px;
      background: #282a36;
      border-radius: 4px;
      color: var(--muted);
      align-self: flex-start;
    }
    .te-feedback {
      margin-top: 14px;
      padding: 12px 16px;
      border-radius: 10px;
      font-size: .84rem;
      line-height: 1.5;
    }
    .te-feedback.sucesso {
      background: color-mix(in srgb, var(--teal) 12%, transparent);
      border: 1px solid var(--teal);
      color: var(--ink);
    }
    .te-feedback.falha {
      background: color-mix(in srgb, var(--rose) 12%, transparent);
      border: 1px solid var(--rose);
      color: var(--ink);
    }

    /* Flashcard */
    .topico-flashcard {
      cursor: pointer;
      perspective: 1000px;
      margin-bottom: 24px;
    }
    .tf-card {
      position: relative;
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 18px;
      padding: 26px;
      min-height: 140px;
      transition: transform .4s var(--ease), border-color .2s;
    }
    .tf-card:hover {
      border-color: var(--cyan);
    }
    .tf-tag {
      font: 700 .62rem "Cascadia Code", monospace;
      color: var(--cyan);
      margin-bottom: 12px;
    }
    .tf-tag.ok { color: var(--teal); }
    .tf-pergunta {
      font: 500 1.05rem Georgia, serif;
      color: var(--ink);
      line-height: 1.5;
      margin: 0 0 14px;
    }
    .tf-resposta {
      font-size: .9rem;
      color: var(--ink2);
      line-height: 1.6;
      margin: 0 0 14px;
    }
    .tf-hint {
      font-size: .75rem;
      color: var(--soft);
    }

    /* Botão dominado */
    .dominado-wrap {
      display: flex;
      justify-content: flex-end;
    }
    .done-btn {
      background: transparent;
      border: 1px solid var(--line2);
      color: var(--muted);
      border-radius: 999px;
      padding: 9px 20px;
      font: 600 .78rem "Inter", sans-serif;
      cursor: pointer;
      transition: all .2s;
    }
    .done-btn:hover {
      border-color: var(--teal);
      color: var(--ink);
    }
    .done-btn.dominado {
      background: color-mix(in srgb, var(--teal) 16%, transparent);
      border-color: var(--teal);
      color: var(--teal);
    }
  `]
})
export class TopicoFechamentoComponent {
  private storageService: StorageService;

  constructor() {
    try {
      this.storageService = inject(StorageService);
    } catch {
      this.storageService = new StorageService();
    }
  }

  @Input() tituloRevisao?: string;
  @Input() pontosRevisao?: RevisaoPonto[];
  @Input() pegadinha?: string;
  @Input() modeloMental?: string;

  @Input() exercicio?: ExercicioDados;
  @Input() flashcard?: FlashcardDados;
  @Input() topicoId?: string;

  readonly respondido = signal<boolean>(false);
  readonly acertou = signal<boolean>(false);
  readonly opcaoEscolhida = signal<string>('');
  readonly feedbackTexto = signal<string>('');
  readonly flashcardVirado = signal<boolean>(false);
  readonly isDominado = signal<boolean>(false);

  ngOnInit(): void {
    if (this.topicoId) {
      const salvo = this.storageService.getItem(`topico_${this.topicoId}_dominado`);
      this.isDominado.set(salvo === 'true');
    }
  }

  responder(op: ExercicioOpcao): void {
    this.respondido.set(true);
    this.opcaoEscolhida.set(op.letra);
    this.acertou.set(op.correta);
    this.feedbackTexto.set(op.rationale);

    if (op.correta) {
      // Incrementa XP
      const xpAtual = parseInt(this.storageService.getItem('quiz_xp') || '0', 10);
      this.storageService.setItem('quiz_xp', String(xpAtual + 50));
    }
  }

  virarFlashcard(): void {
    this.flashcardVirado.update(v => !v);
  }

  toggleDominado(): void {
    if (!this.topicoId) return;
    const novo = !this.isDominado();
    this.isDominado.set(novo);
    this.storageService.setItem(`topico_${this.topicoId}_dominado`, String(novo));
  }
}
